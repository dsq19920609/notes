import Vue from 'vue';
import App from './App.vue';
import store from './store';
import router from './router';
import filters from '@/filters/filters';
import '@/assets/styles/reset.css';

// 注册全局组件
Vue.use(window.hxmui, { projectName: 'goods_stock_selection' });

// 注册全局过滤器
Object.keys(filters).forEach(key => Vue.filter(key, filters[key]));

Vue.config.productionTip = false;

// 注册skyWalking
try {
  const host = window.location.hostname.split('.')[0];
  const collector =
    host === 'eq'
      ? 'https://apm.hexin.cn/skywalking-web'
      : 'https://khtest.10jqka.com.cn/skywalking-web';
  window.ClientMonitor.register({
    collector, // 采集器服务，注意区分环境和域名
    rate: 0.2, // 性能采集比例，业务流量小可以设为1
    service: 'mobileweb_goods_stocks_selection', // 业务标识     mobileweb_ +项目名
    // 页面路径，没有用前端路由要自定义，可参考location.pathname关键字
    pagePath: location.hash.replace('#', '') || '/root',
    serviceVersion: `${window.getPlatform()}_mobile_${window.getAppVersion() || 'others'}`, // 平台(iOS/Android/PC)+版本，格式：设备标识_业务标识_版本标识
    autoTracePerf: false,
    enableSPA: false, // 是否考虑SPA的处理，没有用前端路由一定要置为 false
    useFmp: false, // 是否记录首屏加载信息
    noTrace: true,
  });

  // vue项目在main.js中注册全局error捕获（必要）
  Vue.config.errorHandler = error => {
    console.log(error);
    window.ClientMonitor.reportFrameErrors(
      {
        category: 'js', // 类型
        grade: 'Warning', // 级别
      },
      error
    );
  };
} catch (e) {
  console.log(e);
}


new Vue({
  store,
  router,
  render: h => h(App),
}).$mount('#app');
