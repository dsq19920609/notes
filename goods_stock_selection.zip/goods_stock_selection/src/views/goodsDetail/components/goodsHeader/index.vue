<template>
  <div :class="$style.container">
    <div :class="$style.title">
      <span :class="$style.name">{{goodName}}</span>
    </div>
    <div v-if="goodsDesc" :class="[$style.info]">
      <div class="wrapper">
          <input id="exp1" class="exp" type="checkbox" />
          <div class="text">
            <label class="btn" for="exp1" @click="toggleExpand">
              <img src="@images/icon_list_forwardnew@3x.png" :class="textExpand ? 'expand' : ''">
            </label>
            {{goodsDesc}}
          </div>
        </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'GoodsHeader',
    props: {
      goodsDesc: String,
      goodName: String
    },
    data() {
      return {
        textExpand: false,
      }
    },
    mounted() {
    },
    methods: {
      toggleExpand() {
        this.textExpand = !this.textExpand;
      }
    }
  }
</script>

<style lang="less" module>
  @import "./index.less";
</style>
