<template>
  <div :class="$style.related">
    <hxm-tabs type="slide">
      <hxm-tab-panel title="关联" name="hushen">
        <div :class="$style.relatedBlocks">
          <div :class="$style.tips">
            <span>板块</span>
            <span>点击选择，叠加板块分时</span>
          </div>
          <div :class="$style.blockList">
            <div :class="$style.box">
              <template v-for="(block, index) in relatedBlocks">
                <div :style="index === (relatedBlocks.length - 1) ? {marginRight: '0.32rem'} : {}">
                  <div>
                    <div @click="changeBlock(index)" :class="$style.btns">
                      <img :src="block.checked ? selectImg : unSelectImg" alt="">
                    </div>
                    <div :class="$style.name" @click="jumpBlockPage">
                      <div>{{block.block_name}}</div>
                      <div>+23.45%</div>
                    </div>
                    <div :class="$style.type" v-if="block.block_type_display_name">{{block.block_type_display_name}}</div>
                    <div :class="$style.line" v-if="index !== (relatedBlocks.length - 1)"></div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>
        <div :class="$style.relatedStocks">
          <div :class="$style.tips">
            <span>个股</span>
            <span>点击选择，叠加股价走势</span>
          </div>
          <div :class="$style.stocksList">
            <div :class="$style.fixed" ref="fixed">
              <div :class="[$style.fixedHeader]" ref="fixedHeader">
                <span>叠加</span><span>股票名称</span>
              </div>
              <div :class="$style.list">
                <div v-for="(stock, index) in relatedStocks">
                  <template>
                    <div :class="$style.item">
                      <div :class="$style.selImg" @click="changeStock(index)"><img :src="stock.checked ? selectImg : unSelectImg" alt=""></div>
                      <div :class="$style.name">
                        <div>{{stock.stock_name}}</div>
                        <div>{{stock.stock_ths_hq_code}}</div>
                      </div>
                    </div>
                  </template>
                </div>
              </div>
            </div>
            <div :class="$style.right">
                <div :class="$style.rightHeader" ref="rightHeader">
                  <span>最新价<img :src="sortIcons[0]" @click="changeSort(0)"/></span>
                  <span>涨跌幅<img :src="sortIcons[1]" @click="changeSort(1)"/></span>
                  <span>行情关联度<img :src="sortIcons[2]" @click="changeSort(2)"/></span>
                  <span>成交额<img :src="sortIcons[3]" @click="changeSort(3)"/></span>
                  <span>换手率<img :src="sortIcons[4]" @click="changeSort(4)"/></span>
                </div>
                <template v-for="(stock, index) in relatedStocks">
                  <div :class="$style.item">
                    <span>65.15</span>
                    <span>+6.14%</span>
                    <span>{{stock.correlation_hundred | decimal | addPercentSymbol }}</span>
                    <span>0.58%</span>
                    <span>0.58%</span>
                  </div>
                </template>
            </div>
          </div>
        </div>
      </hxm-tab-panel>
      <!-- <hxm-tab-panel title="产业链" name="bankuai"></hxm-tab-panel>
      <hxm-tab-panel title="新闻" name="kechuangban1"></hxm-tab-panel>
      <hxm-tab-panel title="研报" name="renqi"></hxm-tab-panel> -->
    </hxm-tabs>
  </div>
</template>

<script>
import selectImg from '@images/select_xz@3x.png';
import unSelectImg from '@images/checkbox_list_wxz@2x.png';
import sortIcon from '@images/sort_icon.png';
import sortUpIcon from '@images/sort_up.png';
import sortDownIcon from '@images/sort_down.png';
import sortDefaultIcon from '@images/sort_default.png';


export default {
  props: {
    relatedBlocks: {
      type: Array,
      default: []
    },
    relatedStocks: {
      type: Array,
      default: []
    }
  },
  data() {
    return {
      isFixedHeader: false,
      selectImg,
      unSelectImg,
      sortIcon,
      sortDefaultIcon,
      sortUpIcon,
      sortDownIcon,
      sortState: [0, 0, 0, 0, 0],
      sortIcons: [sortDefaultIcon, sortDefaultIcon, sortDefaultIcon, sortDefaultIcon, sortDefaultIcon]
    }
  },
  mounted() {
    this.initBlocks();
    this.initStocks();
  },
  methods: {
    jumpBlockPage() { // 跳转到板块分时页

    },
    changeSort(index) {
      const curIndex = Number.parseInt(index);
      let sortField = ''; // 排序字段
      let sortType = ''; // 1: 升序  2：降序
      const newSortIcons = [sortDefaultIcon, sortDefaultIcon, sortDefaultIcon, sortDefaultIcon, sortDefaultIcon];
      const newSortState = [0, 0, 0, 0, 0];
      if (this.sortState[curIndex] === 0) {
        sortType = 1;
        newSortState[curIndex] = 1;
        newSortIcons[curIndex] = sortUpIcon;
      }
      if (this.sortState[curIndex] === 1) {
        sortType = 2;
        newSortState[curIndex] = 2;
        newSortIcons[curIndex] = sortDownIcon;
      }
      if (this.sortState[curIndex] === 2) {
        sortType = 1;
        newSortState[curIndex] = 1;
        newSortIcons[curIndex] = sortUpIcon;
      }
      this.sortState = [...newSortState];
      this.sortIcons = [...newSortIcons];
      switch (curIndex) {
        case 0: sortField = ''; break;
        case 1: sortField = ''; break;
        case 2: sortField = 'correlation_hundred'; break;
        case 3: sortField = ''; break;
        case 4: sortField = ''; break;
        default: sortField = '';
      }
      this.handleStocksSort(sortField, sortType);
    },
    handleStocksSort(field, sortType) {
      if (!field || !sortType) return;
      // 处理relatedStocks，根据排序字段和排序类型进行排序 1：升序 2：降序
      const stocks = [...this.relatedStocks];
      stocks.sort((a, b) => {
        if (sortType === 2) {
          return b[field] - a[field];
        }
        if (sortType === 1) {
          return a[field] - b[field];
        }
      });
      this.relatedStocks = [...stocks];
    },
    initBlocks() {
      this.resetRelatedBlocks();
    },
    resetRelatedBlocks() {
      if (Array.isArray(this.relatedBlocks)) {
        this.relatedBlocks.forEach(block => {
          block.checked = false;
        });
        this.relatedBlocks = [...this.relatedBlocks];
      }
    },
    
    initStocks() {
      this.resetRelatedStocks();
    },
    resetRelatedStocks() {
      if (Array.isArray(this.relatedStocks)) {
        this.relatedStocks.forEach(stock => {
          stock.checked = false;
        });
        this.relatedStocks = [...this.relatedStocks];
      }
    },
    changeBlock(index) {
      if (this.relatedBlocks[index].checked) {
        this.relatedBlocks[index].checked = false;
      } else {
        this.relatedBlocks.forEach(block => {
          block.checked = false;
        })
        this.relatedBlocks[index].checked = true;
      }
      this.relatedBlocks = [...this.relatedBlocks];
      this.resetRelatedStocks();
    },
    changeStock(index) {
      if (this.relatedStocks[index].checked) {
        this.relatedStocks[index].checked = false;
      } else {
        this.relatedStocks.forEach(block => {
          block.checked = false;
        })
        this.relatedStocks[index].checked = true;
      }
      this.relatedStocks = [...this.relatedStocks];
      this.resetRelatedBlocks();
    }
  },
}
</script>

<style lang="less" module>
  @import './index.less';
</style>