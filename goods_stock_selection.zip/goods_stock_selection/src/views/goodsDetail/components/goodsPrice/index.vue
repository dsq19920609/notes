<template>
  <div :class="$style.container">
    <div :class="$style.tabs">
      <div :class="$style.tabWrapper">
        <span :class="[curTab === '1' ? $style.cur : $style.notCur]" @click="handleTabChange(1)">价格趋势</span>
        <span :class="[curTab === '2' ? $style.cur : $style.notCur]" @click="handleTabChange(2)">产业数据</span>
      </div>
    </div>
    <div :class="$style.updateData">
      <update-data :curTab="curTab" :frequencyText="frequencyText" :goodsPrice="goodsPrice" :curIdustryPrice="curIdustryPrice"/>
    </div>
  </div>
</template>


<script>
import UpdateData from './UpdateData';
import { mapState, mapMutations }　from 'vuex';

export default {
  components: {
    UpdateData
  },
  props: {
    goodsPrice: Object,
    industryPriceList: Object,
  },
  data() {
    return {
      curTab: '1', // 当前页签 '1': 价格趋势 '2': 产业数据
      curIdustryPrice: {},
      frequencyText: ''
    }
  },
  mounted() {
    this.getCurIndustryPrice();
    this.getFrequencyText();
  },
  methods: {
    handleTabChange(tab) {
      this.curTab = `${tab}`;
      if (this.curTab === '2') {
        this.getCurIndustryPrice();
      }
      this.getFrequencyText();
      this.$emit('pageChange', tab === '1' ? 'goods' : 'industry');
    },
    getCurIndustryPrice() {
      this.industryPriceList.forEach(item => {
        if (item.industryCode === this.curIndustryCode) {
          this.curIdustryPrice = { ...item };
        }
      });
    },
    getFrequencyText: function() {
      const date = {
        'D': '日更',
        'W': '周更',
        'M': '月更'
      };
      if (this.curTab === '1') {
        this.frequencyText = date[this.goodsPrice.frequency];
      }
      if (this.curTab === '2') {
        this.frequencyText = date[this.curIdustryPrice.frequency];
      }
    }
  },
  computed: {
    ...mapState(['curIndustryCode'])
  },
  watch: {
    goodsPrice(price) {
      if (price && price.frequency) {
        this.getFrequencyText();
      }
    }
  }
}
</script>

<style lang="less" module>
  @import './index.less';
</style>