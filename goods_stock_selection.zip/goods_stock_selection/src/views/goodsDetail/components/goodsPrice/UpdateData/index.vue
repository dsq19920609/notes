<template>
  <div :class="$style.container">
    <span :class="$style.tips">{{frequencyText}}</span>
    <div v-if="curTab === '1'" :class="$style.goodsPrice">
      <div>
        <div>最新价格</div>
        <div>{{goodsPrice.price | decimal}}</div>
      </div>
      <div>
        <div>最新涨幅</div>
        <div>{{goodsPrice.change | decimal | positive | addPercentSymbol}}</div>
      </div>
      <div v-if="goodsPrice.frequency !== 'w'">
        <div>近一周涨幅</div>
        <div>{{goodsPrice.week_change | decimal | positive | addPercentSymbol}}</div>
      </div>
      <div>
        <div>近一月涨幅</div>
        <div>{{goodsPrice.month_change | decimal | positive | addPercentSymbol}}</div>
      </div>
    </div>
    <div v-else :class="$style.industry">
      <div>
        <div>{{curIdustryPrice.change | decimal}}</div>
        <div>最新值</div>
      </div>
      <div>
        <div>{{curIdustryPrice.year_on_year | decimal | positive | addPercentSymbol}}</div>
        <div>同比</div>
      </div>
      <div>
        <div>{{curIdustryPrice.month_on_month | decimal | positive | addPercentSymbol}}</div>
        <div>环比</div>
      </div>
    </div>
  </div>
</template>


<script>
export default {
  props: {
    curTab: {
      type: 'string',
      required: true
    },
    frequencyText: String,
    goodsPrice: Object,
    curIdustryPrice: Object
  },
  data() {
    return {
    }
  }
}
</script>

<style lang="less" module>
  @import './index.less';
</style>