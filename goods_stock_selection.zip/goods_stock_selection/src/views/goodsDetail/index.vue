<template>
  <div :class="$style.container">
    <div :class="$style.nav">
      <img alt='' src='@images/icon_nav_back@3x.png'/>
      <span>{{goodName | wordSlice(7)}}</span>
    </div>
    <div :class="$style.goodsInfo">
      <goods-header :goodsDesc='goodsDesc' :goodName="goodName"/>
    </div>
    <div v-if="isShowFutures" :class="$style.futures" @click="toFuturesPage">
      <span>期货</span>
      <span>{{futuresInfo.future_code}}{{futuresInfo.future_name}}</span>
      <span>374.58</span>
      <span>+3.21%</span>
      <img src="@images/icon_forward.png" alt="">
    </div>
    <div :class="$style.goodsPrice">
      <goods-price :goodsPrice="goodsPrice" :industryPriceList="industryPriceList" @pageChange="pageChange"/>
    </div>
    <div :class="[$style.fixedPart]" ref="fixedPart"> 
      <div :class="$style.chartsDisplay">
        <charts-display/>
      </div>
      <div :class="$style.relatedModule">
        <related-module :relatedBlocks="relatedBlocks" :relatedStocks="relatedStocks"/>
      </div>
    </div>
  </div>
</template>


<script>
import { getGoodsDetaill, getIndustryDetail } from '@/apis/goods';
import GoodsHeader from './components/goodsHeader';
import goodsPrice from './components/goodsPrice';
import chartsDisplay from './components/chartsDisplay';
import RelatedModule from './components/relatedModule';
import { mapMutations } from 'vuex';

export default {
  name: 'goodsDetail',
  components: {
    GoodsHeader,
    goodsPrice,
    RelatedModule,
    chartsDisplay
  },
  data() {
    return {
      goodsData: {}, // 商品详情
      goodName: '',
      goodsDesc: '',
      curPage: 'goods', // goods:商品价格趋势 industry: 产业数据
      isShowFutures: false,
      futuresInfo: {}, // 期货信息
      goodsPrice: {
        frequency: '', // d: 日更 w: 周更 m: 月更
        price: '',
        change: '',
        week_change: '',
        month_change: ''
      }, // 商品价格涨幅
      industryDetailList: [], // 产业数据详情列表
      industryPriceList: [], // 产业数据同比，环比等信息
      relatedBlocks: [], // 关联的板块列表
      relatedStocks: [] // 关联的个股
    }
  },
  mounted() {
    // 获取商品详情
    getGoodsDetaill('S004451247').then(data => {
      this.goodsData = data;
      this.buildGoodsDetailData(data);
      this.buildRelatedBlockAStocksData(data);
      this.getIndustryListDetail(data);
    });
  },
  methods: {
    getIndustryListDetail(data){
      const { related_industry } = data;
      if (Array.isArray(related_industry) && related_industry.length > 0) {
        const reqQueue = [];
        related_industry.forEach(item => reqQueue.push(getIndustryDetail(item.industry_code)));
        Promise.all(reqQueue).then(result => {
          this.industryDetailList = result;
          this.buildIndustryData(result);
        });
      }
    },
    toFuturesPage() { // 跳转到商品落地页
      console.log('toFuturesPage');
    },
    buildGoodsDetailData(data) {
      const { base_info: { good_name, good_desc, frequency, price, change, week_change, month_change }, related_industry, related_future } = data;
      this.goodName = good_name;
      this.goodsDesc = good_desc;
      this.goodsPrice = {
        frequency,
        price,
        change,
        week_change,
        month_change
      };
      // 是否展示货期
      if (related_future && related_future.future_code) {
        this.isShowFutures = true;
        this.futuresInfo = {
          future_code: related_future.future_code,
          future_name: related_future.future_name
        };
        this.getFutureDetail();
      }
    },
    getFutureDetail() {
      // 客户端获取期货的现价和涨跌幅
      if (window.callNativeHandler) {
        callNativeHandler('getHQ', {
          columnorder: ['10', '34818'], // 现价 涨跌幅
          stocklist: [], //股票代码列表
          marketlist: [], //市场id类别
        }, () => {
        });
      }
    },
    buildIndustryData(result) {
      // 默认选中第一条产业数据
      this.setIndustryCode({
        industry_code: result[0].base_info.industry_code
      });
      if(Array.isArray(result)) {
        const industryPriceList = [];
        result.forEach(item => {
          const { base_info: { industry_code, frequency, change, year_on_year, month_on_month  } } = item;
          industryPriceList.push({
            industryCode: industry_code,
            frequency: frequency, // d: 日更 w: 周更 m: 月更
            change,
            year_on_year,
            month_on_month
          }); 
        });
        this.industryPriceList = industryPriceList;
      }
    },
    buildRelatedBlockAStocksData(data) {
      // 构建板块和个股数据时，调用客户端协议查询现价和涨幅信息等
      if (this.curPage === 'goods') {
        const { related_blocks, related_stocks } = data;
        this.relatedBlocks = related_blocks || [];
        this.relatedStocks = related_stocks || [];
        this.getStockDetail(related_stocks);
      }
      if (this.curPage === 'industry') {
        if (this.industryDetailList && this.industryDetailList.length > 0) {
          const { related_blocks, related_stocks } = this.industryDetailList[0];
          this.relatedBlocks = related_blocks || [];
          this.relatedStocks = related_stocks || [];
          this.getStockDetail(related_stocks);
        }
      }
    },
    // 获取板块涨跌幅
    getBlockDetail() {
      if (window.callNativeHandler) {
        callNativeHandler('getHQ', {
          columnorder: ['10', '34818'], // 现价 涨跌幅
          stocklist: [], //股票代码列表
          marketlist: [], //市场id类别
        }, () => {

        });
      }
    },
    // 获取个股的涨跌幅等信息
    getStockDetail(stocks) {
      const stocklist = [];
      const marketlist = [];
      if (Array.isArray(stocks) && stocks.length > 0) {
        stocks.forEach(stock => {
          stocklist.push(stock.stock_ths_hq_code);
          marketlist.push(stock.market_ths_hq_code);
        });
      }
      if (window.callNativeHandler) {
        callNativeHandler('getHQ', {
          columnorder: ['10', '34818', '19', '967817'], // 现价 涨跌幅
          stocklist: [], //股票代码列表
          marketlist: [], //市场id类别
        }, () => {

        });
      }
    },
    pageChange(page) {
      this.curPage = page;
      // 页签切换时产业数据重置为默认值
      if (this.industryDetailList && this.industryDetailList.length > 0) {
        const { base_info, related_blocks, related_stocks } = this.industryDetailList[0];
        this.setIndustryCode({
          industry_code: base_info.industry_code
        });
      }
      this.buildRelatedBlockAStocksData(this.goodsData);
    },
    ...mapMutations(['setIndustryCode'])
  },
};
</script>

<style lang="less" module>
  @import './index.less';
</style>
