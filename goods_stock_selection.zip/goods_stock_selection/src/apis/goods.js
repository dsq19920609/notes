// eslint-disable-next-line no-unused-vars
import req from '../utils/http';

// 商品详情
export function getGoodsDetaill(goodCode) {
  return req('get', `https://apigate-test.10jqka.com.cn/d/goods-stock-pick/goods/detail/query?good_code=${goodCode}`);
};

// 产业详情
export function getIndustryDetail(industryCode) {
  return req('get',  `https://apigate-test.10jqka.com.cn/d/goods-stock-pick/industry/detail/query?industry_code=${industryCode}`);
}