// 无数据情况处理，传入空字符串
const judgeIsNull = function (val) {
  const target = typeof val === 'object' ? Object.prototype.toString.call(val) : `${val}`;
  if (/null|undefined|nan|^\s*$/i.test(target)) {
    return '--';
  }
  return val;
};

// 数值保留两位小数
const decimal = function (val) {
  const two = 2;
  return judgeIsNull(val) === '--' ? '--' : parseFloat(val).toFixed(two);
};

// 正数前面添加+
const positive = function (val) {
  if (judgeIsNull(val) === '--') {
    return '--';
  } else if (parseFloat(val) > 0) {
    return `+${val}`;
  } else {
    return val;
  }
};

// 数值后添加%
const addPercentSymbol = function (val) {
  return judgeIsNull(val) === '--' ? '--' : `${val}%`;
};

// 去除字符串的空格
const removeSpace = function (val) {
  return judgeIsNull(val) === '--' ? val.replace(/\s/g, '') : '--';
};

// 时间戳转换为日期
const stampToDate = function (val) {
  return Boolean(+val) ? new Date(+val).toTimeString().split(' ')[0] : '--';
};

// 文字截取
const wordSlice = function(text, length) {
  if (typeof text === 'string' && text.length > 7) {
    return text.slice(0, length) + '...';
  }
  return text;
}

export default {
  judgeIsNull,
  decimal,
  positive,
  addPercentSymbol,
  removeSpace,
  stampToDate,
  wordSlice
};
