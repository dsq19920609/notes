
const Detail = () =>　import('../views/goodsDetail');

export default [
  {
    path: '/detail',
    name: 'Detail',
    component: Detail,
    meta: {
      title: '',
    },
  },
  {
    path: '*',
    redirect: '/detail',
  },
];
