// 初始state
const state = () => ({
  curIndustryCode: '0' // 当前选中的industry_code
});

// getters
const getters = {

};

// mutations
const mutations = {
  setIndustryCode(state, payload) {
    state.curIndustryCode = payload.industry_code;
  }
};

// actions
const actions = {

};


export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
};
