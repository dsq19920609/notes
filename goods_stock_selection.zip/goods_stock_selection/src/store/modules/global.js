// 初始state
const state = () => ({
});

// getters
const getters = {

};

// mutations
const mutations = {

};

// actions
const actions = {

};


export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
};
