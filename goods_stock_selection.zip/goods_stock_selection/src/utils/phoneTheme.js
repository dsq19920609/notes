// 判断黑夜模式  hxtheme/0 hxtheme/1
export const phoneTheme = (type = false) => {
  const ua = navigator.userAgent.toLowerCase();
  if (/hxtheme\/1/gi.test(ua) && type) {
  // 黑夜模式
    document.getElementsByTagName('html')[0].setAttribute('theme-mode', 'black');
  }
  return /hxtheme\/1/gi.test(ua);
};
