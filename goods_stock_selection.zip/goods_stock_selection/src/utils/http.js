/* eslint-disable no-console */
import axios from 'axios';
import qs from 'qs';

const instance = axios.create({
  baseURL: '',
  timeout: 3000,
  withCredentials: true, // 跨域请求携带cookie
});

const reqlock = {};

instance.interceptors.request.use(
  function (config) {
    // 请求锁定，同一个请求只能同时有一个在请求中
    const reqLockKey = config.params && config.params.reqLockKey;
    if (!reqLockKey || !reqlock[reqLockKey]) {
      reqLockKey && (reqlock[reqLockKey] = true);
      return config;
    } else {
      return Promise.reject();
    }
  },
  function (error) {
    return Promise.reject(error);
  }
);

// 错误处理需要完善
instance.interceptors.response.use(
  function (response) {
    const reqLockKey = response.params && response.params.reqLockKey;
    if (reqLockKey) {
      reqlock[reqLockKey] = false;
    }
    return response.data;
  },
  function (error) {
    return Promise.reject(error);
  }
);

export default function (method, url, lastUrl, data = null) {
  const newUrl = url + (lastUrl ? lastUrl : '');
  const newMethod = method.toLowerCase();
  if (newMethod === 'post') {
    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
    };
    return new Promise((resolve, reject) => {
      instance.post(newUrl, qs.stringify(data), config).then((result) => { resolve(result.data) }).catch((error) => { reject(error) })
    });
  } else if (newMethod === 'get') {
    return new Promise((resolve, reject) => {
      instance.get(newUrl, {
        params: data,
      }).then((result) => { resolve(result.data) }).catch((error) => { reject(error) })
    });
  } else {
    return false;
  }
}
