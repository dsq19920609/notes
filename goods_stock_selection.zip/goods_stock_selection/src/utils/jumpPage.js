// 跳转到商品落地页
export function jumpToProdPage(stockCode, marketId) {
  location.href = `client://client.html?action=ymtz^webid=2205^stockcode=${stockCode}^marketid=${marketId}`;
}

// 跳转到板块分时页
export function jumpToBlockPage(stockCode, marketId) {
  location.href = `client://client.html?action=ymtz^webid=2205^stockcode=${stockCode}^marketid=${marketId}`;
}