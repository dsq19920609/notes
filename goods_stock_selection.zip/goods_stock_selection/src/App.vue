<template>
    <div id="app">
      <router-view />
    </div>
  </template>
  
  <script>
  import { phoneTheme } from './utils/phoneTheme'
  export default {
    mounted() {
      phoneTheme();
    }
  }
  </script>
  
  <style lang="less">
  @import './assets/styles/skin.less';
    html {
      height: 100%;
    }
    body {
      height: 100vh;
      background: @background-page;
      overflow-x: hidden;
    }
    #app {
      height: 100%;
      font-family: 'PingFang Medium', 'PingFang SC', 'Source Han Sans', sans-serif;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
  
    [theme-mode="black"] {
      html {
        height: 100%;
      }
      body {
        height: 100%;
        background: @background-page-dark;
        overflow-x: hidden;
      }
      #app {
        height: 100%;
        font-family: 'PingFang Medium', 'PingFang SC', 'Source Han Sans', sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
    }
  </style>
  