/* eslint-disable camelcase */
const path = require("path");
const webpack = require("webpack");
const TerserJSPlugin = require("terser-webpack-plugin");

// 正式环境
const IS_RELEASE = process.env.VUE_APP_CURRENTMODE === "release";

function resolve(dir) {
  return path.join(__dirname, dir);
}

module.exports = {
  publicPath: process.env.VUE_APP_BASE_URL, // 静态资源的前缀(可配置为域名后面的子路径或直接配置为绝对路径域名 + 子路径)
  css: {
    // 正式环境关闭sourcemap
    sourceMap: !IS_RELEASE
  },
  productionSourceMap: !IS_RELEASE, // 正式环境关闭sourcemap
  lintOnSave: false,
  chainWebpack: config => {
    // 小文件转换成base64
    config.module
      .rule("images")
      .use("url-loader")
      .loader("url-loader")
      .tap(options =>
        Object.assign(options, {
          limit: 10240,
          fallback: {
            loader: "file-loader",
            options: {
              name: "img/[name].[ext]"
            }
          }
        })
      );
  },
  configureWebpack: config => {
    Object.assign(config.resolve, {
      alias: {
        "@": resolve("src"),
        "@components": resolve("src/components"),
        "@views": resolve("src/views"),
        "@images": resolve("src/assets/images"),
        "@style": resolve("src/assets/styles")
      },
      extensions: [".js", ".vue", ".less", ".json"],
      modules: [resolve("node_modules"), "node_modules"],
      mainFields: ["browser", "module", "main"]
    });
    config.devtool = "sourcemap";
    // webpack 正式环境开启代码压缩
    config.optimization = IS_RELEASE
      ? {
          minimizer: [
            new TerserJSPlugin({
              terserOptions: {
                compress: {
                  dead_code: true,
                  drop_debugger: IS_RELEASE,
                  drop_console: IS_RELEASE
                }
              }
            })
          ]
        }
      : {};
    // 将变量注入每个模块(其实不建议这样做，容易造成代码混乱)
    config.plugins.push(
      new webpack.ProvidePlugin({
        // 全局配置项
        _Global: [resolve("./src/config/index.js"), "default"],
        // 工具库
        _t: [resolve("./src/utils/tools.js"), "default"]
      })
    );
    config.externals = [
      {
        vue: "Vue"
      }
    ];
  },
  devServer: {
    open: false,
    // host: 'dev.10jqka.com.cn',
    host: 'localhost',
    // disableHostCheck: true,
    port: 8080,
    // https: true,
    // 接口代理配置
    proxy: {
      '/api': {
        target: 'http://gpc.10jqka.com.cn/valuation',
        ws: false,
        changeOrigin: true,
        pathRewrite: {
          '^/api': '/',
        },
      },
    },
  },
  pluginOptions: {
    "style-resources-loader": {
      preProcessor: "less",
      patterns: [resolve("src/assets/styles/common.less")]
    }
  }
};
