<template>
  <div class="home" @scroll="pageScroll(e)">
    <!-- 陆股通/港股通切换 -->
    <div class="top-cards" :class="{ fixed: fixedTab }">
      <!-- 陆股通 -->
      <div
        class="card"
        :class="{ default: pageType !== 'north', active: pageType === 'north' }"
        @click="changeCard('north')"
      >
        <div class="header">
          <div class="title">
            <div class="main-title">陆股通</div>
            <div class="sub-title">(北向)</div>
          </div>
          <div class="label" :class="{ trade: todayFlowData.hgtMarketStatus === 3 }">
            {{ todayFlowData.hgtMarketStatusDesc }}
          </div>
        </div>
        <div class="desc">
          <div class="desc-title">成交净买入</div>
          <div class="desc-value" :class="{ red: todayFlowData.hsTotalNetBuy >= 0 }">
            {{ todayFlowData.hsTotalNetBuy | numberConvert
            }}<span style="fontsize: 0.26rem;">亿</span>
          </div>
        </div>
        <div class="desc">
          <div class="desc-title">近一周</div>
          <div class="desc-value" :class="{ red: todayFlowData.hsWeekTotalNetBuy >= 0 }">
            {{ todayFlowData.hsWeekTotalNetBuy | numberConvert
            }}<span style="fontsize: 0.26rem;">亿</span>
          </div>
        </div>
      </div>
      <!-- 港股通 -->
      <div
        class="card"
        :class="{ default: pageType !== 'south', active: pageType === 'south' }"
        @click="changeCard('south')"
      >
        <div class="header">
          <div class="title">
            <div class="main-title">港股通</div>
            <div class="sub-title">(南向)</div>
          </div>
          <div class="label" :class="{ trade: todayFlowData.ggtMarketStatus === 3 }">
            {{ todayFlowData.ggtMarketStatusDesc }}
          </div>
        </div>
        <div class="desc">
          <div class="desc-title">成交净买入</div>
          <div class="desc-value" :class="{ red: todayFlowData.hkTotalNetBuy >= 0 }">
            {{ todayFlowData.hkTotalNetBuy | numberConvert
            }}<span style="fontsize: 0.26rem;">亿</span>
          </div>
        </div>
        <div class="desc">
          <div class="desc-title">近一周</div>
          <div class="desc-value" :class="{ red: todayFlowData.hkWeekTotalNetBuy >= 0 }">
            {{ todayFlowData.hkWeekTotalNetBuy | numberConvert
            }}<span style="fontsize: 0.26rem;">亿</span>
          </div>
        </div>
      </div>
    </div>
    <!-- 陆股通/港股通页面 -->
    <div class="page" :key="pageType">
      <!-- 模块切换tab -->
      <div class="module-tabs" :class="{ fixed: fixedTab }">
        <template v-for="(item, index) in moduleTabs">
          <div
            v-if="!(pageType === 'south' && (item.id === '3' || item.id === '4'))"
            :key="index"
            class="module-tab"
            :class="{ active: currentTab === item.id }"
            @click="changeModule(item.id)"
          >
            {{ item.tab }}
            <div class="active-bottom"></div>
          </div>
        </template>
      </div>
      <!-- 资金流向模块 -->
      <MoneyFlow
        v-show="currentTab === '1'"
        :pageType="pageType"
        :fixedTab="fixedTab"
        :todayFlowData="todayFlowData"
      ></MoneyFlow>
      <StocksPanel :pageType="pageType" v-if="currentTab === '2'"></StocksPanel>
      <BlocksPanel :pageType="pageType" v-if="currentTab === '3'"></BlocksPanel>
      <OrgnizationPanel :pageType="pageType" v-if="currentTab === '4'"></OrgnizationPanel>
    </div>
    <SearchPanel
      :searchList="searchList"
      @cancel="searchVisible = false"
      v-if="searchVisible"
    ></SearchPanel>
    <!-- 用于CICD上传 -->
    <img src="../assets/images/icon_nav_search@2x.png" style="display: none;" />
    <img src="../assets/images/icon_nav_search_dark@2x.png" style="display: none;" />
  </div>
</template>

<script>
const MODULETABS = [
  {
    id: '1',
    tab: '资金流向',
  },
  {
    id: '2',
    tab: '个股',
  },
  {
    id: '3',
    tab: '板块',
  },
  {
    id: '4',
    tab: '机构',
  },
];
import MoneyFlow from './MoneyFlow';
import SearchPanel from '@/components/SearchPanel.vue';
import StocksPanel from './StocksPanel.vue';
import BlocksPanel from './BlocksPanel.vue';
import OrgnizationPanel from './OrgnizationPanel.vue';
import config from '@/config';
import util from '@/lib/util.js';
import { getTodayFlowData, getSearchStocks } from '@/apis/index';
import { mapState, mapMutations } from 'vuex';
import { phoneTheme } from '@/assets/common.js';
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
export default {
  name: 'Home',
  components: {
    MoneyFlow,
    StocksPanel,
    BlocksPanel,
    SearchPanel,
    OrgnizationPanel,
  },
  computed: {
    ...mapState(['fixedTab']),
  },
  mounted() {
    // 具体顶部的距离
    this.tabsOffsetTop = document.getElementsByClassName('module-tabs')[0].offsetTop;
    if (util.getQueryVariable('tab')) {
      this.changeModule(util.getQueryVariable('tab'));
    }
    try {
      // 股票列表
      getSearchStocks().then(res => {
        this.searchList = res.hs.data.concat(res.hk.data);
      });
    } catch (error) {
      console.log(error);
    }

    this.handleGetTodayFlowData(); // 获取今日流向数据
    // 30s更新一下数据
    this.timer = setInterval(() => {
      this.handleGetTodayFlowData(); // 获取今日流向数据
    }, 30000);
    this.initSearch();
    window.addEventListener('scroll', e => {
      if (this.tabsOffsetTop <= e.target.scrollingElement.scrollTop) {
        this.setFixedTab(true);
      } else {
        this.setFixedTab(false);
      }
    });
    document.addEventListener('visibilitychange', () => {
      this.initSearch();
    });
    window.hxmClickStat('hsgtnew');
  },
  beforeDestroy() {
    window.removeEventListener('scroll', () => {});
    clearInterval(this.timer);
  },
  data() {
    return {
      pageType: 'north', // 页面类型。陆股通：north;港股通：south。
      moduleTabs: MODULETABS, // tab栏选项
      searchVisible: false,
      currentTab: '1', // 当前tab
      // fixedTab: false, // tab签是否固定在页面顶部
      tabsOffsetTop: null, // tab签距页面顶部的距离
      todayFlowData: {
        date: '', // 交易日日期
        type: '', // north北向，south南向
        hsTotalNetBuy: '', // 陆股通今日成交净买入
        hsWeekTotalNetBuy: '', // 陆股通近一周净买入
        hkTotalNetBuy: '', // 港股通今日成交净买入
        hkWeekTotalNetBuy: '', // 港股通近一周净买入
        hgtMarketStatus: '', // 陆股通市场状态
        hgtMarketStatusDesc: '', // 陆股通市场状态描述
        ggtMarketStatus: '', // 港股通市场状态
        ggtMarketStatusDesc: '', // 港股通市场状态描述
        newHighRemind: '', // 创新高提醒文案
        chartData: {
          netBuyData: [], // 净买入数据
          netInflowData: [], // 净流入数据
        }, // 今日流向图表数据
      }, // 今日流向数据
      timer: null,
      // 支持沪深港通的股票列表
      searchList: [],
    };
  },
  methods: {
    ...mapMutations(['setFixedTab']),
    initSearch() {
      const self = this;
      const imgUrl = phoneTheme() ? 'icon_nav_search_dark@2x.png' : 'icon_nav_search@2x.png';
      try {
        window.callNativeHandler('notifyWebHandleEvent', {
          method: 'setTitleBar',
          params: {
            rightViewType: 'ImageFunctionView', //右上角功能的类型
            stopSetNil: 'yes',
            buttonName: 'search',
            imgUrl: `https:${config.imageUrl}/img/${imgUrl}`,
          },
        });

        window.callNativeHandler('changeWebViewButton');

        window.registerWebHandler('changeWebViewButton', function () {
          self.searchVisible = true;
        });
      } catch (e) {
        console.log(e);
      }
    },
    // 切换陆股通/港股通
    changeCard(type) {
      this.pageType = type;
      this.currentTab = '1'; //  当前页签  资金流向、个股、板块、机构
      this.handleGetTodayFlowData();
      if (type == 'north') {
        window.hxmClickStat('lsgt.lgt');
      } else {
        window.hxmClickStat('lsgt.ggt');
      }
    },
    // 切换模块 
    changeModule(id) {
      this.currentTab = id;
      if (this.fixedTab) {
        // document.documentElement.scrollTop = 372;
        window.scrollTo(0, 372 * pageRate * dpr);
      }
      // 埋点
      if (this.pageType == 'north') {
        if (id == 1) {
          window.hxmClickStat('lsgt.lgt.zjlx');
        } else if (id == 2) {
          window.hxmClickStat('lsgt.lgt.gg');
        } else if (id == 3) {
          window.hxmClickStat('lsgt.lgt.bk');
        } else {
          window.hxmClickStat('lsgt.lgt.jg');
        }
      } else {
        if (id == 1) {
          window.hxmClickStat('lsgt.ggt.zjlx');
        } else {
          window.hxmClickStat('lsgt.ggt.gg');
        }
      }
    },
    // 获取页面数据(今日流向分时图)
    handleGetTodayFlowData() {
      getTodayFlowData(this.pageType).then(res => {
        // console.log(res);
        if (res.status_code === 0) {
          const netBuyData = []; // 净买入数据
          const netInflowData = []; // 净流入数据
          // 初始化净买入数据
          res.data.net_buy_time_list.forEach((item, index) => {
            netBuyData.push({
              date: item,
              total: null,
              sh: null,
              sz: null,
            });
          });
          // 净买入
          res.data.total_net_buy_list.forEach((item, index) => {
            netBuyData[index].total = item;
          });
          // 沪股通
          res.data.sh_net_buy_list.forEach((item, index) => {
            netBuyData[index].sh = item;
          });
          //  深股通
          res.data.sz_net_buy_list.forEach((item, index) => {
            netBuyData[index].sz = item;
          });
          // 初始化净流入数据
          res.data.net_inflow_time_list.forEach((item, index) => {
            netInflowData.push({
              date: item,
              total: null,
              sh: null,
              sz: null,
            });
          });
          res.data.total_net_inflow_list.forEach((item, index) => {
            netInflowData[index].total = item;
          });
          res.data.sh_net_inflow_list.forEach((item, index) => {
            netInflowData[index].sh = item;
          });
          res.data.sz_net_inflow_list.forEach((item, index) => {
            netInflowData[index].sz = item;
          });
          this.todayFlowData = {
            date: res.data.date, // 交易日日期
            type: res.data.type, // north北向，south南向
            hsTotalNetBuy: res.data.hs_total_net_buy, // 陆股通今日成交净买入
            hsWeekTotalNetBuy: res.data.hs_week_total_net_buy, // 陆股通近一周净买入
            hkTotalNetBuy: res.data.hk_total_net_buy, // 港股通今日成交净买入
            hkWeekTotalNetBuy: res.data.hk_week_total_net_buy, // 港股通近一周净买入
            hgtMarketStatus: res.data.hgt_market_status, // 陆股通市场状态 3：交易中 4：无间休市
            hgtMarketStatusDesc: res.data.hgt_market_status_desc, // 陆股通市场状态描述
            ggtMarketStatus: res.data.ggt_market_status, // 港股通市场状态
            ggtMarketStatusDesc: res.data.ggt_market_status_desc, // 港股通市场状态描述
            newHighRemind: res.data.new_high_remind, // 创新高提醒文案
            chartData: { // 今日流向图表数据
              netBuyData, // 净买入数据
              netInflowData, // 净流入数据
            },
          };
          console.log(this.todayFlowData);
        }
      });
    },
  },
};
</script>

<style lang="less" scoped>
@import '../assets/styles/mixin.less';
@import '../assets/styles/skin.less';
.temp {
  position: fixed;
  right: 0;
  bottom: 0;
  padding: 0.1rem;
  background-color: #fff;
}
.home {
  height: 100%;
  position: relative;

  .top-cards {
    .flex(row,space-between,flex-start,nowrap);
    height: 2.48rem;
    padding: 0 0.32rem;
    background-image: @background-top;
    &.fixed {
      margin-bottom: 0.88rem;
    }
    .card {
      .flex(column,flex-start,center,nowrap);
      width: 3.32rem;
      margin-top: 0.32rem;
      &.active {
        height: 1.9875rem;
        background-image: url('../assets/images/bg_top_card.png');
        background-repeat: no-repeat;
        background-size: 100%;
        .header {
          .flex(row,space-between,center,nowrap);
          width: calc(100% - 0.48rem);
          height: 0.44rem;
          margin: 0.18rem 0 0.16rem;
          .title {
            .flex(row,flex-start,center,nowrap);
            color: @font-white;
            font-family: PingFangSC-Regular;
            .main-title {
              font-size: 0.32rem;
              font-weight: 700;
            }
            .sub-title {
              font-size: 0.24rem;
              font-weight: 400;
            }
          }
          .label {
            min-width: 0.68rem;
            height: 0.3rem;
            padding: 0 0.06rem;
            border-radius: 0.06rem;
            font-family: PingFangSC-Regular;
            font-size: 0.2rem;
            color: @font-white;
            font-weight: 400;
            line-height: 0.32rem;
            background: @background-card-label-active;
            &.trade {
              background: @background-card-label-trade;
            }
          }
        }
        .desc {
          .flex(row,space-between,center,nowrap);
          width: calc(100% - 0.48rem);
          margin-bottom: 0.08rem;
          .desc-title {
            height: 0.36rem;
            font-family: PingFangSC-Regular;
            font-size: 0.26rem;
            color: @font-white-7;
            font-weight: 400;
            line-height: 0.36rem;
          }
          .desc-value {
            height: 0.36rem;
            font-family: THSMoneyfont-Medium;
            font-size: 0.28rem;
            color: @font-white;
            line-height: 0.36rem;
            font-weight: 500;
          }
        }
      }
      &.default {
        height: 1.78rem;
        background-color: @background-top-card;
        border-radius: 0.16rem;
        .header {
          .flex(row,space-between,center,nowrap);
          width: calc(100% - 0.48rem);
          height: 0.44rem;
          margin: 0.18rem 0 0.16rem;
          .title {
            .flex(row,flex-start,center,nowrap);
            color: @font-most-major;
            font-family: PingFangSC-Regular;
            .main-title {
              font-size: 0.32rem;
              font-weight: 700;
            }
            .sub-title {
              font-size: 0.24rem;
              font-weight: 400;
            }
          }
          .label {
            min-width: 0.68rem;
            height: 0.3rem;
            padding: 0 0.06rem;
            border-radius: 0.06rem;
            font-family: PingFangSC-Regular;
            font-size: 0.2rem;
            color: @font-white;
            font-weight: 400;
            line-height: 0.32rem;
            background: @background-card-label-default;
            &.trade {
              background: @background-card-label-trade;
            }
          }
        }
        .desc {
          .flex(row,space-between,center,nowrap);
          width: calc(100% - 0.48rem);
          margin-bottom: 0.08rem;
          .desc-title {
            height: 0.36rem;
            font-family: PingFangSC-Regular;
            font-size: 0.26rem;
            color: @font-major;
            font-weight: 400;
            line-height: 0.36rem;
          }
          .desc-value {
            height: 0.36rem;
            font-family: THSMoneyfont-Medium;
            font-size: 0.28rem;
            line-height: 0.36rem;
            font-weight: 500;
            color: @font-green;
            &.red {
              color: @font-red;
            }
          }
        }
      }
    }
  }
  .page {
    .module-tabs {
      .flex(row,flex-start,center,nowrap);
      width: 100%;
      height: 0.88rem;
      border-bottom: 0.01rem solid #eeeeee;
      background-color: @background-white;
      border-radius: 0.16rem 0.16rem 0 0;
      &.fixed {
        position: fixed;
        top: 0;
        z-index: 10;
      }
      .module-tab {
        position: relative;
        width: 1.875rem;
        height: 0.88rem;
        font-family: PingFangSC-Regular;
        font-size: 0.3rem;
        color: @font-major;
        text-align: center;
        line-height: 0.88rem;
        font-weight: 400;
        &.active {
          font-size: 0.32rem;
          color: @font-most-major;
          font-weight: 700;
          .active-bottom {
            position: absolute;
            left: 50%;
            bottom: 0.06rem;
            transform: translateX(-50%);
            width: 0.4rem;
            height: 0.08rem;
            background-color: @background-red;
            border-radius: 0.04rem;
          }
        }
      }
    }
  }
}
[theme-mode='black'] {
  .home {
    height: 100%;
    .top-cards {
      .flex(row,space-between,flex-start,nowrap);
      height: 2.48rem;
      padding: 0 0.32rem;
      background-image: @background-top-dark;
      &.fixed {
        margin-bottom: 0.88rem;
      }
      .card {
        .flex(column,flex-start,center,nowrap);
        width: 3.32rem;
        margin-top: 0.32rem;
        &.active {
          height: 1.9875rem;
          background-image: url('../assets/images/bg_top_card.png');
          background-repeat: no-repeat;
          background-size: 100%;
          .header {
            .flex(row,space-between,center,nowrap);
            width: calc(100% - 0.48rem);
            height: 0.44rem;
            margin: 0.18rem 0 0.16rem;
            .title {
              .flex(row,flex-start,center,nowrap);
              color: @font-white-dark;
              font-family: PingFangSC-Regular;
              .main-title {
                font-size: 0.32rem;
                font-weight: 700;
              }
              .sub-title {
                font-size: 0.24rem;
                font-weight: 400;
              }
            }
            .label {
              min-width: 0.68rem;
              height: 0.3rem;
              padding: 0 0.06rem;
              border-radius: 0.06rem;
              font-family: PingFangSC-Regular;
              font-size: 0.2rem;
              color: @font-white-dark;
              font-weight: 400;
              line-height: 0.32rem;
              background: @background-card-label-active-dark;
              &.trade {
                background: @background-card-label-trade-dark;
              }
            }
          }
          .desc {
            .flex(row,space-between,center,nowrap);
            width: calc(100% - 0.48rem);
            margin-bottom: 0.08rem;
            .desc-title {
              height: 0.36rem;
              font-family: PingFangSC-Regular;
              font-size: 0.26rem;
              color: @font-white-7-dark;
              font-weight: 400;
              line-height: 0.36rem;
            }
            .desc-value {
              height: 0.36rem;
              font-family: THSMoneyfont-Medium;
              font-size: 0.28rem;
              color: @font-white-dark;
              line-height: 0.36rem;
              font-weight: 500;
            }
          }
        }
        &.default {
          height: 1.78rem;
          background-color: @background-top-card-dark;
          border-radius: 0.16rem;
          .header {
            .flex(row,space-between,center,nowrap);
            width: calc(100% - 0.48rem);
            height: 0.44rem;
            margin: 0.18rem 0 0.16rem;
            .title {
              .flex(row,flex-start,center,nowrap);
              color: @font-most-major-dark;
              font-family: PingFangSC-Regular;
              .main-title {
                font-size: 0.32rem;
                font-weight: 700;
              }
              .sub-title {
                font-size: 0.24rem;
                font-weight: 400;
              }
            }
            .label {
              min-width: 0.68rem;
              height: 0.3rem;
              padding: 0 0.06rem;
              border-radius: 0.06rem;
              font-family: PingFangSC-Regular;
              font-size: 0.2rem;
              color: @font-white-dark;
              font-weight: 400;
              line-height: 0.32rem;
              background: @background-card-label-default-dark;
              &.trade {
                background: @background-card-label-trade-dark;
              }
            }
          }
          .desc {
            .flex(row,space-between,center,nowrap);
            width: calc(100% - 0.48rem);
            margin-bottom: 0.08rem;
            .desc-title {
              height: 0.36rem;
              font-family: PingFangSC-Regular;
              font-size: 0.26rem;
              color: @font-major-dark;
              font-weight: 400;
              line-height: 0.36rem;
            }
            .desc-value {
              height: 0.36rem;
              font-family: THSMoneyfont-Medium;
              font-size: 0.28rem;
              line-height: 0.36rem;
              font-weight: 500;
              color: @font-green-dark;
              &.red {
                color: @font-red-dark;
              }
            }
          }
        }
      }
    }
    .page {
      .module-tabs {
        .flex(row,flex-start,center,nowrap);
        height: 0.88rem;
        width: 100%;
        border-bottom: 0.01rem solid #2e2e2e;
        background-color: @background-white-dark;
        border-radius: 0.16rem 0.16rem 0 0;
        &.fixed {
          position: fixed;
          top: 0;
          z-index: 1;
        }
        .module-tab {
          position: relative;
          width: 1.875rem;
          height: 0.88rem;
          font-family: PingFangSC-Regular;
          font-size: 0.3rem;
          color: @font-major-dark;
          text-align: center;
          line-height: 0.88rem;
          font-weight: 400;
          &.active {
            font-size: 0.32rem;
            color: @font-most-major-dark;
            font-weight: 700;
            .active-bottom {
              position: absolute;
              left: 50%;
              bottom: 0.06rem;
              transform: translateX(-50%);
              width: 0.4rem;
              height: 0.08rem;
              background-color: @background-red-dark;
              border-radius: 0.04rem;
            }
          }
        }
      }
    }
  }
}
// 解决安卓字体比ios字体偏大问题。
[theme-platform='iphone'] {
  .label {
    padding: 0 0.08rem !important;
    line-height: 0.3rem !important;
  }
}
</style>
