<template>
  <div class="history-data-page" @scroll="getMoreData">
      <div class="list-header">
          <div class="col1">日期</div>
          <div class="col2">{{pageType === 'north' ? '沪股通' : '港股通(沪)'}}</div>
          <div class="col3">{{pageType === 'north' ? '深股通' : '港股通(深)'}}</div>
          <div class="col4">合计</div>
      </div>
      <div class="list-content">
          <template v-for="(item,index) in historyList">
                <div 
                    class="list-item"
                    :key="index"
                >
                    <div class="col1">{{item.date}}</div>
                    <div class="col2" :class="{'red': item.hgt >=0 }">{{item.hgt | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                    <div class="col3" :class="{'red': item.sgt >=0 }">{{item.sgt | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                    <div class="col4" :class="{'red': item.total >=0 }">{{item.total | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                </div>
          </template>
      </div>
      <div class="list-bottom" v-if="historyList.length === total">已加载全部</div>
  </div>
</template>
<script>
import {getHistoryData} from '@/apis';
export default {
  name: 'Historydatapage',
  mounted() {
      this.handleGetHistoryData();
  },
  data() {
    return {
       historyList: [], // 历史数据列表
       pageIndex: 1,
       pageSize: 100,
       total: null,
       bottomLoading: false,
       pageType: this.$route.query.pageType
    };
  },
  methods: {
    // 获取历史数据
    handleGetHistoryData () {
        this.bottomLoading = true;
        getHistoryData(this.pageType,this.pageIndex,this.pageSize).then((res)=>{
            if (res.status_code === 0) {
                this.total = res.data.total;
                res.data.list.forEach((item,index)=>{
                    this.historyList.push({
                        date: item.trade_date,
                        hgt: item.sh_net_buy/100000000,
                        sgt: item.sz_net_buy/100000000,
                        total: item.total_net_buy/100000000
                    });
                });
            }
        });
        setTimeout(()=>{
            this.bottomLoading = false;
        },100); // 节流
    },
    // 滚动加载更多
    getMoreData (e) {
        const {scrollTop, clientHeight, scrollHeight} = e.target;
        // 加载更多的条件：滚动到了底部、当前不是正在加载中、没有获取全部数据
        if (scrollTop + clientHeight + 300 >= scrollHeight && !this.bottomLoading && this.historyList.length < this.total) {
            this.pageIndex += 1;
            this.handleGetHistoryData();
        }
    }
  }
};
</script>
<style lang="less" scoped>
@import '../assets/styles/mixin.less';
@import '../assets/styles/skin.less';
.history-data-page {
    .flex(column,flex-start,center,nowrap);
    width: 100%;
    height: 100%;
    border-radius: 0.16rem;
    background-color: @background-white;
    overflow-y: auto;
    .list-header {
        .flex(row,flex-start,center,nowrap);
        position: fixed;
        top: 0;
        z-index: 1;
        width: calc(100% - 0.64rem);
        padding: 0 0.64rem;
        height: 0.74rem;
        font-family: PingFangSC-Regular;
        font-size: 0.28rem;
        color: @font-general-major;
        font-weight: 400;
        background-color: @background-white;
        // border-bottom: 0.01rem solid @line-gray;
        .col1 {
            width: 2.2rem;
            text-align: left;
        }
        .col2 {
            width: 1.32rem;
            text-align: right;
        }
        .col3 {
            width: 1.68rem;
            text-align: right;
        }
        .col4 {
            width: 1.68rem;
            text-align: right;
        }
    }
    .list-content {
        width: calc(100% - 0.64rem);
        margin-top: 0.74rem;
        .list-item {
            .flex(row,flex-start,center,nowrap);
            width: 100%;
            min-height: 0.96rem;
            font-family: THSMoneyfont-Medium;
            font-size: 0.32rem;
            font-weight: 500;
            border-bottom: 0.01rem solid @line-gray;
            &:first-child {
                border-top: 0.01rem solid @line-gray;
            }
            .col1 {
                width: 2.2rem;
                text-align: left;
                color: @font-most-major;
            }
            .col2 {
                width: 1.32rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
            .col3 {
                width: 1.68rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
            .col4 {
                width: 1.68rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
        }
        
    }
    .list-bottom {
        width: 100%;
        height:0.96rem;
        line-height: 0.96rem;
        color: @font-general-major;
        font-size: 0.28rem;
        text-align: center;
    }
}
[theme-mode="black"] {
    .history-data-page {
        .flex(column,flex-start,center,nowrap);
        width: 100%;
        height: 100%;
        margin-bottom: 0.4rem;
        border-radius: 0.16rem;
        background-color: @background-white-dark;
        overflow-y: auto;
        .list-header {
            .flex(row,flex-start,center,nowrap);
            position: fixed;
            top: 0;
            z-index: 1;
            width: calc(100% - 0.64rem);
            padding: 0 0.64rem;
            height: 0.74rem;
            font-family: PingFangSC-Regular;
            font-size: 0.28rem;
            color: @font-general-major-dark;
            font-weight: 400;
            background-color: @background-white-dark;
            .col1 {
                width: 2.2rem;
                text-align: left;
            }
            .col2 {
                width: 1.32rem;
                text-align: right;
            }
            .col3 {
                width: 1.68rem;
                text-align: right;
            }
            .col4 {
                width: 1.68rem;
                text-align: right;
            }
        }
        .list-content {
            width: calc(100% - 0.64rem);
            margin-top: 0.74rem;
            .list-item {
                .flex(row,flex-start,center,nowrap);
                width: 100%;
                min-height: 0.96rem;
                font-family: THSMoneyfont-Medium;
                font-size: 0.32rem;
                font-weight: 500;
                border-bottom: 0.01rem solid @line-gray-dark;
                 &:first-child {
                    border-top: 0.01rem solid @line-gray-dark;
                }
                .col1 {
                    width: 2.2rem;
                    text-align: left;
                    color: @font-most-major-dark;
                }
                .col2 {
                    width: 1.32rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red-dark;
                    }
                }
                .col3 {
                    width: 1.68rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red-dark;
                    }
                }
                .col4 {
                    width: 1.68rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red-dark;
                    }
                }
            }
            
        }
        .list-bottom {
            width: 100%;
            height:0.96rem;
            line-height: 0.96rem;
            color: @font-general-major-dark;
            font-size: 0.28rem;
            text-align: center;
        }
    }
}
</style>
