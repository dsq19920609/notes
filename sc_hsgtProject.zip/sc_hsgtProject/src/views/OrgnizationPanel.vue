<template>
  <div class="orgnization-panel">
    <div :class="fixed">
      <RadioBox :type="3" @change="radioChange"></RadioBox>
    </div>
    <TableList
      @tr-click="trClick"
      @thClick="thClick"
      :fixedTab="fixedTab"
      :isLoading="bottomLoading"
      ref="tableList"
      :thead="thead"
      :class="tableListClass"
      :defaultSortField="defaultSortField"
      :list="list"
    ></TableList>
  </div>
</template>

<script>
import TableList from '@/components/TableList.vue';
import RadioBox from '@/components/RadioBox.vue';
import req from '@/apis/http.js';
import config from '@/config';
import { mapState, mapMutations } from 'vuex';
import theadObj from '@/lib/theadObj.js';
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
// 默认排序字段
const defaultSortField = {
  1: 'cal_profit_amount',
  2: 'sum_buy_amount',
  3: 'continue_increase_days',
};
export default {
  data() {
    return {
      // 筛选选项
      radioId: 1,
      // 请求参数
      type: 'profit',
      reqUrl: '/broker/get_broker_stat_info',
      sliderVisible: false,
      // 表头
      thead: [],
      // 表格数据
      list: [],
      pageIndex: 1,
      pageSize: 20,
      // 排序字段
      sortField: '',
      // 排序类型
      sortMode: '',
      bottomLoading: false,
      total: 0,
      startDate: '',
      endDate: '',
      // 默认排序字段
      defaultSortField: '',
    };
  },
  computed: {
    ...mapState(['fixedTab']),
    fixed() {
      return [this.fixedTab ? 'fixed' : ''];
    },
    tableListClass() {
      return [this.fixedTab ? 'table-fixed' : ''];
    },
  },
  watch: {
    radioId() {
      this.list = [];
      this.sortField = '';
      this.sortMode = '';
      this.$refs.tableList.initSort();
      this.setThead();
      this.getData();
    },
  },
  components: {
    TableList,
    RadioBox,
  },
  methods: {
    ...mapMutations(['setFixedTab']),
    sliderChange(startDate, endDate) {
      this.startDate = startDate;
      this.endDate = endDate;
      this.getData();
    },
    // 滚动加载更多
    getMoreData(e) {
      const { scrollTop, clientHeight, scrollHeight } = e.target;
      // 加载更多的条件：滚动到了底部、当前不是正在加载中、没有获取全部数据
      if (
        scrollTop + clientHeight + 300 >= scrollHeight &&
        !this.bottomLoading &&
        this.list.length < this.total
      ) {
        this.pageIndex += 1;
        this.getData(true);
      }
    },
    setThead() {
      if (this.radioId == 1) {
        this.thead = theadObj.north.getProfit();
      } else if (this.radioId == 2) {
        this.thead = theadObj.north.getFund();
      } else {
        this.thead = theadObj.north.getContinue();
      }
      this.defaultSortField = defaultSortField[this.radioId];
    },
    trClick(item) {
      window.location.href = `${config.url.organDetailLink}?brokercode=${item.border_code}`;
      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      window.hxmClickStat(`hsgt.${type}.jg.djgp`);
    },
    thClick(item, sortType) {
      if (sortType == 'up') {
        this.sortMode = 'asc';
      } else {
        this.sortMode = 'desc';
      }
      this.sortField = item.key;
      this.list = [];
      this.getData();
    },
    radioChange(item) {
      this.radioId = item.id;
      this.type = item.type;
      this.sortMode = '';
      this.sortField = '';
      const type = this.pageType == 'north' ? 'lgt' : 'ggt';

      const radioIdMap = {
        1: 'ylzq',
        2: 'zjzq',
        3: 'lxzc',
      };
      window.hxmClickStat(`hsgt.${type}.jg.bd.${radioIdMap[item.id]}`);
    },
    dateRangeChange(v, startDate, endDate) {
      this.list = [];
      this.dateId = v;
      // 单日历选择
      if (v == 1) {
        this.sliderVisible = false;
        this.startDate = startDate;
        this.getData();
      } else if (v == 5 && this.startDate) {
        // 范围选择
        this.sliderVisible = true;
        this.startDate = startDate;
        this.endDate = endDate;
      } else if (v == 5 && !this.startDate) {
        // 只展示slider，不筛选
        this.sliderVisible = true;
        this.getData();
      } else {
        this.sliderVisible = false;
        this.getData();
      }
    },
    getDate(v) {
      return `${v.toString().substr(4, 2)}-${v.toString().substr(6, 2)}`;
    },
    // 请求数据
    getData(nextPage = false) {
      this.bottomLoading = true;
      let url = '';
      url = `${config.api.interface + this.reqUrl}?type=${this.type}&sort_field=${
        this.sortField
      }&sort_mode=${this.sortMode}&page_index=${this.pageIndex}&page_size=${this.pageSize}`;
      if (!nextPage && this.fixedTab) {
        // document.documentElement.scrollTop = 120;
        window.scrollTo(0, 124 * pageRate * dpr);
      }
      req('get', url, '')
        .then(res => {
          if (res.status_code == 0) {
            this.list = this.list.concat(res.data.list);
            this.total = res.data.total;
          }
          this.bottomLoading = false;
        })
        .catch(() => {
          this.bottomLoading = false;
        });
    },
    organScroll(e) {
      const { scrollTop, clientHeight, scrollHeight } = e.target.documentElement;
      if (
        scrollTop + clientHeight + 300 >= scrollHeight &&
        !this.bottomLoading &&
        this.list.length < this.total
      ) {
        this.pageIndex += 1;
        this.getData(true);
      }
    },
  },
  mounted() {
    this.setThead();
    this.getData();
    window.addEventListener('scroll', this.organScroll);
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.organScroll);
  },
};
</script>
<style lang="less">
.orgnization-panel {
  background: #ffffff;
  min-height: 100vh;
  overflow-x: hidden;
  position: relative;
  .fixed {
    position: fixed;
    top: 0.86rem;
    z-index: 10;
    width: 100%;
    background: #ffffff;
  }
  .table-list.table-fixed {
    margin-top: 1.12rem;
    .table-thead-fixed {
      position: fixed;
      top: 2rem;
      border-top: 0.01rem solid rgba(232, 232, 232, 1);
      z-index: 10;
    }
    .table-column-thead {
      top: 2.02rem;
    }
    .right-white {
      top: 2rem;
    }
  }
}
[theme-mode='black'] {
  .orgnization-panel {
    background: #121212;
    .fixed {
      background: #121212;
    }
    .table-list.table-fixed {
      .table-thead-fixed {
        border-top: 0.01rem solid rgba(46, 46, 46, 1);
      }
    }
  }
}
</style>
