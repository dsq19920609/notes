<template>
  <div class="blocks-panel" ref="blocksPanel">
    <div :class="fixed">
      <RadioBox @change="radioChange" :type="4"></RadioBox>
      <DateRangeBox
        v-model="dateId"
        :tradeList="tradeList"
        @change="dateRangeChange"
      ></DateRangeBox>
      <!-- <div class="border-bottom"></div> -->
    </div>
    <TreeMap :class="treeMapClass" :list="treeMapList"></TreeMap>
    <TableList
      ref="tableList"
      @tr-click="trClick"
      @thClick="thClick"
      :fixedTab="tableFixed"
      :class="tableListClass"
      :isLoading="bottomLoading"
      :thead="thead"
      :list="list"
      :defaultSortField="defaultSortField"
      :defaultSortMode="defaultSortMode"
    ></TableList>
    <SliderBox
      ref="slider"
      @change="sliderChange"
      :tradeList="tradeList"
      v-show="sliderVisible"
    ></SliderBox>
  </div>
</template>

<script>
import SliderBox from '@/components/SliderBox.vue';
import RadioBox from '@/components/RadioBox.vue';
import DateRangeBox from '@/components/DateRangeBox.vue';
import TableList from '@/components/TableList.vue';
import TreeMap from '@/components/TreeMap.vue';
import req from '@/apis/http.js';
import config from '@/config';
import { getDateCalendar } from '@/apis/index';
import { mapState, mapMutations } from 'vuex';
import theadObj from '@/lib/theadObj.js';
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
const dateMap = {
  1: 'one',
  2: 'five',
  3: 'twenty',
  4: 'sixty',
  5: 'any',
};
export default {
  data() {
    return {
      scrollTop: 0,
      // 交易日日期列表
      tradeList: [],
      // 1 流入 2流出
      radioId: 1,
      reqUrl: '/concept/get_concept_list',
      // 日期范围选择类型
      dateId: 1,
      sliderVisible: false,
      // 表头
      thead: [],
      // 表格数据
      list: [],
      pageIndex: 1,
      pageSize: 20,
      // 排序字段
      sortField: '',
      // 排序类型
      sortMode: '',
      bottomLoading: false,
      total: 0,
      startDate: '',
      endDate: '',
      // 树图数据是否可用，不可用就更新
      treeMapValid: false,
      // 传入树图的数据
      treeMapList: [],
      defaultSortField: 'inflow',
      defaultSortMode: 'down',
    };
  },
  computed: {
    ...mapState(['fixedTab']),
    fixed() {
      return [this.fixedTab ? 'fixed' : ''];
    },
    treeMapClass() {
      return [this.fixedTab ? 'tree-map-fixed' : ''];
    },
    tableListClass() {
      return [this.scrollTop >= 320 * dpr * pageRate ? 'table-fixed' : ''];
    },
    tableFixed() {
      return this.scrollTop >= 320 * dpr * pageRate ? true : false;
    },
  },
  watch: {
    dateId(v) {
      if (v == 5) {
        this.sliderVisible = true;
      } else {
        this.sliderVisible = false;
      }
    },
    radioId(v) {
      this.list = [];
      if (v == 1) {
        this.sortMode = 'desc';
        this.defaultSortMode = 'down';
      } else {
        this.sortMode = 'asc';
        this.defaultSortMode = 'up';
      }
      this.sortField = 'inflow';
      this.$refs.tableList.initSort();
      this.$refs.slider.init();
      this.treeMapValid = false;
      this.setThead();
      this.getData();
      this.defaultSortField = '';
      this.$nextTick(() => {
        this.defaultSortField = 'inflow';
      });
    },
  },
  components: {
    SliderBox,
    DateRangeBox,
    TableList,
    TreeMap,
    RadioBox,
  },
  methods: {
    ...mapMutations(['setFixedTab']),
    sliderChange(startDate, endDate) {
      this.startDate = startDate;
      this.endDate = endDate;
      this.list = [];
      this.treeMapValid = false;
      this.getData();
    },
    setThead() {
      const vm = this;
      this.thead = theadObj.north.getBlocks(vm);
    },
    trClick(item) {
      const dateStr = this.tradeList[this.tradeList.length - 1];
      const date = `${dateStr.substr(0, 4)}-${dateStr.substr(4, 2)}-${dateStr.substr(6, 2)}`;
      window.location.href = `${config.url.blockDetailLink}?tab=0&code=${item.code}&date=${date}`;

      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      window.hxmClickStat(`hsgt.${type}.bk.djgp`);
    },
    // 排序处理
    thClick(item, sortType) {
      if (sortType == 'up') {
        this.sortMode = 'asc';
      } else {
        this.sortMode = 'desc';
      }
      this.sortField = item.key;
      this.list = [];
      this.getData(false, this.scrollTop);
    },
    // 获取交易日列表
    getTradeDayList() {
      getDateCalendar('north').then(res => {
        if (res.status_code === 0) {
          this.tradeList = res.data;
        }
      });
    },
    radioChange(item) {
      this.radioId = item.id;
      this.dateId = 1;
    },
    dateRangeChange(v, startDate) {
      this.treeMapValid = false;
      // 单日历选择
      if (v == 1) {
        this.list = [];
        this.sliderVisible = false;
        this.startDate = startDate;
        this.$refs.slider.init();
        this.getData();
      } else if (v == 5) {
        // 只展示slider，不筛选
        this.sliderVisible = true;
        // this.getData();
      } else {
        this.list = [];
        this.sliderVisible = false;
        this.$refs.slider.init();
        this.getData();
      }

      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      if (v == 1) {
        window.hxmClickStat(`hsgt.${type}.bk.sjxz`);
      } else {
        const dateIdMap = {
          2: '5',
          3: '20',
          4: '60',
          5: 'zdy',
        };
        window.hxmClickStat(`hsgt.${type}.bk.qjxz.${dateIdMap[v]}`);
      }
    },
    getDate(v) {
      return `${v.toString().substr(4, 2)}-${v.toString().substr(6, 2)}`;
    },
    // 请求数据
    getData(nextPage = false, scrollTop = 0) {
      this.bottomLoading = true;
      let url = '';
      if (this.dateId == 1) {
        url = `${config.api.interface + this.reqUrl}?flow=${
          this.radioId
        }&query_type=one&start_date=${this.startDate}`;
      } else if (this.dateId == 5) {
        url = `${config.api.interface + this.reqUrl}?flow=${
          this.radioId
        }&query_type=any&start_date=${this.startDate}&end_date=${this.endDate}`;
      } else {
        url = `${config.api.interface + this.reqUrl}?flow=${this.radioId}&query_type=${
          dateMap[this.dateId]
        }`;
      }

      url += `&page_index=${this.pageIndex}&page_size=${this.pageSize}`;

      if (this.sortField) {
        url += `&sort_field=${this.sortField}&sort_mode=${this.sortMode}`;
      }

      if (!nextPage && this.fixedTab) {
        // document.documentElement.scrollTop = 120;
        window.scrollTo(0, 124 * pageRate * dpr);
      }

      req('get', url, '')
        .then(res => {
          if (res.status_code == 0) {
            this.list = this.list.concat(res.data.list);
            this.total = res.data.total;
          }
          if (scrollTop) {
            setTimeout(() => {
              this.$refs.blocksPanel.scrollTop = scrollTop;
            });
          }
          this.bottomLoading = false;
          if (!nextPage && !this.treeMapValid) {
            this.treeMapList = [];
            for (let i = 0; i < 10; i++) {
              const item = {
                name: res.data.list[i].name,
                showValue: res.data.list[i].inflow,
                value: Math.abs(res.data.list[i].inflow),
                change: res.data.list[i].change,
              };
              this.treeMapList.push(item);
            }
            this.treeMapValid = true;
          }
        })
        .catch(() => {
          this.bottomLoading = false;
          this.treeMapList = [];
        });
    },
    blocksScroll(e) {
      const { scrollTop, clientHeight, scrollHeight } = e.target.documentElement;
      this.scrollTop = scrollTop;
      if (
        scrollTop + clientHeight + 300 >= scrollHeight &&
        !this.bottomLoading &&
        this.list.length < this.total
      ) {
        this.pageIndex += 1;
        this.getData(true);
      }
    },
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.blocksScroll);
  },
  mounted() {
    this.getTradeDayList();
    this.setThead();

    window.addEventListener('scroll', this.blocksScroll);
  },
};
</script>
<style lang="less">
.border-bottom {
  border-bottom: 0.01rem solid rgba(232, 232, 232, 1);
  height: 0.01rem;
  margin: 0 0.32rem;
}
.blocks-panel {
  background: #ffffff;
  overflow-x: hidden;
  min-height: 100vh;
  position: relative;
  .fixed {
    position: fixed;
    top: 0.88rem;
    z-index: 10;
    background: #ffffff;
    width: 100vw;
  }
  .tree-map.tree-map-fixed {
    margin-top: 1.86rem;
  }
  .table-list {
    border-top: none;
  }
  .table-list.table-fixed {
    .table-thead-fixed {
      position: fixed;
      top: 2.73rem;
      border-top: 0.01rem solid rgba(232, 232, 232, 1);
      z-index: 10;
    }
    .table-column-thead {
      top: 2.74rem;
    }
    .right-white {
      top: 2.73rem;
    }
  }
}

[theme-mode='black'] {
  .border-bottom {
    border-bottom: 0.01rem solid rgba(46, 46, 46, 1);
  }
  .blocks-panel {
    background: #121212;
    .fixed {
      background: #121212;
    }
    .table-list {
      border-top: none;
    }
    .table-list.table-fixed {
      .table-thead-fixed {
        border-top: 0.01rem solid rgba(46, 46, 46, 1);
      }
    }
  }
}
</style>
