<template>
  <div class="stocks-panel">
    <div :class="fixed">
      <RadioBox @change="radioChange"></RadioBox>
      <DateRangeBox
        v-show="radioId != 5"
        v-model="dateId"
        :tradeList="realTradeList"
        @change="dateRangeChange"
      ></DateRangeBox>
    </div>
    <TableList
      ref="tableList"
      @tr-click="trClick"
      @thClick="thClick"
      :isLoading="bottomLoading"
      :fixedTab="fixedTab"
      :thead="thead"
      :class="tableListClass"
      :defaultSortField="defaultSortField"
      :list="list"
    ></TableList>
    <template v-if="radioId == 1">
      <div class="stocks-bottom" v-if="pageType == 'north'">
        榜单数据取自「北向资金沪市十大成交股」「北向资金深市十大成交股」，由同花顺进行合并排序，每个交易日收盘后18点更新
      </div>
      <div class="stocks-bottom" v-else>
        榜单数据取自「南向资金沪市十大成交股」「南向资金深市十大成交股」，由同花顺进行合并排序，每个交易日收盘后18点更新
      </div>
    </template>
    <SliderBox
      ref="slider"
      @change="sliderChange"
      :tradeList="realTradeList"
      v-show="sliderVisible"
    ></SliderBox>
  </div>
</template>

<script>
import SliderBox from '@/components/SliderBox.vue';
import RadioBox from '@/components/RadioBox.vue';
import DateRangeBox from '@/components/DateRangeBox.vue';
import TableList from '@/components/TableList.vue';
import req from '@/apis/http.js';
import config from '@/config';
import { getDateCalendar, getTopTenDateCalendar } from '@/apis/index';
import { mapState, mapMutations } from 'vuex';
import theadObj from '@/lib/theadObj.js';
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
const dateMap = {
  1: 'one',
  2: 'five',
  3: 'twenty',
  4: 'sixty',
  5: 'any',
};
// 默认排序字段
const defaultSortField = {
  1: 'total_amount',
  2: 'net_buy_amount',
  3: 'net_sell_amount',
  4: 'add_hold_percentage',
  5: 'calc_hold_market_value',
  6: 'net_buy_amount',
};
export default {
  data() {
    return {
      tradeList: [],
      topTenTradeList: [],
      // 使用的交易日列表，根据是否是十大成交榜变化
      realTradeList: [],
      radioId: 1,
      reqUrl: '/stock/top_ten_data/get_list',
      dateId: 1,
      sliderVisible: false,
      thead: [],
      list: [],
      pageIndex: 1,
      pageSize: 20,
      sortField: '',
      bottomLoading: false,
      total: 0,
      sortMode: '',
      startDate: '',
      endDate: '',
      timer: null,
      defaultSortField: '',
      selfStockList: [],
    };
  },
  props: {
    pageType: {
      type: String,
      default: 'north',
    },
  },
  computed: {
    ...mapState(['fixedTab']),
    fixed() {
      return [this.fixedTab ? 'fixed' : ''];
    },
    tableListClass() {
      if (this.radioId == 5) {
        return [this.fixedTab ? 'table-fixed2' : ''];
      } else {
        return [this.fixedTab ? 'table-fixed' : ''];
      }
    },
  },
  watch: {
    dateId(v) {
      if (v == 5) {
        this.sliderVisible = true;
      } else {
        this.sliderVisible = false;
      }
    },
    radioId(v, ov) {
      this.list = [];
      this.pageIndex = 1;
      this.sortField = '';
      this.sortMode = '';
      this.dateId = 1;
      this.$refs.slider.init();
      this.$refs.tableList.initSort();
      this.setThead();
      if (v == 1) {
        this.realTradeList = this.topTenTradeList;
      } else {
        this.realTradeList = this.tradeList;
      }
      if (v != 1 && ov != 1) {
        this.getData();
      }
    },
  },
  components: {
    SliderBox,
    RadioBox,
    DateRangeBox,
    TableList,
  },
  methods: {
    ...mapMutations(['setFixedTab']),
    stockScroll(e) {
      const { scrollTop, clientHeight, scrollHeight } = e.target.documentElement;
      if (
        scrollTop + clientHeight + 300 >= scrollHeight &&
        !this.bottomLoading &&
        this.list.length < this.total
      ) {
        this.pageIndex += 1;
        this.getData(true);
      }
    },
    trClick(item) {
      window.location.href = `${config.url.stockDetailLink}?market=hs&code=${
        item.security_code || item.code
      }`;
      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      window.hxmClickStat(`hsgt.${type}.gegu.djgp`);
    },
    sliderChange(startDate, endDate) {
      this.startDate = startDate;
      this.endDate = endDate;
      this.list = [];
      this.pageIndex = 1;
      this.getData();
    },
    // 设置表头
    setThead() {
      const vm = this;
      switch (this.radioId) {
      case 1:
        this.thead = theadObj[this.pageType].getTopTen(vm, this.dateId);
        break;
      case 2:
        this.thead = theadObj[this.pageType].getBuy(vm);
        break;
      case 3:
        this.thead = theadObj[this.pageType].getSell(vm);
        break;
      case 4:
        this.thead = theadObj[this.pageType].getAddHold(vm);
        break;
      case 5:
        this.thead = theadObj[this.pageType].getHeavyPosition(vm);
        break;
      case 6:
        this.thead = theadObj[this.pageType].getSelfStock(vm);
        break;
      default:
        break;
      }

      if (this.radioId == 1 && this.dateId != 1) {
        this.defaultSortField = 'range_net_buy_amount';
      } else {
        this.defaultSortField = defaultSortField[this.radioId];
      }
    },
    thClick(item, sortType) {
      if (sortType == 'up') {
        this.sortMode = 'asc';
      } else {
        this.sortMode = 'desc';
      }
      this.sortField = item.key;
      this.list = [];
      this.pageIndex = 1;
      this.getData();
    },
    getTradeDayList() {
      getDateCalendar(this.pageType).then(res => {
        if (res.status_code === 0) {
          this.tradeList = res.data;
        }
      });
      getTopTenDateCalendar(this.pageType).then(res => {
        if (res.status_code === 0) {
          this.topTenTradeList = res.data;
          this.realTradeList = this.topTenTradeList;
        }
      });
    },
    radioChange(item) {
      this.reqUrl = item.url;
      this.radioId = item.id;

      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      const taMap = {
        1: 'sdcjb',
        2: 'jmr',
        3: 'jmc',
        4: 'zcbl',
        5: 'zcgp',
        6: 'zxg',
      };
      window.hxmClickStat(`hsgt.${type}.gegu.bd.${taMap[item.id]}`);
    },
    // 日期范围更改
    dateRangeChange(v, startDate) {
      this.dateId = v;
      this.setThead();
      // 单日历选择
      if (v == 1) {
        this.list = [];
        this.pageIndex = 1;
        this.sliderVisible = false;
        this.startDate = startDate;
        this.$refs.slider.init();
        this.getData();
      } else if (v == 5) {
        // 只展示slider，不筛选
        this.sliderVisible = true;
      } else {
        this.list = [];
        this.pageIndex = 1;
        this.sliderVisible = false;
        this.$refs.slider.init();
        this.getData();
      }
      const type = this.pageType == 'north' ? 'lgt' : 'ggt';
      if (v == 1) {
        window.hxmClickStat(`hsgt.${type}.gegu.sjxz`);
      } else {
        const dateIdMap = {
          2: '5',
          3: '20',
          4: '60',
          5: 'zdy',
        };
        window.hxmClickStat(`hsgt.${type}.gegu.qjxz.${dateIdMap[v]}`);
      }
    },
    getDate(v) {
      return `${v.toString().substr(4, 2)}-${v.toString().substr(6, 2)}`;
    },
    // 获取自选股接口
    getSelfStock() {
      const body = {
        type: this.pageType,
        query_type: dateMap[this.dateId],
        stock_code_list: this.selfStockList,
        start_date: this.startDate,
        end_date: this.endDate,
        sort_field: this.sortField,
        sort_mode: this.sortMode,
        page_index: this.pageIndex,
        page_size: this.pageSize,
      };
      req('post', `${config.api.interface + this.reqUrl}`, '', body).then(res => {
        if (res.status_code == 0) {
          this.list = res.data.list;
          this.total = res.data.total;
        }
        this.bottomLoading = false;
      }).catch(() => {
        this.bottomLoading = false;
      });
    },
    setList(url) {
      req('get', url, '')
        .then(res => {
          if (res.status_code == 0) {
            if (window.getAppVersion()) {
              const stockList = [];
              const marketList = [];
              for (let i = 0; i < res.data.list.length; i++) {
                const item = res.data.list[i];
                stockList.push(item.security_code || item.stock_code);
                marketList.push(item.thsmarket_code_hq);
              }

              const param = {
                columOrder: ['10', '34818'], // 现价 涨跌幅  股票名称
                stockList, //股票代码
                marketList, //市场id
              };
              window.webHQData.initWebHQ(param, data => {
                if (data['34818']) {
                  for (let i = 0; i < res.data.list.length; i++) {
                    const item = res.data.list[i];
                    // item.stock_name = data['59'][i];
                    if (this.radioId == 5) {
                      item.rate = Number(data['34818'][i].substr(0, data['34818'][i].length - 1));
                    }
                  }
                }
                if (this.list.length < res.data.total) {
                  this.list = this.list.concat(res.data.list);
                }
                this.total = res.data.total;
                this.bottomLoading = false;
              });
            } else {
              this.list = this.list.concat(res.data.list);
              this.total = res.data.total;
              this.bottomLoading = false;
            }

            for (let i = 0; i < this.list.length; i++) {
              if (!this.list[i].data_all_update) {
                if (this.pageType == 'north') {
                  this.$set(this.list[i], 'hold_trable_calc_percentage', '次日4点更新');
                } else {
                  this.$set(this.list[i], 'hold_trable_calc_percentage', 'T+3日4点更新');
                }
              }
            }
          }
        })
        .catch(() => {
          this.bottomLoading = false;
        });
    },
    // 请求数据
    getData(nextPage = false) {
      this.bottomLoading = true;
      if (this.radioId == 6) {
        if (window.getAppVersion()) {
          window.callNativeHandler(
            'selfCodeAction', //必填
            { action: 'getAllStocks' }, //必填
            res => {
              console.log(res);
              //必填
              if (res.state == 30) {
                this.selfStockList = [];
                res.selfCodeList.forEach(item => {
                  this.selfStockList.push(item.stockcode);
                });
                this.getSelfStock();
              }
            }
          );
        } else {
          setTimeout(() => {
            this.selfStockList = ['300033', '1A0001', '03333'];
            this.getSelfStock();
          });
        }
      } else {
        let url = '';
        if (this.dateId == 1) {
          url = `${config.api.interface + this.reqUrl}?type=${
            this.pageType
          }&query_type=one&start_date=${this.startDate}&sort_field=${this.sortField}&sort_mode=${
            this.sortMode
          }&page_index=${this.pageIndex}&page_size=${this.pageSize}`;
        } else if (this.dateId == 5) {
          url = `${config.api.interface + this.reqUrl}?type=${
            this.pageType
          }&query_type=any&start_date=${this.startDate}&end_date=${this.endDate}&sort_field=${
            this.sortField
          }&sort_mode=${this.sortMode}&page_index=${this.pageIndex}&page_size=${this.pageSize}`;
        } else {
          url = `${config.api.interface + this.reqUrl}?type=${this.pageType}&query_type=${
            dateMap[this.dateId]
          }&sort_field=${this.sortField}&sort_mode=${this.sortMode}&page_index=${
            this.pageIndex
          }&page_size=${this.pageSize}`;
        }
        if (!nextPage && this.fixedTab) {
          // document.documentElement.scrollTop = 120;
          window.scrollTo(0, 124 * pageRate * dpr);
        }
        this.setList(url);
      }
    },
    getHq() {
      console.log(window.getAppVersion());
      if (window.getAppVersion()) {
        const stockList = [];
        const marketList = [];
        for (let i = 0; i < this.list.length; i++) {
          const item = this.list[i];
          stockList.push(item.security_code || item.stock_code);
          marketList.push(item.thsmarket_code_hq);
        }

        const param = {
          columOrder: ['10', '34818'], // 现价 涨跌幅  股票名称
          stockList, //股票代码
          marketList, //市场id
        };
        console.log(param);
        window.webHQData.initWebHQ(param, data => {
          console.log(data);
          if (data['34818']) {
            for (let i = 0; i < this.list.length; i++) {
              this.$set(
                this.list[i],
                'rate',
                Number(data['34818'][i].substr(0, data['34818'][i].length - 1))
              );
            }
          }
        });
      }
    },
  },
  mounted() {
    this.getTradeDayList();
    this.setThead();

    window.addEventListener('scroll', this.stockScroll);
    this.timer = setInterval(() => {
      console.log('timer');
      if (this.radioId == 5) {
        this.getHq();
      }
    }, 30000);
  },
  beforeDestroy() {
    clearInterval(this.timer);
    window.removeEventListener('scroll', this.stockScroll);
  },
};
</script>

<style lang="less">
.th-type-code {
  text-align: left;
  font-size: 0.24rem;
  line-height: 0.32rem;
  color: #999999;
  padding-top: 0.07rem;
}
// 机构名称
.td-type-name {
  text-align: left;
  font-size: 0.3rem;
  line-height: 0.4rem;
  max-width: 2.54rem;
  word-break: break-all;
  white-space: normal;
  overflow: hidden;
  text-overflow: ellipsis;
  line-clamp: 2;
  text-overflow: -o-ellipsis-lastline;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.td-type-code {
  text-align: left;
  .name {
    font-size: 0.32rem;
    color: #323232;
    line-height: 0.4rem;
  }
  .code {
    font-size: 0.24rem;
    color: #999999;
    line-height: 0.03rem;
  }
  .tag {
    background-color: rgba(254, 163, 30, 0.1);
    padding: 0.02rem;
    font-size: 0.18rem;
    color: #fea31e;
    line-height: 0.22rem;
    display: inline-block;
    vertical-align: middle;
    margin-left: 0.12rem;
  }
}

.stocks-panel {
  background: #ffffff;
  overflow-x: hidden;
  position: relative;
  min-height: 100vh;
  .fixed {
    position: fixed;
    top: 0.88rem;
    z-index: 10;
  }
  .table-list.table-fixed {
    margin-top: 1.84rem;
    .table-thead-fixed {
      position: fixed;
      border-top: 0.01rem solid rgba(232, 232, 232, 1);
      top: 2.73rem;
      z-index: 10;
    }
    .table-column-thead {
      top: 2.74rem;
    }
    .right-white {
      top: 2.73rem;
    }
  }
  .table-list.table-fixed2 {
    margin-top: 1.14rem;
    .table-thead-fixed {
      position: fixed;
      border-top: 0.01rem solid rgba(232, 232, 232, 1);
      top: 2.02rem;
      z-index: 10;
    }
    .table-column-thead {
      top: 2.04rem;
    }
    .right-white {
      top: 2.02rem;
    }
  }

  .stocks-bottom {
    font-family: PingFangSC-Regular;
    font-size: 0.24rem;
    color: #999999;
    letter-spacing: 0;
    background-color: #f5f5f5;
    font-weight: 400;
    text-align: left;
    padding: 0.32rem;
    width: 100vw;
    box-sizing: border-box;
  }
}

[theme-mode='black'] {
  .td-type-code {
    .name {
      color: #d2d2d3;
    }
    .code {
      color: #8e8e8e;
    }
  }

  .stocks-panel {
    background: #121212;

    .table-list.table-fixed {
      .table-thead-fixed {
        border-top: 0.01rem solid rgba(46, 46, 46, 1);
      }
    }
    .table-list2.table-fixed {
      .table-thead-fixed {
        border-top: 0.01rem solid rgba(46, 46, 46, 1);
      }
    }
  }

  .stocks-bottom {
    color: #8e8e8e;
    background-color: #121212;
  }
}
</style>
