<template>
    <div class="money-flow">
        <!-- 今日流向 -->
        <TodayFlow :pageType="pageType" :todayFlowData="todayFlowData"></TodayFlow>
        <!-- 北向点评/北向复盘 -->
        <CommentAndReplay :pageType="pageType" :hgtMarketStatus="todayFlowData.hgtMarketStatus" :ggtMarketStatus="todayFlowData.ggtMarketStatus"></CommentAndReplay>
        <!-- 历史流向 -->
        <HistoryFlow :pageType="pageType" :hgtMarketStatus="todayFlowData.hgtMarketStatus" :ggtMarketStatus="todayFlowData.ggtMarketStatus"></HistoryFlow>
        <!-- 历史数据 -->
        <HistoryData :pageType="pageType"></HistoryData>
    </div>
</template>

<script>
import TodayFlow from '@/components/todayFlow/index';
import CommentAndReplay from '@/components/commentAndReplay';
import HistoryFlow from '@/components/historyFlow/index';
import HistoryData from '@/components/historyData';
export default {
    name: 'MoneyFlow',
    props: {
        pageType: String,
        todayFlowData: Object
    },
    components: {
        TodayFlow,
        CommentAndReplay,
        HistoryFlow,
        HistoryData
    }
};
</script>
<style lang="less" scoped>
@import '../assets/styles/mixin.less';
@import '../assets/styles/skin.less';
.money-flow {
    .flex(column,flex-start,center,nowrap);
    background-color: @background-page;
}
[theme-mode="black"] {
    .money-flow {
    .flex(column,flex-start,center,nowrap);
    background-color: @background-page-dark;
}
}
</style>