import Home from '_v/Home';
import HistoryDataPage from '_v/HistoryDataPage';

export default [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      // config current page title
      title: '沪深港通',
    },
  },
  {
    path: '/historyDataPage',
    name: 'HistoryDataPage',
    component: HistoryDataPage,
    meta: {
      title: '历史数据',
    },
  },
  {
    path: '*',
    redirect: '/',
  },
];