// eslint-disable-next-line no-unused-vars
import req from './http.js';
import config from '../config';

// 获取今日流向数据
export const getTodayFlowData = type =>
  req('get', `${config.api.interface}/captitalflows/timedia/get_timedia?type=${type}`, '');

// 获取历史流向数据
export const getHistoryFlowData = (type, historyType) =>
  req(
    'get',
    `${config.api.interface}/captitalflows/history/get_captitalflows_history?type=${type}&history_type=${historyType}`,
    ''
  );

// 获取北向点评/北向复盘
export const getCommentAndReplay = type =>
  req(
    'get',
    `${config.api.interface}/captitalflows/paperwork/get_tradedate_paperwork?type=${type}`,
    ''
  );

// 获取资金流向历史数据
export const getHistoryData = (type, pageIndex, pageSize) =>
  req(
    'get',
    `${config.api.interface}/basedata/tradedate_data/get_history_list?type=${type}&page_index=${pageIndex}&page_size=${pageSize}`,
    ''
  );

// 获取交易日列表 凌晨更新
export const getDateCalendar = type =>
  req('get', `${config.api.interface}/basedata/date_calendar/get_date_calendar?type=${type}`, '');

// 获取十大成交榜交易日列表 18:00更新
export const getTopTenDateCalendar = type =>
  req(
    'get',
    `${config.api.interface}/basedata/date_calendar/get_top_ten_date_calendar?type=${type}`,
    ''
  );

//获取支持沪深港通交易的股票列表
export const getSearchStocks = () => req('get', config.api.getSearchStocks, '');

//股票搜索
export const searchStock = pattern =>
  req('get', `${config.api.searchStock}?pattern=${pattern}&appname=hsgtProject`, '');
