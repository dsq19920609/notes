<template>
  <div class="today-flow">
    <div class="title-and-select">
      <div class="title">今日流向</div>
      <SelectList :list="dataTypeList" level="1" @selectItem="changeTodayFlowType"></SelectList>
    </div>
    <div class="chart-header">
      <template v-for="(item, index) in seriesList">
        <div class="series-switch" :key="index" @click="switchSeriesStatus(item)">
          <div v-if="item.switchable && !item.seriesStatus" class="switch-btn">
            <img :src="closeBtn" alt="" />
          </div>
          <div v-if="item.switchable && item.seriesStatus" class="switch-btn">
            <img v-if="item.color === 'green'" :src="greenBtn" alt="" />
            <img v-if="item.color === 'orange'" :src="orangeBtn" alt="" />
            <img v-if="item.color === 'pink'" :src="pinkBtn" alt="" />
          </div>
          <div
            class="line"
            :class="{
              blue: item.color === 'blue',
              green: item.color === 'green',
              pink: item.color === 'pink',
              orange: item.color === 'orange',
            }"
          ></div>
          <div v-if="item.label" class="label">{{ item.label }}</div>
          <SelectList
            v-if="item.selectable"
            :list="item.selectList"
            level="2"
            @selectItem="changeExponentType"
          ></SelectList>
        </div>
      </template>
    </div>
    <!-- 图表位 -->
    <TodayFlowChart
      :pageType="pageType"
      :todayFlowType="todayFlowType"
      :todayFlowData="todayFlowData"
      :shLine="shLine"
      :szLine="szLine"
      :exponentLine="exponentLine"
      :exponentTypeInfo="exponentTypeInfo"
      :seriesList="seriesList"
    ></TodayFlowChart>
    <div class="notice" v-if="todayFlowData.newHighRemind">
      <img src="../../assets/images/icon_tz.png" alt="" />
      <div class="content">{{ todayFlowData.newHighRemind }}</div>
    </div>
  </div>
</template>
<script>
import SelectList from '@/components/commen/selectList';
import TodayFlowChart from '@/components/todayFlow/todayFlowChart';
// import {getTodayFlowData} from '../../apis';
import closeBtn from '@/assets/images/close_btn.png';
import greenBtn from '@/assets/images/green_btn.png';
import orangeBtn from '@/assets/images/orange_btn.png';
import pinkBtn from '@/assets/images/pink_btn.png';
export default {
  name: 'TodayFlow',
  props: {
    pageType: String,
    todayFlowData: Object,
  },
  components: {
    SelectList,
    TodayFlowChart,
  },
  mounted() {
    this.synchronizeBtnAndLine();
  },
  data() {
    return {
      dataTypeList: [
        {
          id: '1',
          label: '成交净买入',
        },
        {
          id: '2',
          label: '资金净流入',
        },
      ], // 数据类型列表
      seriesList: [], // 图标头部系列控制
      todayFlowType: null, // 今日流向类型。成交净买入/资金净流入
      shLine: null, // 是否显示沪股通线
      szLine: null, // 是否显示港股通线
      exponentLine: null, // 是否指数线
      exponentTypeInfo: {
        label: '',
        code: '',
      }, // 当前指数类型请求数据的信息。
      closeBtn,
      greenBtn,
      orangeBtn,
      pinkBtn,
    };
  },
  methods: {
    // 控制开关的状态
    switchSeriesStatus(series) {
      this.seriesList = this.seriesList.map((item, index) => {
        if (series.id === item.id) {
          item.seriesStatus = !item.seriesStatus;
          if (item.id === '2') {
            localStorage.setItem('showSh', item.seriesStatus);
          } else if (item.id === '3') {
            this.szLine = item.seriesStatus;
            localStorage.setItem('showSz', item.seriesStatus);
          } else if (item.id === '4') {
            this.exponentLine = item.seriesStatus;
            localStorage.setItem('showExponent', item.seriesStatus);
          }
        }
        const pageType = this.pageType == 'north' ? 'lgt' : 'ggt';
        const subType = {
          '2': 'hgt',
          '3': 'sgt',
          '4': 'szzs',
        };
        const op = item.seriesStatus ? 'dj' : 'qxdj';
        window.hxmClickStat(`hsgt.${pageType}.${subType[item.id]}.${op}`);
        return item;
      });
      this.synchronizeBtnAndLine();
    },
    // 同步开关按钮和线的显示或关闭状态
    synchronizeBtnAndLine() {
      this.seriesList.forEach((item, index) => {
        if (item.id === '2') {
          this.shLine = item.seriesStatus;
        } else if (item.id === '3') {
          this.szLine = item.seriesStatus;
        } else if (item.id === '4') {
          this.exponentLine = item.seriesStatus;
        }
      });
    },
    // 今日流向类型变化
    changeTodayFlowType(item) {
      this.todayFlowType = item.id;
      if (this.pageType === 'north' && this.todayFlowType === '1') {
        this.seriesList = [
          {
            id: '1',
            label: '合计净买入',
            selectable: false,
            switchable: false,
            seriesStatus: false,
            color: 'blue',
          },
          {
            id: '2',
            label: '沪股通',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSh') === 'true' || false,
            color: 'green',
          },
          {
            id: '3',
            label: '深股通',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSz') === 'true' || false,
            color: 'pink',
          },
          {
            id: '4',
            label: '',
            selectable: true,
            selectList: [
              {
                id: '1',
                label: '上证指数',
                code: 'hs_1A0001',
              },
              {
                id: '2',
                label: '深证成指',
                code: 'hs_399001',
              },
              {
                id: '3',
                label: '创业板指',
                code: 'hs_399006',
              },
            ],
            switchable: true,
            seriesStatus: localStorage.getItem('showExponent') === 'false' ? false : true,
            color: 'orange',
          },
        ];
        window.hxmClickStat('hsgt.lgt.cjjmr');
      } else if (this.pageType === 'north' && this.todayFlowType === '2') {
        this.seriesList = [
          {
            id: '1',
            label: '合计净流入',
            selectable: false,
            switchable: false,
            seriesStatus: false,
            color: 'blue',
          },
          {
            id: '2',
            label: '沪股通',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSh') === 'true' || false,
            color: 'green',
          },
          {
            id: '3',
            label: '深股通',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSz') === 'true' || false,
            color: 'pink',
          },
          {
            id: '4',
            label: '',
            selectable: true,
            selectList: [
              {
                id: '1',
                label: '上证指数',
                code: 'hs_1A0001',
              },
              {
                id: '2',
                label: '深证成指',
                code: 'hs_399001',
              },
              {
                id: '3',
                label: '创业板指',
                code: 'hs_399006',
              },
            ],
            switchable: true,
            seriesStatus: localStorage.getItem('showExponent') === 'false' ? false : true,
            color: 'orange',
          },
        ];
        window.hxmClickStat('hsgt.lgt.zjlr');
      } else if (this.pageType === 'south' && this.todayFlowType === '1') {
        this.seriesList = [
          {
            id: '1',
            label: '合计净买入',
            selectable: false,
            switchable: false,
            seriesStatus: false,
            color: 'blue',
          },
          {
            id: '2',
            label: '港股通(沪)',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSh') === 'true' || false,
            color: 'green',
          },
          {
            id: '3',
            label: '港股通(深)',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSz') === 'true' || false,
            color: 'pink',
          },
          {
            id: '4',
            label: '',
            selectable: true,
            selectList: [
              {
                id: '1',
                label: '恒生指数',
                code: 'hk_HSI',
              },
              {
                id: '2',
                label: '国企指数',
                code: 'hk_HSCEI',
              },
            ],
            switchable: true,
            seriesStatus: localStorage.getItem('showExponent') === 'false' ? false : true,
            color: 'orange',
          },
        ];
        window.hxmClickStat('hsgt.ggt.cjjmr');
      } else if (this.pageType === 'south' && this.todayFlowType === '2') {
        this.seriesList = [
          {
            id: '1',
            label: '合计净流入',
            selectable: false,
            switchable: false,
            seriesStatus: false,
            color: 'blue',
          },
          {
            id: '2',
            label: '港股通(沪)',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSh') === 'true' || false,
            color: 'green',
          },
          {
            id: '3',
            label: '港股通(深)',
            selectable: false,
            switchable: true,
            seriesStatus: localStorage.getItem('showSz') === 'true' || false,
            color: 'pink',
          },
          {
            id: '4',
            label: '',
            selectable: true,
            selectList: [
              {
                id: '1',
                label: '恒生指数',
                code: 'hk_HSI',
              },
              {
                id: '2',
                label: '国企指数',
                code: 'hk_HSCEI',
              },
            ],
            switchable: true,
            seriesStatus: localStorage.getItem('showExponent') === 'false' ? false : true,
            color: 'orange',
          },
        ];
        window.hxmClickStat('hsgt.ggt.zjlr');
      }
    },
    // 指数类型变化
    changeExponentType(item) {
      this.exponentTypeInfo = {
        label: item.label,
        code: item.code,
      };
    },
  },
};
</script>
<style lang="less" scoped>
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.today-flow {
  .flex(column,flex-start,center,nowrap);
  width: 100%;
  padding-bottom: 0.32rem;
  margin-bottom: 0.16rem;
  border-radius: 0 0 0.16rem 0.16rem;
  background-color: @background-white;
  .title-and-select {
    .flex(row,space-between,center,nowrap);
    width: calc(100% - 0.64rem);
    margin: 0.4rem 0 0.32rem;
    .title {
      font-size: 0.36rem;
      color: @font-most-major;
      line-height: 0.5rem;
      font-weight: 700;
      text-align: left;
    }
  }
  .chart-header {
    .flex(row,space-between,center,nowrap);
    width: calc(100% - 0.64rem);
    margin-bottom: 0.4rem;
    .series-switch {
      .flex(row,flex-start,center,nowrap);
      .switch-btn {
        .flex(row,center,center,nowrap);
        position: relative;
        margin-right: 0.1rem;
        img {
          width: 0.24rem;
          height: 0.24rem;
        }
      }
      .line {
        width: 0.12rem;
        height: 0.04rem;
        margin-right: 0.08rem;
        border-radius: 0.02rem;
        &.blue {
          background: @line-blue;
        }
        &.green {
          background: @line-green;
        }
        &.pink {
          background: @line-pink;
        }
        &.orange {
          background: @line-orange;
        }
      }
      .label {
        font-family: PingFangSC-Regular;
        font-size: 0.24rem;
        color: @font-general-major;
        font-weight: 400;
      }
    }
  }
  .notice {
    .flex(row,flex-start,center,nowrap);
    width: calc(100% - 0.64rem);
    height: 0.64rem;
    margin-top: 0.32rem;
    font-family: PingFangSC-Regular;
    font-size: 0.24rem;
    color: @font-major;
    font-weight: 400;
    background: @background-red06;
    border-radius: 0.16rem;
    .content {
      flex: 1;
      text-align: left;
      margin-right: 0.2rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    img {
      margin-left: 0.24rem;
      margin-right: 0.1rem;
      width: 0.24rem;
      height: 0.24rem;
    }
  }
}
[theme-mode='black'] {
  .today-flow {
    .flex(column,flex-start,center,nowrap);
    width: 100%;
    padding-bottom: 0.32rem;
    margin-bottom: 0.16rem;
    border-radius: 0 0 0.16rem 0.16rem;
    background-color: @background-white-dark;
    .title-and-select {
      .flex(row,space-between,center,nowrap);
      width: calc(100% - 0.64rem);
      margin: 0.4rem 0 0.32rem;
      .title {
        font-size: 0.36rem;
        color: @font-most-major-dark;
        line-height: 0.5rem;
        font-weight: 700;
        text-align: left;
      }
    }
    .chart-header {
      .flex(row,space-between,center,nowrap);
      width: calc(100% - 0.64rem);
      margin-bottom: 0.4rem;
      .series-switch {
        .flex(row,flex-start,center,nowrap);
        .switch-btn {
          position: relative;
          margin-right: 0.1rem;
          img {
            width: 0.24rem;
            height: 0.24rem;
          }
        }
        .line {
          width: 0.12rem;
          height: 0.04rem;
          margin-right: 0.08rem;
          border-radius: 0.02rem;
          &.blue {
            background: @line-blue-dark;
          }
          &.green {
            background: @line-green-dark;
          }
          &.pink {
            background: @line-pink-dark;
          }
          &.orange {
            background: @line-orange-dark;
          }
        }
        .label {
          font-family: PingFangSC-Regular;
          font-size: 0.24rem;
          color: @font-general-major-dark;
          font-weight: 400;
        }
      }
    }
    .notice {
      .flex(row,flex-start,center,nowrap);
      width: calc(100% - 0.64rem);
      height: 0.64rem;
      margin-top: 0.32rem;
      font-family: PingFangSC-Regular;
      font-size: 0.24rem;
      color: @font-major-dark;
      font-weight: 400;
      background: @background-red06-dark;
      border-radius: 0.16rem;
      .content {
        flex: 1;
        text-align: left;
        margin-right: 0.2rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      img {
        margin-left: 0.24rem;
        margin-right: 0.1rem;
        width: 0.24rem;
        height: 0.24rem;
      }
    }
  }
}
</style>
