<template>
    <div class="wp" @touchstart="handleTouchMove" @touchmove="handleTouchMove">
        <div class="chartBox" id="today-chart"></div>
        <img class="watermark" src="../../assets/images/sy.png" alt="">
        <div v-if="touching" class="tooltip" :class="{'left': tooltipPosition === 'left','right': tooltipPosition === 'right'}">
            <div class="tooltip-time">
                <div class="title">
                    {{tooltipData.date}} {{tooltipData.time}}
                </div>
            </div>
            <div class="tooltip-item">
                <div class="title">
                    <div class="line blue"></div>
                    {{tooltipData.content[0].label}}
                </div>
                <div class="value">
                    {{tooltipData.content[0].value != null ? `${numberConvert(tooltipData.content[0].value)}亿` : '--'}}
                </div>
            </div>
            <div class="tooltip-item" v-if="shLine">
                <div class="title">
                    <div class="line green"></div>
                    {{tooltipData.content[1].label}}
                </div>
                <div class="value">{{tooltipData.content[1].value != null ? `${numberConvert(tooltipData.content[1].value)}亿` : '--'}}</div>
            </div>
            <div class="tooltip-item" v-if="szLine">
                <div class="title">
                    <div class="line pink"></div>
                    {{tooltipData.content[2].label}}
                </div>
                <div class="value">{{tooltipData.content[2].value != null ? `${numberConvert(tooltipData.content[2].value)}亿`: '--'}}</div>
            </div>
            <div class="tooltip-item" v-if="exponentLine">
                <div class="title">
                    <div class="line orange"></div>
                    {{tooltipData.content[3].label}}
                </div>
                <div class="value">
                    {{tooltipData.content[3].value1 != null ? `${tooltipData.content[3].value1.toFixed(2)}`: '--'}}&nbsp;&nbsp;
                    {{tooltipData.content[3].value2 != null ? `${numberConvert(tooltipData.content[3].value2*100)}%`: '--'}}
                </div>
            </div>
        </div>
    </div>
</template>
<script>
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr');
const pageRate = pageWidth / (375*dpr);
import { phoneTheme } from '@/assets/common.js';
import {Interceptor} from './charts.js';
export default {
    name: 'TodayflowChart',
    mounted() {
        this.isDark = phoneTheme();
    },
    props: {
        pageType:String,
        todayFlowType:String,
        shLine: Boolean,
        szLine: Boolean,
        exponentLine: Boolean,
        todayFlowData: Object,
        exponentTypeInfo: Object,
        seriesList: Object
    },
    watch: {
        todayFlowData () {
            this.init = true;
            // console.log('111',this.todayFlowData)
            this.updateChartData();
        },
        pageType () {
            this.updateChartData();
        },
        todayFlowType () {
            this.updateChartData();
        },
        shLine () {
            this.updateChartData();
        },
        szLine () {
            this.updateChartData();
        },
        exponentLine () {
            this.updateChartData();
        },
        exponentTypeInfo () {
            this.updateChartData();
        },
        touching () {
            if (this.touching) {
                document.body.style.overflowY = 'hidden';
            } else {
                this.handleAxisPointer('hide');
                document.body.style.overflowY = 'auto';
            }
        }
    },
    methods: {
        // 更新图表数据
        updateChartData() {
            if (this.init) {
                console.log(this.todayFlowData)
                let todayChart = document.getElementById('today-chart');
                if (todayChart.firstChild) {
                    todayChart.removeChild(todayChart.firstChild);
                }
                let myChart = D3Charts.init('today-chart');
                let color = {
                    axisLine: this.isDark ? ' #2E2E2E' : '#e8e8e8',// 每个标志线的颜色
                    eqAxisX: this.isDark ? '#8e8e8e' :'#999999', // x坐标轴字体颜色
                    eqAxisY: this.isDark ? '#757575' :'#b3b3b3', // y坐标轴字体颜色
                    blueLine: this.isDark ? '#497DE6' : '#5B91FC',// 蓝线
                    greenLine: this.isDark ? '#35DCC5' : '#35DCC5',// 绿线
                    pinkLine: this.isDark ? '#E376B0' : '#E376B0',// 粉线
                    orangeLine: this.isDark ? '#E67643' : '#FF834A',// 橙线
                    hoverLine: this.isDark ? '#8e8e8e' : '#999999',  // 悬停十字线颜色
                    titleFront: this.isDark ? '#8e8e8e' : '#999999',// 小标题字体颜色
                    legendFront: this.isDark ? '#8e8e8e' : '#999999',// 上筛选字体颜色
                    areaColor: this.isDark ? '#497DE6' : '#5B91FC',// 填充区域颜色
                    upBarcolor: this.isDark ? ' #E46057' : '#FF665C',// 上涨柱状图颜色
                    downBarcolor: this.isDark ? '#41AF67' : '#47C271'// 下跌柱状图颜色
                };// 图表各类颜色属性
                let font = {
                    size: 13 * dpr * pageRate,
                    weight: 500,
                    family: 'THSMoneyfont-Medium'
                };// 字体相关配置
                let paramsConfig = {
                    type: 'fsToday',
                    code: window.location.search.substr(1) || this.exponentTypeInfo.code,
                    // isKeepingGet: true, // 是否持续获取
                    // intervalTime: 6000 // 间隔多久更新一次(推荐大于60秒,因为现在服务端缓存是1分钟)
                }; // 请求参数配置
                console.log(paramsConfig)
                let dp = D3Charts.getDataPool();
                dp.setStatus({ enableFilterUrl: true });
                let dataProvider = D3Charts.getDataPool().register(paramsConfig);
                D3Charts.getDataPool().onAction(dataProvider, 'PROVIDER_UPDATE.myproject', (d) => {
                    if (d.fetchStatus.code !== '000') return; // 状态判断
                    let Data = [...d.data[paramsConfig.code].dataArray]; // 获取数据
                    this.exponentData = Data;
                    this.todayFlowData.chartData[this.todayFlowType === '1' ? 'netBuyData' : 'netInflowData'].forEach((item,index)=>{
                        if (item.date === '09:30') {
                            for (let i = 0; i < index; i++) {
                                Data.unshift({
                                    av: null,
                                    avPct: null,
                                    n: null,
                                    nowp: null,
                                    nowpPct: null,
                                    np: null,
                                    s: null,
                                    t: null,
                                });
                            }
                        }
                    });
                    console.log(Data)
                    // 配置项
                    const option = {
                        data: [
                            {
                                originData: this.todayFlowType === '1' ? this.todayFlowData.chartData.netBuyData :  this.todayFlowData.chartData.netInflowData
                            },
                            {
                                originData: Data
                            }
                        ],
                        grid: [{
                            top: 2 * dpr * pageRate,
                            left: 0,
                            right:0,
                            bottom: 24 * dpr * pageRate
                        }],
                        series: [
                            {
                                type: "line",
                                $dataIndex: 0,
                                $axisIndex: [0, 1],
                                dataKey: "total",
                                name: "合计净买入/合计净流入",
                                line: {
                                    show: true,
                                    style: {
                                        normal: {
                                            stroke: color.blueLine,
                                            lineWidth: 1.5 * dpr * pageRate
                                        }
                                    }
                                },
                                area: {
                                    show: true,
                                    snapToBottom: true,
                                    style: {
                                        normal: {
                                            fill: {
                                                y2: 1,
                                                x2: 0,
                                                colorStops: [
                                                    {
                                                        offset: 0,
                                                        color: color.blueLine
                                                    },
                                                    {
                                                        offset: 1,
                                                        color: this.isDark ? 'black' :'white'
                                                    },
                                                ]

                                            },
                                            opacity: 0.2
                                        }
                                    },
                                    opacity: 0.2
                                }
                            },
                            {
                                type: "line",
                                $dataIndex: 0,
                                $axisIndex: [0, 1],
                                dataKey: "sh",
                                name: "沪股通",
                                line: {
                                    show: this.shLine,
                                    style: {
                                        normal: {
                                            stroke: color.greenLine,
                                            lineWidth: 1 * dpr * pageRate
                                        }
                                    }
                                },
                                area: {
                                    show: false,
                                    snapToBottom: true,
                                    style: {
                                        normal: {
                                            fill: {
                                                y2: 1,
                                                x2: 0,
                                                colorStops: [
                                                    {
                                                        offset: 0,
                                                        color: color.greenLine
                                                    },
                                                    {
                                                        offset: 1,
                                                        color: this.isDark ? 'black' : 'white'
                                                    },
                                                ]

                                            },
                                            opacity: 0.2
                                        }
                                    },
                                    opacity: 0.2
                                }
                            },
                            {
                                type: "line",
                                $dataIndex: 0,
                                $axisIndex: [0, 1],
                                dataKey: "sz",
                                name: "深股通",
                                line: {
                                    show: this.szLine,
                                    style: {
                                        normal: {
                                            stroke: color.pinkLine,
                                            lineWidth: 1 * dpr * pageRate
                                        }
                                    }
                                },
                                area: {
                                    show: false,
                                    snapToBottom: true,
                                    style: {
                                        normal: {
                                            fill: {
                                                y2: 1,
                                                x2: 0,
                                                colorStops: [
                                                    {
                                                        offset: 0,
                                                        color: color.pinkLine
                                                    },
                                                    {
                                                        offset: 1,
                                                        color: this.isDark ? 'black' : 'white'
                                                    },
                                                ]

                                            },
                                            opacity: 0.2
                                        }
                                    },
                                    opacity: 0.2
                                }
                            },
                            {
                                type: "line",
                                $dataIndex: 1,
                                dataKey: "nowpPct",
                                name: "指数",
                                $axisIndex: [0, 2],
                                line: {
                                    show: this.exponentLine,
                                    style: {
                                        normal: {
                                            stroke: color.orangeLine,
                                            lineWidth: 1 * dpr * pageRate
                                        }
                                    }
                                },
                            },
                        ],
                        dataZoom: [{}],
                        axis: [
                            {
                                position: 'bottom',
                                type: 'point',
                                xOrY: 'x',
                                $dataIndex: 0,
                                dataKey: 'date',
                                paddingInner: 0.1 * dpr * pageRate,
                                paddingOuter: 0.1 * dpr * pageRate,
                                barGap: 0,
                                $dataZoomIndex: 0,
                                line: {
                                    show: false
                                },
                                tick: {
                                    show: false
                                },
                                label: {
                                    padding: 10 * dpr,
                                    inRange: true,
                                    style: {
                                        fill: color.eqAxisX,
                                        fontSize: font.size,
                                        fontFamily: font.family
                                    },
                                    formatter: function (v,vindex,num) {
                                        switch (true) {
                                            case vindex === 0 || vindex === num-1:
                                                return v;
                                                break;
                                            case v === '11:30':
                                                return '11:30/13:00'
                                                break;
                                            case v === '12:00':
                                                return '12:00/13:00'
                                                break;
                                            default:
                                                return '';
                                                break;
                                        }
                                    }
                                },
                                tickValues: (v)=>{
                                    if (this.pageType === 'north') {
                                        return [v[0],v[Math.floor((v.length-1)/4)],'11:30',v[Math.floor((v.length-1)/4*3)],v[v.length-1]]
                                    } else {
                                        return [v[0],v[Math.floor((v.length-1)/4)],'12:00',v[Math.floor((v.length-1)/4*3)],v[v.length-1]]
                                    }
                                },
                                splitLine: {
                                    show: true,
                                    style: (value,index)=>{
                                        if (index === 0 || index === 4) {
                                            return {
                                                stroke: color.axisLine,
                                                lineWidth: 0
                                            }
                                        }
                                        return {
                                            stroke: color.axisLine,
                                            lineWidth: 1 * dpr * pageRate,
                                        }
                                    }
                                },
                            },
                            {
                                position: 'left',
                                type: 'linear',
                                $gridIndex: 0, // 位置部署改成0，也就是grid数组的第一个位置构建
                                xOrY: 'y',
                                line: {
                                    show: false
                                },
                                tick: {
                                    show: false
                                },
                                tickValues: function (domainLeft) {
                                    let min = domainLeft[0];
                                    let max = domainLeft[1];
                                    let detar = max - min; // 差值
                                    let num = [domainLeft[0], detar / 4 + domainLeft[0], detar * 2 / 4 + domainLeft[0], detar * 3 / 4 + domainLeft[0], domainLeft[1]];
                                    return num;
                                },
                                label: {
                                    show: true,
                                    padding: 0,
                                    inRange: true,
                                    inside: true,
                                    offset: [10* dpr * pageRate,10* dpr * pageRate],
                                    style: {
                                        fill: color.eqAxisY,
                                        fontSize: font.size,// 字体大小
                                        fontWeight: font.weight,
                                        fontFamily: font.family
                                    },
                                    formatter: function (v, index, num) {
                                        return `${Math.round(v*100)/100}亿`;
                                    },
                                },
                                splitLine: {
                                    show: true,
                                    style: {
                                        stroke: color.axisLine,
                                        color: color.axisLine,
                                        lineDash: [3* dpr * pageRate, 3* dpr * pageRate],
                                        lineWidth: 1 * dpr * pageRate
                                    }
                                },
                            },
                            {
                                position: 'right',
                                type: 'linear',
                                $gridIndex: 0,
                                xOrY: 'y',
                                line: {
                                    show: false
                                },
                                tick: {
                                    show: false
                                },
                                tickValues: function (domainRight) {
                                    let min = domainRight[0];
                                    let max = domainRight[1];
                                    let detar = max - min; // 差值
                                    let num = [domainRight[0], detar / 4 + domainRight[0], detar * 2 / 4 + domainRight[0], detar * 3 / 4 + domainRight[0], domainRight[1]];
                                    return num;
                                },
                                label: {
                                    show: this.exponentLine,
                                    padding: 0,
                                    inRange: true,
                                    inside: true,
                                    style: {
                                        fill: color.eqAxisY,
                                        fontSize: font.size,
                                        fontWeight: font.weight,
                                        fontFamily: font.family,
                                        textAlign: 'right'
                                    },
                                    formatter: function (v, index, num) {
                                        return `${Math.round(v*100*100)/100}%`;
                                    },
                                }
                            }
                        ],
                        // 光标放置在那里那么那里就会出现这个提示柱
                        axisPointer: [
                            // 垂直实线
                            {
                                $axisIndex: 0,
                                line: {
                                    show: true,
                                    style: {
                                        stroke: color.hoverLine,
                                        lineWidth: 1 * dpr * pageRate
                                    }
                                },
                                label: {
                                    show: false
                                }
                            },
                        ],
                        animation: false
                    }
                    if (!this.interceptor) {
                        this.interceptor = new Interceptor(myChart._dom, 300, this.setTouching, this.setPointer);
                    }
                    this.chart = myChart;
                    myChart.setOption(option);
                    this.xAxis = myChart.getModel('axis', 0);
                    this.axisPointer = myChart.getModel('axisPointer');
                    this.axisPointerViewX = myChart.getViewOfComponentModel(this.axisPointer[0]);
                    const axisModel = myChart.getModel('axis', 0);
                    myChart.registerAction(axisModel, 'AXIS_MOVE', this.onChartMove);
                    myChart.registerAction(axisModel, 'AXIS_OUT', this.onChartOut);
                });
            }
        },
        // 四舍五入并保留两位小数
        numberConvert(value) {
            return  `${value >0 ? '+': ''}${value.toFixed(2)}`;
        },
        setTouching (value) {
            this.touching = value;
        },
        setPointer (value) {
            this.pointer = value;
        },
        onChartMove (e) {
            this.pointer = true;
            this.setTooltip(e.dataIndex);
        },
        onChartOut (e) {
            this.pointer = false;
        },
        handleTouchMove (e) {
            if (this.touching && !this.pointer) {
                let { clientX } = e.touches[0];
                const { x } = this.chart._dom.children[0].children[0].getBoundingClientRect();
                let _x = clientX - x;
                const xRange = this.xAxis.range;
                const xDelta = xRange[1] - xRange[0];
                const xTotal = this.xAxis.domain.length;
                let xIndex = Math.floor(((_x - xRange[0]) / xDelta) * xTotal);
                xIndex = xIndex < 0 ? 0 : (xIndex > xTotal - 1 ? xTotal - 1 : xIndex);
                this.handleAxisPointer('show', xIndex);
                this.setTooltip(xIndex);
            }
        },
        // 控制坐标指示线显示与隐藏
        handleAxisPointer (type, xIndex) {
            this.xShape = this.axisPointerViewX._shapeMap;
            for (let shape in this.xShape) {
                const timer = setTimeout(() => {
                    clearTimeout(timer);
                    this.xShape[shape][type]()
                })
                if (typeof xIndex === 'number' && type === 'show') {
                    let x = this.xAxis.scale(this.xAxis.domain[xIndex]);
                    if (~shape.indexOf('label')) {
                        // 绘制x轴竖线
                        const xRange = this.xAxis.range;
                        const outerWidth = (this.xShape[shape]?.__textCotentBlock?.outerWidth || 74) / 2;
                        x = (x - outerWidth) < xRange[0] ? xRange[0] + outerWidth : x;
                        x = (x + outerWidth) > xRange[1] ? xRange[1] - outerWidth : x;
                        let pos = this.xShape[shape].position;
                        this.xShape[shape].attr('position', [x, pos[1]])
                        this.xShape[shape].style.text = this.xAxis.domain[xIndex]
                    } else {
                        this.xShape[shape].attr('shape', {...this.xShape[shape].shape, x1: x, x2: x})
                    }
                };
            }
        },
        setTooltip (xIndex) {
            this.tooltipPosition = xIndex > (this.xAxis.startIndex + this.xAxis.endIndex)/2 ? 'left': 'right';
            this.tooltipData = {
                date: this.todayFlowData.date,
                time: this.xAxis.domain[xIndex],
                content: [
                    {
                        label: this.seriesList[0].label,
                        value: this.todayFlowType === '1' ? this.todayFlowData.chartData.netBuyData[xIndex].total :  this.todayFlowData.chartData.netInflowData[xIndex].total
                    },
                    {
                        label: this.seriesList[1].label,
                        value: this.todayFlowType === '1' ? this.todayFlowData.chartData.netBuyData[xIndex].sh :  this.todayFlowData.chartData.netInflowData[xIndex].sh
                    },
                    {
                        label: this.seriesList[2].label,
                        value: this.todayFlowType === '1' ? this.todayFlowData.chartData.netBuyData[xIndex].sz :  this.todayFlowData.chartData.netInflowData[xIndex].sz
                    },
                    {
                        label: this.exponentTypeInfo.label,
                        value1: this.exponentData[xIndex]?.nowp || null,
                        value2: this.exponentData[xIndex]?.nowpPct || null
                    }
                ]
            }
        }
    },
    data() {
        return {
            isDark: false,
            chart: null,
            touching: false,
            pointer: false,
            interceptor: null,
            xAxis: null,
            axisPointer: null,
            axisPointerViewX: null,
            axisPointerViewY: null,
            xShape: null,
            yShape: null,
            init: false,
            tooltipPosition: 'right',
            tooltipData: {
                date: '',
                time: '',
                content: [
                    {
                        label: '',
                        value: ''
                    },
                    {
                        label: '',
                        value: ''
                    },
                    {
                        label: '',
                        value: ''
                    },
                    {
                        label: '',
                        value: ''
                    }
                ]
            },
            exponentData: []
        };
    },
};
</script>


<style lang="less" scoped>
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.wp {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    .watermark {
        position: absolute;
        width: 0.72rem;
        right: 0.8rem;
        bottom: 0.7rem;
    }
    .tooltip {
        position: absolute;
        top: 0;
        min-width: 3.5rem;
        border-radius: 0.08rem;
        background: #323232;
        text-align: left;
        opacity: 0.8;
        padding: 0.16rem 0;
        &.left {
            left: 0;
        }
        &.right {
            right: 0;
        }
        .tooltip-time {
            font-family: THSMoneyfont-Medium;
            font-size: 0.22rem;
            color: @font-white;
            font-weight: 500;
            margin-left: 0.16rem;
            margin-bottom: 0.06rem;
        }
        .tooltip-item {
            .flex(row,space-between,center,nowrap);
            margin: 0 0.16rem 0.08rem 0.16rem;
            .icon {
                width: 0.2rem;
                height: 0.2rem;
                margin-right: 0.06rem;
            }
            .line {
                display: inline-block;
                width: 0.12rem;
                height: 0.04rem;
                margin-right: 0.14rem;
                border-radius: 0.02rem;
                &.blue {
                    background: @line-blue;
                }
                &.green {
                    background: @line-green;
                }
                &.pink {
                    background: @line-pink;
                }
                &.orange {
                    background: @line-orange;
                }
            }
            .blank {
                display: inline-block;
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.14rem;
            }
            .title {
                .flex(row,space-between,center,nowrap);
                font-family: PingFangSC-Regular;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 400;
            }
            .value {
                font-family: THSMoneyfont-Medium;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 500; 
            }
        }
    }
}
.chartBox {
    width: 6.86rem;
    height: 3.6rem;
    background-color: transparent;
}

</style>
<style lang="less"> 
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.wp {
    .tooltip-time {
        font-family: THSMoneyfont-Medium;
        font-size: 0.22rem;
        color: @font-white;
        font-weight: 500;
        margin-left: 0.16rem;
        margin-bottom: 0.06rem;
    }
    .tooltip-item {
        .flex(row,space-between,center,nowrap);
        margin: 0 0.16rem 0.08rem 0.16rem;
        .icon {
            width: 0.2rem;
            height: 0.2rem;
            margin-right: 0.06rem;
        }
        .line {
            display: inline-block;
            width: 0.12rem;
            height: 0.04rem;
            margin-right: 0.14rem;
            border-radius: 0.02rem;
            &.blue {
                background: @line-blue;
            }
            &.green {
                background: @line-green;
            }
            &.pink {
                background: @line-pink;
            }
            &.orange {
                background: @line-orange;
            }
        }
        .blank {
            display: inline-block;
            width: 0.12rem;
            height: 0.12rem;
            margin-right: 0.14rem;
        }
        .title {
            .flex(row,space-between,center,nowrap);
            font-family: PingFangSC-Regular;
            font-size: 0.24rem;
            color: @font-white;
            font-weight: 400;
        }
        .value {
            font-family: THSMoneyfont-Medium;
            font-size: 0.24rem;
            color: @font-white;
            font-weight: 500; 
        }
    }
}
[theme-mode="black"] {
    .wp {
        .tooltip-time {
            font-family: THSMoneyfont-Medium;
            font-size: 0.22rem;
            color: @font-white;
            font-weight: 500;
            margin-left: 0.16rem;
            margin-bottom: 0.06rem;
        }
        .tooltip-item {
            .flex(row,space-between,center,nowrap);
            margin: 0 0.16rem 0.08rem 0.16rem;
            .icon {
                width: 0.2rem;
                height: 0.2rem;
                margin-right: 0.06rem;
            }
            .line {
                display: inline-block;
                width: 0.12rem;
                height: 0.04rem;
                margin-right: 0.14rem;
                border-radius: 0.02rem;
                &.blue {
                    background: @line-blue;
                }
                &.green {
                    background: @line-green;
                }
                &.pink {
                    background: @line-pink;
                }
                &.orange {
                    background: @line-orange;
                }
            }
            .blank {
                display: inline-block;
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.14rem;
            }
            .title {
                .flex(row,space-between,center,nowrap);
                font-family: PingFangSC-Regular;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 400;
            }
            .value {
                font-family: THSMoneyfont-Medium;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 500; 
            }
        }
    }
}
</style>
