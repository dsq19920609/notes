// 控制图标无效滑动
export class Interceptor {
    constructor(dom, time, setTouch, setPointer) {
      this.posX = 0;
      this.posY = 0;
      this.start = null;
      this._dom = dom;
      this._time = time;
      this.onTouchStart = this.onTouchStart.bind(this);
      this.onTouchMove = this.onTouchMove.bind(this);
      this.onTouchEnd = this.onTouchEnd.bind(this);
      this.locked = true;
      this.setTouch = setTouch;
      this.setPointer = setPointer;
      dom.addEventListener('touchstart', this.onTouchStart, true);
      dom.addEventListener('touchmove', this.onTouchMove, true);
      dom.addEventListener('touchend', this.onTouchEnd, true);
    }
    onTouchStart(e) {
      if (this.locked) {
        e.stopPropagation();
        this.posX = e.touches[0].pageX;
        this.posY = e.touches[0].pageY;
        this.start = e;
        this.unLock = setTimeout(() => {
          this.locked = false;
          this.unLock = false;
          this.setTouch(true);
          e.target.dispatchEvent(
            new TouchEvent('touchstart', {
              cancelable: true,
              bubbles: true,
              composed: true,
              touches: [e.touches[0]],
              targetTouches: [e.touches[0]],
              changedTouches: [e.touches[0]],
            })
          );
        }, this._time);
      }
    }
    onTouchMove(e) {
      if (this.locked) {
        if (this.unLock) {
          const moveX = Math.abs(e.touches[0].pageX - this.posX);
          const moveY = Math.abs(e.touches[0].pageY - this.posY);
          this.posX = e.touches[0].pageX;
          this.posY = e.touches[0].pageY;
          if (moveX < 5 && moveY >= moveX) {
            clearTimeout(this.unLock);
            this.unLock = false;  
          } else {
            clearTimeout(this.unLock);
            this.locked = false;
            this.unLock = false;
            this.setTouch(true);
            e.target.dispatchEvent(
              new TouchEvent('touchstart', {
                cancelable: true,
                bubbles: true,
                composed: true,
                touches: [this.start.touches[0]],
                targetTouches: [this.start.touches[0]],
                changedTouches: [this.start.touches[0]],
              })
            );
          }
        }
        e.stopPropagation();
      }
    }
    onTouchEnd(e) {
      this.locked = true;
      this.setTouch(false);
      this.setPointer(false);
      if (this.unLock) {
        clearTimeout(this.unLock);
        this.unLock = false;
      }
    }
    destroy() {
      dom.removeEventListener('touchstart', this.onTouchStart, true);
      dom.removeEventListener('touchmove', this.onTouchMove, true);
      dom.removeEventListener('touchend', this.onTouchEnd, true);
    }
}