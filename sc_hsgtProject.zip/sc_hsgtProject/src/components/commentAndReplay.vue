<template>
    <div class="comment-and-replay" v-if="list.length > 0">
        <template v-for="(item,index) in list">
            <div
                class="comment-or-replay"
                :class="{'slide': list.length > 1}"
                :key="index"
                @click="jumpDetail(item)"
            >
                <img class="logo" :src="isDark ? bxdpDark : bxdp" alt="" v-if="pageType === 'north' && item.type === '1'">
                <img class="logo" :src="isDark ? bxfpDark : bxfp" alt="" v-else-if="pageType === 'north' && item.type === '2'">
                <img class="logo" :src="isDark ? nxdpDark : nxdp" alt="" v-else-if="pageType === 'south' && item.type === '1'">
                <img class="line" :src="isDark ? lineFgDark : lineFg" alt="">
                <div class="desc">{{item.desc}}</div>
                <img class="forward" src="../assets/images/icon_forward.png" alt="" v-if="item.type === '2'">
            </div>
        </template>
    </div>
</template>
<script>
import bxdp from '@/assets/images/bxdp.png';
import bxfp from '@/assets/images/bxfp.png';
import bxdpDark from '@/assets/images/bxdp_dark.png';
import bxfpDark from '@/assets/images/bxfp_dark.png';
import nxdp from '@/assets/images/nxdp.png';
import nxdpDark from '@/assets/images/nxdp_dark.png';
import lineFg from '@/assets/images/line_fg.png';
import lineFgDark from '@/assets/images/line_fg_dark.png';
import { phoneTheme } from '@/assets/common.js';
import {getCommentAndReplay} from '@/apis';
export default {
  name: 'CommentAndReplay',
  props: {
    hgtMarketStatus: Number,
    ggtMarketStatus: Number,
    pageType:String
  },
  watch: {
    hgtMarketStatus() {
      this.handleGetCommentAndReplay();
    },
    ggtMarketStatus() {
      this.handleGetCommentAndReplay();
    }
  },
  mounted() {
    this.isDark = phoneTheme();
    this.handleGetCommentAndReplay();
    this.timer = setInterval(()=>{
      this.handleGetCommentAndReplay();
    },60000);
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  data() {
    return {
      list: [], // 北向点评/复盘列表
      isDark: false,
      bxdp,
      bxfp,
      nxdp,
      bxdpDark,
      bxfpDark,
      nxdpDark,
      lineFg,
      lineFgDark,
      timer: null
    };
  },
  methods: {
    // 获取北向点评/复盘数据
    handleGetCommentAndReplay () {
      getCommentAndReplay(this.pageType).then(res=>{
        if (res.status_code === 0) {
          const arr = [];
          for (const key in res.data) {
            res.data[key] && arr.push({
              type: key === 'replay_paperwork' ? '2' : '1', // 类型：点评1；复盘2。
              desc: res.data[key].content,
              url: res.data[key].link,
              pushType: res.data[key].push_type
            });
          }
          const newArr = [];
          if (this.hgtMarketStatus === 3 || this.ggtMarketStatus  === 3) {
            for (let i = 0; i < 3; i++) {
              arr.forEach((item,index)=>{
                if (i === 0 && item.pushType === 2) {
                  newArr.push(item);
                } else if (i === 1 && item.pushType === 1) {
                  newArr.push(item);
                } else if (i === 2 && item.pushType === 3) {
                  newArr.push(item);
                }
              });
            }
          } else {
            for (let i = 0; i < 3;i++) {
              arr.forEach((item,index)=>{
                if (i === 0 && item.pushType === 3) {
                  newArr.push(item);
                } else if (i === 1 && item.pushType === 2) {
                  newArr.push(item);
                } else if (i === 2 && item.pushType === 1) {
                  newArr.push(item);
                }
              });
            }
          }
          this.list = newArr.length > 1 ? [newArr[0],newArr[1],newArr[0]] : [newArr[0]];
        }
      });
    },
    // 跳转页面
    jumpDetail(item) {
      if (item.type === '2') {
        window.location.href = item.url;
      }
    }
  }
};
</script>
<style lang="less" scoped>
@import '../assets/styles/mixin.less';
@import '../assets/styles/skin.less';
.comment-and-replay {
    width: 100%;
    height: 1.44rem;
    margin-bottom: 0.12rem;
    border-radius: 0.16rem;
    background-color: @background-white;
    text-align: -webkit-center;
    overflow: hidden;
    .comment-or-replay {
        .flex(row,flex-start,center,nowrap);
        width: calc(100% - 0.6rem);
        height: 100%;
        .logo {
            height: 0.8rem;
            margin-right: 0.16rem;
        }
        .line {
            height: 0.7rem;
            margin-right: 0.24rem;
        }
        .desc {
            flex: 1;
            margin-right: 0.24rem;
            font-family: PingFangSC-Regular;
            font-size: 0.28rem;
            color: @font-major;
            text-align: left;
            line-height: 0.4rem;
            font-weight: 400;
            text-overflow: -o-ellipsis-lastline;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
        }
        .forward {
            height: 0.24rem;
        }
        &.slide {
            animation: slide 10s ease 5s infinite;
        }
    }
}
[theme-mode="black"] {
    .comment-and-replay {
        width: 100%;
        height: 1.44rem;
        margin-bottom: 0.12rem;
        border-radius: 0.16rem;
        background-color: @background-white-dark;
        text-align: -webkit-center;
        overflow: hidden;
        .comment-or-replay {
            .flex(row,flex-start,center,nowrap);
            width: calc(100% - 0.6rem);
            height: 100%;
            .logo {
                height: 0.8rem;
                margin-right: 0.16rem;
            }
            .line {
                height: 0.7rem;
                margin-right: 0.24rem;
            }
            .desc {
                flex: 1;
                margin-right: 0.24rem;
                font-family: PingFangSC-Regular;
                font-size: 0.28rem;
                color: @font-major-dark;
                text-align: left;
                line-height: 0.4rem;
                font-weight: 400;
                text-overflow: -o-ellipsis-lastline;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                line-clamp: 2;
                -webkit-box-orient: vertical;
                word-break: break-all;
            }
            .forward {
                height: 0.24rem;
            }
            &.slide {
                animation: slide 10s ease 5s infinite;
            }
        }
    }
}
@keyframes slide {
    0% {
        transform: translateY(0);
    }
    10% {
        transform: translateY(-1.44rem);
    }
    50% {
        transform: translateY(-1.44rem);
    }
    60% {
        transform: translateY(-2.88rem);
    }
    100% {
        transform: translateY(-2.88rem);
    }
}
</style>
