<template>
  <div class="date-range-box">
    <div @click="handleRangeClick(1)" :class="{ 'select-date': true, active: activeItem == 1 }">
      {{ selectDate }}
      <img
        style="margin-right: 0.15rem; width: 0.16rem;"
        src="../assets/images/icon_open.png"
        alt=""
      />
      <div class="vertical-line"></div>
    </div>
    <div @click="handleRangeClick(2)" :class="{ 'date-range-item': true, active: activeItem == 2 }">
      近5日
    </div>
    <div @click="handleRangeClick(3)" :class="{ 'date-range-item': true, active: activeItem == 3 }">
      近20日
    </div>
    <div @click="handleRangeClick(4)" :class="{ 'date-range-item': true, active: activeItem == 4 }">
      近60日
    </div>
    <div
      @click="handleRangeClick(5)"
      :class="{ 'date-range-item': true, active: activeItem == 5 }"
      style="margin-right: 0;"
    >
      区间选择
    </div>
    <hxm-calendar
      v-model="dateShow"
      :dateArr="dateArr"
      :useDefaultEntry="false"
      @confirm="handleConfirm"
    ></hxm-calendar>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectDate: '',
      // 1日期选择，2近5日，3近20日，4近60日，5区间选择
      activeItem: 1,
      dateShow: false,
      startDate: '',
      endDate: '',
    };
  },
  model: {
    prop: 'value',
    event: 'changeDateId',
  },
  props: {
    value: {
      type: Number,
      default: 1,
    },
    tradeList: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  computed: {
    dateArr() {
      const list = [];
      this.tradeList.forEach(element => {
        list.push(`${element.substr(0, 4)}/${element.substr(4, 2)}/${element.substr(6, 2)}`);
      });
      return list;
    },
  },
  watch: {
    tradeList() {
      const element = this.tradeList[this.tradeList.length - 1];
      this.selectDate = `${element.substr(0, 4)}-${element.substr(4, 2)}-${element.substr(6, 2)}`;
      this.$emit('change', 1, this.selectDate);
    },
    value(v) {
      this.activeItem = v;
    },
    activeItem(v) {
      this.$emit('changeDateId', v);
    },
  },
  methods: {
    handleConfirm(v) {
      this.selectDate = v.replace(/\//g, '-');
      this.$emit('change', 1, this.selectDate);
    },
    handleRangeClick(n) {
      if (n == this.activeItem && n == 1) {
        this.dateShow = true;
      }
      if (n != this.activeItem) {
        this.activeItem = n;
        // if (n == 5) {
        // this.$emit('change', n, this.startDate, this.endDate);
        // } else
        if (n == 1) {
          this.$emit('change', 1, this.selectDate);
        } else {
          this.$emit('change', n);
        }
      }
    },
  },
  mounted() {
    this.selectDate = `${new Date().getFullYear()}-${
      new Date().getMonth() + 1
    }-${new Date().getDate()}`;
  },
};
</script>
<style lang="less" scoped>
.vertical-line {
  display: inline-block;
  width: 1px;
  height: 12px;
  box-shadow: inset 1px 0px 0px 0px rgba(232, 232, 232, 1);
  margin-right: 0.4rem;
  vertical-align: middle;
}
.date-range-box {
  text-align: left;
  padding: 0.32rem;
  white-space: nowrap;
  padding-top: 0.06rem;
  height: 0.72rem;
  background-color: #fff;
  display: flex;
  justify-content: space-between;
  width: 100vw;
  box-sizing: border-box;
  .select-date {
    font-family: PingFangSC-Regular;
    font-size: 0.28rem;
    color: #999999;
    margin-right: 0.16rem;
  }

  .date-range-item {
    font-family: PingFangSC-Regular;
    color: #999999;
    margin-right: 0.32rem;
    font-size: 0.26rem;
    flex: 1;
    font-weight: 400;
  }

  .date-range-item:nth-last-child(1) {
    margin-right: 0rem;
  }

  .active {
    color: #323232;
    font-family: PingFangSC-Medium;
    font-weight: 500;
  }
}
[theme-mode='black'] {
  .vertical-line {
    box-shadow: inset 1px 0px 0px 0px rgba(46, 46, 46, 1);
  }
  .date-range-box {
    background-color: #121212;
    .select-date {
      color: #8e8e8e;
    }

    .date-range-item {
      color: #8e8e8e;
    }

    .active {
      color: #d2d2d3;
    }
  }
}
</style>
