<template>
  <div class="kline" ref="klineBox">
    <div class="top">
      <div class="name">
        上证指数
      </div>
      <div class="info">
        您可以参照大盘的走势情况，选取任意区间
      </div>
    </div>
    <div class="kline-chart" ref="kline">
      <div id="kline-chart"></div>
      <div ref="rangeBox" class="select-range-box"></div>
    </div>
  </div>
</template>

<script>
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
import { phoneTheme } from '@/assets/common.js';
import util from '@/lib/util.js';

export default {
  data() {
    return {
      chart: null,
      chartData: [],
      isDark: false,
      // 指标最大值
      vValue: 0,
    };
  },
  props: {
    startIndex: {
      type: Number,
      default: 0,
    },
    endIndex: {
      type: Number,
      default: 59,
    },
    klineVisible: {
      type: Boolean,
      default: false,
    },
  },
  mounted() {
    this.isDark = phoneTheme();
    // this.isDark = true;
    setTimeout(() => {
      this.updateChartData();
    });
  },
  watch: {
    startIndex() {
      this.setRangeBox();
    },
    endIndex() {
      this.setRangeBox();
    },
    klineVisible(v) {
      if (v) {
        this.chart.resize();
        this.$refs.klineBox.style.visibility = 'visible';
      } else {
        this.$refs.klineBox.style.visibility = 'hidden';
      }
    },
  },
  methods: {
    setRangeBox() {
      // 选框宽度
      const wholeWidth = this.$refs.kline.offsetWidth;
      // 单根K线宽度
      const hqbarWidth = wholeWidth / 60;
      this.$refs.rangeBox.style.marginLeft = `${this.startIndex * hqbarWidth}px`;
      this.$refs.rangeBox.style.width = `${(this.endIndex - this.startIndex + 1) * hqbarWidth}px`;
    },
    setChart() {
      const s = this;
      const color = {
        axisLine: this.isDark ? '#2e2e2e' : '#e8e8e8', // 每个标志线的颜色
        eqAxisY: this.isDark ? '#8E8E8E' : '#999999', // y坐标轴字体颜色
        areaColor: this.isDark ? '#497DE6' : '#5B91FC', // 填充区域颜色
        klineUpColor: this.isDark ? ' #E46057' : '#FF665C', // k线上涨颜色
        klineDownColor: this.isDark ? '#41AF67' : '#47C271', // k线下跌颜色
      }; // 图标颜色相关变量
      const font = {
        size: 11 * dpr * pageRate,
        weight: 500,
        family: ' THSMoneyfont-Medium',
      }; // 字体相关属性
      // 配置项
      const option = {
        data: [
          {
            originData: this.chartData,
          },
        ],
        // 坐标轴
        axis: s.getAxis(color,font),
        // 页面组件布局分布
        grid: [
          {
            left: 0,
            top: 0,
            right: 0,
            bottom: '32%',
          },
          {
            left: 0,
            top: '70%',
            right: 0,
            bottom: 0,
            background: {
              show: true,
              borderEnable: [0, 0, 0, 0],
              style: {
                stroke: color.axisLine,
              },
            },
          },
        ],
        series: [
          {
            type: 'hqbar',
            name: 'kline_price',
            hqbarType: 'kline',
            $axisIndex: [0, 1, 2],
            zlevel: 2,
            $dataIndex: 0,
            hq: {
              up: {
                stroke: color.klineUpColor,
                fill: color.klineUpColor,
              },
              down: {
                stroke: color.klineDownColor,
                fill: color.klineDownColor,
              },
            },
          },
          {
            type: 'hqbar',
            name: 'kline_vol',
            hqbarType: 'vol',
            zlevel: 2,
            $axisIndex: [0, 3, 4],
            $dataIndex: 0,
            hq: {
              up: {
                stroke: color.klineUpColor,
                fill: color.klineUpColor,
              },
              down: {
                stroke: color.klineDownColor,
                fill: color.klineDownColor,
              },
            },
          },
        ],
        animation: false,
      };
      const myChart = window.D3Charts.init('kline-chart');
      this.chart = myChart;
      myChart.setOption(option);
    },
    getAxis(color,font){
      const s=this;
      return [
        {
          // 底部x轴
          position: 'bottom',
          type: 'band',
          $gridIndex: [0, 1],
          xOrY: 'x',
          $dataIndex: 0,
          dataKey: 't',
          paddingInner: dpr == '1' ? 0.4 * dpr : 0.1 * dpr, // dpr为1时k线图会变宽导致挨在一起，所以做了区分
          paddingOuter: dpr == '1' ? 0.4 * dpr : 0.1 * dpr, // dpr为1时k线图会变宽导致挨在一起，所以做了区分
          barGap: 0,
          label: {
            show: false,
          },
          line: {
            show: false,
          },
          tick: {
            show: false,
          },
        },
        {
          // 左侧y轴
          position: 'left',
          type: 'linear',
          $gridIndex: 0,
          xOrY: 'y',
          zlevel: 1,
          // 用于判断y轴的范围，上下限最大最小值
          tickValues(domainLeft) {
            const min = domainLeft[0];
            const max = domainLeft[1];
            const detar = max - min; // 差值
            const num = [
              domainLeft[0],
              detar / 4 + domainLeft[0],
              detar / 2 + domainLeft[0],
              detar / 4 * 3 + domainLeft[0],
              domainLeft[1],
            ];
            return num;
          },
          // y轴分割线
          splitLine: {
            show: true,
            style: {
              stroke: color.axisLine,
              color: color.axisLine,
              lineWidth: 0.5 * dpr * pageRate,
            },
          },
          line: {
            show: false,
          },
          tick: {
            show: false,
          },
        },
        {
          // 左侧y轴
          position: 'left',
          type: 'linear',
          $gridIndex: 0,
          xOrY: 'y',
          zlevel: 10,
          // 用于判断y轴的范围，上下限最大最小值
          tickValues(domainLeft) {
            const min = domainLeft[0];
            const max = domainLeft[1];
            const detar = max - min; // 差值
            const num = [
              domainLeft[0],
              detar / 4 + domainLeft[0],
              detar / 2 + domainLeft[0],
              detar / 4 * 3 + domainLeft[0],
              domainLeft[1],
            ];
            return num;
          },
          label: {
            show: true,
            padding: 0,
            inRange: true,
            inside: true,
            style: {
              fill: color.eqAxisY,
              fontSize: font.size, // 字体大小
              fontWeight: font.weight,
              fontFamily: font.family,
            },
            formatter(a) {
              return a.toFixed(2);
            },
          },
          line: {
            show: false,
          },
          tick: {
            show: false,
          },
        },
        {
          position: 'left',
          type: 'linear',
          $gridIndex: 1,
          zlevel: 1,
          xOrY: 'y',
          tickValues(domain) {
            const min = domain[0];
            const max = domain[1];
            const detar = max - min; // 差值
            s.vValue = domain[1];
            return [domain[0], domain[0] + detar / 2, domain[1]];
          },
          splitLine: {
            show: true,
            style: {
              stroke: color.axisLine,
              color: color.axisLine,
              lineWidth: 0.5 * dpr * pageRate,
            },
          },
          label: {
            show: false,
            inRange: true,
            padding: 0,
            inside: true,
            style: {
              fill: color.eqAxisY,
              fontSize: font.size, // 字体大小
              fontWeight: font.weight,
              fontFamily: font.family,
            },
            formatter(v) {
              if (v == s.vValue) {
                return util.getUnitNumber2(v);
              } else {
                return '';
              }
            },
          },
          line: {
            show: false,
          },
          tick: {
            show: false,
          },
        },
        {
          position: 'left',
          type: 'linear',
          $gridIndex: 1,
          zlevel: 10,
          xOrY: 'y',
          tickValues(domain) {
            const min = domain[0];
            const max = domain[1];
            const detar = max - min; // 差值
            s.vValue = domain[1];
            return [domain[0], domain[0] + detar / 2, domain[1]];
          },
          label: {
            inRange: true,
            padding: 0,
            inside: true,
            style: {
              fill: color.eqAxisY,
              fontSize: font.size, // 字体大小
              fontWeight: font.weight,
              fontFamily: font.family,
            },
            formatter(v) {
              if (v == s.vValue) {
                return util.getUnitNumber2(v);
              } else {
                return '';
              }
            },
          },
          line: {
            show: false,
          },
          tick: {
            show: false,
          },
        },
      ];
    },
    // 更新图表数据
    updateChartData() {
      const code = 'hs_1A0001';

      // 请求kline数据时的配置
      const klinedata = {
        type: 'klineLast',
        dType: 'qfqDay',
        code,
        ma: [5, 10, 30],
        sliceDays: -60,
      };
      const dp = window.D3Charts.getDataPool();
      dp.setStatus({ enableFilterUrl: true });
      const dataProvider = window.D3Charts.getDataPool().register(klinedata);
      window.D3Charts.getDataPool().onAction(dataProvider, 'PROVIDER_UPDATE.myproject', d => {
        if (d.fetchStatus.code !== '000') return;
        this.chartData = d.data.dataArray;
        this.setChart();
      });
    },
  },
};
</script>

<style lang="less" scoped>
.kline {
  height: 4.68rem;
  position: fixed;
  visibility: hidden;
  background: #ffffff;
  box-shadow: 0px -3px 12px 0px rgba(232, 232, 232, 1);
  width: 100vw;
  bottom: 1.92rem;
  left: 0;
  border-top-left-radius: 0.2rem;
  border-top-right-radius: 0.2rem;
  padding: 0.32rem 0.32rem 0 0.32rem;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  .top {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    margin-bottom: 0.24rem;
    .name {
      font-size: 0.28rem;
      color: #323232;
      font-family: PingFangSC-Medium;
      font-weight: 600;
    }
    .info {
      font-size: 0.22rem;
      color: #999999;
      font-family: PingFangSC-Regular;
    }
  }
}
.kline-chart {
  flex: 1;
  display: flex;
  position: relative;
}
#kline-chart {
  width: 100%;
  height: 100%;
}

.select-range-box {
  width: 100%;
  height: 100%;
  background: rgba(233, 48, 48, 0.1);
  position: absolute;
  box-sizing: border-box;
  border-right: 0.03rem dashed #fa3b32;
  border-left: 0.03rem dashed #fa3b32;
}

[theme-mode='black'] {
  .kline {
    background: #191919;
    box-shadow: 0px -3px 12px 0px rgba(0, 0, 0, 1);
    .top {
      .name {
        color: #d2d2d3;
      }
      .info {
        color: #8e8e8e;
      }
    }
  }
  .select-range-box {
    background: rgba(207, 57, 48, 0.1);
    border-right: 0.03rem dashed #cf3930;
    border-left: 0.03rem dashed #cf3930;
  }
}
</style>
