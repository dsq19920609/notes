<template>
    <div class="wp" @touchstart="handleTouchMove" @touchmove="handleTouchMove">
        <div class="chartBox" id="history-chart"></div>
        <img class="watermark" src="../../assets/images/sy.png" alt="">
        <div class="select-area">
            <div class="icon1"></div>
            <div class="icon2"></div>
            <SelectList class="select" v-if="netSelect.selectable" :list="netSelect.selectList" level='2' @selectItem="changeNetType"></SelectList>
        </div>
        <div v-if="touching && showTooltip" class="tooltip" :class="{'left': tooltipPosition === 'left','right': tooltipPosition === 'right'}">
            <div class="tooltip-time">
                <div>{{tooltipData.date}}</div>
            </div>
            <div class="tooltip-item">
                <div class="title">
                    <img class="icon" :src="TlImg" alt="" v-if="exponentTypeInfo.lineType === 'kline'">
                    <div class="line orange" v-if="exponentTypeInfo.lineType === 'line'"></div>
                    {{tooltipData.content[0].label}}
                </div>
                <div class="value">
                    &nbsp;{{tooltipData.content[0].value1 != null ? `${tooltipData.content[0].value1.toFixed(2)}` : `--`}}&nbsp;
                    {{tooltipData.content[0].value2 != null ? `${numberConvert(tooltipData.content[0].value2)}%` : `--`}}
                </div>
            </div>
            <div class="tooltip-item">
                <div class="title">
                    <div class="line blue"></div>
                    {{tooltipData.content[1].label}}
                </div>
                <div class="value">
                    {{tooltipData.content[1].value != null ? `${tooltipData.content[1].value.toFixed(2)}` : `--`}}
                </div>
            </div>
            <div class="tooltip-item">
                <div class="title">
                    <div class="block" :class="{'red': tooltipData.content[2].value >= 0,'green':tooltipData.content[2].value < 0}"></div>
                    {{tooltipData.content[2].label}}
                </div>
                <div class="value">
                    {{tooltipData.content[2].value != null ? `${numberConvert(tooltipData.content[2].value)}` : `--`}}
                </div>
            </div>
        </div>
    </div>
</template>

<script>
const pageWidth = document.body.offsetWidth;
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
import SelectList from '@/components/commen/selectList';
import TlImg from '@/assets/images/tl.png';
import { phoneTheme } from '@/assets/common.js';
import {Interceptor,MobileInteractor} from './charts.js';
export default {
  name: 'HistoryflowChart',
  components: {
    SelectList
  },
  props: {
    pageType: String,
    historyFlowData: Object,
    totalNetTypeInfo: String,
    exponentTypeInfo: Object,
    dateType: String
  },
  watch: {
    historyFlowData() {
      this.init = true;
      this.updateChartData();
    },
    totalNetTypeInfo() {
      this.updateChartData();
    },
    exponentTypeInfo() {
      this.updateChartData();
    },
    netTypeInfo () {
      this.updateChartData();
    },
    touching () {
      if (this.touching) {
        document.body.style.overflowY = 'hidden';
      } else {
        this.handleAxisPointer('hide');
        document.body.style.overflowY = 'auto';
      }
    }
  },
  mounted() {
    this.isDark = phoneTheme();
  },
  data() {
    return {
      netSelect: {
        selectable: true,
        selectList: [
          {
            id: 'buy',
            label: this.pageType === 'north' ? '北向净买(亿)':'南向净买(亿)'
          },
          {
            id: 'profit',
            label: this.pageType === 'north' ? '北向盈利(亿)':'南向盈利(亿)'
          }
        ],
        switchable: true,
        seriesStatus: false,
        color: 'blue'
      },
      netTypeInfo: {
        id: '',
        label: ''
      },
      init: false,
      isDark: false,
      chart: null,
      touching: false,
      showTooltip: false,
      pointer: false,
      interceptor: null,
      mobileInteractor: null,
      xAxis: null,
      axisPointer: null,
      axisPointerViewX: null,
      axisPointerViewY: null,
      xShape: null,
      yShape: null,
      TlImg,
      tooltipPosition: 'right',
      tooltipData: {
        date: '',
        time: '',
        content: [
          {
            label: '',
            value: ''
          },
          {
            label: '',
            value: ''
          },
          {
            label: '',
            value: ''
          },
        ]
      },
      allChartData: []
    };
  },
  methods: {
    // 更新图表数据
    updateChartData() {
      if (this.init) {
        const historyChart = document.getElementById('history-chart');
        if (historyChart.firstChild) {
          historyChart.removeChild(historyChart.firstChild); // 更新图表前将图表从dom中移除，防止图表渲染不出来。
        }
        const myChart = D3Charts.init('history-chart');
        const code = window.location.search.substr(1) || this.exponentTypeInfo.code;
        const color = {
          axisLine: this.isDark ? ' #2E2E2E' : '#e8e8e8',// 每个标志线的颜色
          eqAxisX: this.isDark ? '#8e8e8e' :'#999999', // x坐标轴字体颜色
          eqAxisY: this.isDark ? '#757575' :'#b3b3b3', // y坐标轴字体颜色
          blueLine: this.isDark ? '#497DE6' : '#5B91FC',// 蓝线
          orangeLine: this.isDark ? '#E67643' : '#FF834A',// 橙线
          hoverLine: this.isDark ? '#8e8e8e' : '#999999',  // 悬停十字线颜色
          titleFront: this.isDark ? '#8e8e8e' : '#999999',// 小标题字体颜色
          legendFront: this.isDark ? '#8e8e8e' : '#999999',// 上筛选字体颜色
          areaColor: this.isDark ? '#497DE6' : '#5B91FC',// 填充区域颜色
          klineUpColor: this.isDark ? ' #E46057' : '#FF665C', // k线上涨颜色
          klineDownColor: this.isDark ? '#41AF67' : '#47C271',// k线下跌颜色
          upBarcolor: this.isDark ? ' #E46057' : '#FF665C',// 上涨柱状图颜色
          downBarcolor: this.isDark ? '#41AF67' : '#47C271'// 下跌柱状图颜色
        }; // 图标颜色相关变量
        const font = {
          size: 13 *dpr * pageRate,
          weight: 500,
          family: ' THSMoneyfont-Medium'
        };// 字体相关属性
        // 请求kline数据时的配置
        const klinedata = {
          type: 'klineCommon',
          dType: `qfq${this.dateType}`,
          code,
          ma: [5, 10, 30]
        };
        const dp = D3Charts.getDataPool();
        dp.setStatus({ enableFilterUrl: true });
        const dataProvider = D3Charts.getDataPool().register(klinedata);
        D3Charts.getDataPool().onAction(dataProvider, 'PROVIDER_UPDATE.myproject', d => {
          if (d.fetchStatus.code !== '000') return;
          const minValueSpan = 20; // 最小时间间距为20天
          let Data = d.data.dataArray.slice(-this.historyFlowData.chartData.length); // 获取数据-k线图接口获取原始数据
          Data = Data.map((item,index)=>{
            for (const key in this.historyFlowData.chartData[index]) {
              this.$set(item,key,this.historyFlowData.chartData[index][key]);
            }
            return item;
          });
          this.allChartData = Data;
          // 配置项
          const option = {
            data: [
              {
                originData: Data
              }
            ],
            // 坐标轴
            axis: [
              {
                // 底部x轴
                position: 'bottom',
                type: 'band',
                $gridIndex: [0, 1],
                xOrY: 'x',
                $dataIndex: 0,
                dataKey: 'date',
                paddingInner: dpr == '1' ? 0.4 * dpr : 0.1 * dpr, // dpr为1时k线图会变宽导致挨在一起，所以做了区分
                paddingOuter: dpr == '1' ? 0.4 * dpr : 0.1 * dpr, // dpr为1时k线图会变宽导致挨在一起，所以做了区分
                barGap: 0,
                $dataZoomIndex: 0,
                // 用于判断当前页面最大的值的效果
                tickValues (domain) {
                  //间隔是20天一个间隔
                  return [domain[0], domain[19], domain[39], domain[59]];
                },
                label: {
                  padding: 10 * dpr * pageRate,
                  inRange: true,
                  style: {
                    fill: color.eqAxisX,
                    fontSize: font.size,
                    fontFamily: font.family
                  },
                  // x的时间轴-数据拆分
                  formatter (time) {
                    return `${time.slice(4,6)}-${time.slice(6)}`;
                  }
                },
                line: {
                  show: false
                },
                tick: {
                  show: false
                }
              },
              {
                // 右侧y轴指数类型数据展示(k线图)
                position: 'right',
                type: 'linear',
                $gridIndex: 0,
                xOrY: 'y',
                // 用于判断右侧y轴的范围，上下限最大最小值
                tickValues (domainRight,i) {
                  const min = domainRight[0];
                  const max = domainRight[1];
                  const detar = max - min;
                  return [domainRight[0], detar / 4 + domainRight[0], detar * 2 / 4 + domainRight[0], detar * 3 / 4 + domainRight[0], domainRight[1]];
                },
                // y轴分割线
                splitLine: {
                  show: false,
                  style: {
                    stroke: color.axisLine,
                    color: color.axisLine,
                    lineDash: [3* dpr *pageRate, 3* dpr *pageRate],
                    lineWidth: 1 * dpr *pageRate
                  }
                },
                label: {
                  // 右侧文字内容样式
                  padding: 0,
                  inRange: true,
                  inside: true,
                  style: {
                    fill: color.eqAxisY,
                    fontSize: font.size,
                    fontWeight: font.weight,
                    fontFamily: font.family,
                    textAlign: 'right'
                  },
                  formatter(a) {
                    return  Math.round(a);
                  },
                },
                line: {
                  show: false
                },
                tick: {
                  show: false
                }
              },
              {
                // 左侧y轴
                position: 'left',
                type: 'linear',
                $gridIndex: 0,
                xOrY: 'y',
                // 用于判断y轴的范围，上下限最大最小值
                tickValues (domainLeft) {
                  const min = domainLeft[0];
                  const max = domainLeft[1];
                  const detar = max - min; // 差值
                  const num = [domainLeft[0], detar / 4 + domainLeft[0], detar * 2 / 4 + domainLeft[0], detar * 3 / 4 + domainLeft[0], domainLeft[1]];
                  return num;
                },
                // y轴分割线
                splitLine: {
                  show: true,
                  style: {
                    stroke: color.axisLine,
                    color: color.axisLine,
                    lineDash: [3* dpr *pageRate, 3* dpr *pageRate],
                    lineWidth: 1 * dpr *pageRate
                  }
                },
                label: {
                  show: true,
                  padding: 0,
                  inRange: true,
                  inside: true,
                  style: {
                    fill: color.eqAxisY,
                    fontSize: font.size,// 字体大小
                    fontWeight: font.weight,
                    fontFamily: font.family
                  },
                  formatter (a, count, allNum) {
                    const labelValue = Math.round(a);
                    return labelValue;
                  },
                },
                line: {
                  show: false
                },
                tick: {
                  show: false
                }
              },
              {
                // 右侧轴用于展示涨幅变化情况（用于底部的柱状图）
                position: 'left',
                type: 'linear',
                $gridIndex: 1,
                domainEqualZero: [0, 1],
                xOrY: 'y',
                // 用于判断y轴的范围，上下限最大最小值，这里只有两个值所以其他的不需要展示
                tickValues (domainDown) {
                  const min = domainDown[0];
                  const max = domainDown[1];
                  return [min, max];
                },
                // y轴分割线
                splitLine: {
                  show: true,
                  style: {
                    stroke: color.axisLine,
                    color: color.axisLine,
                    lineDash: [3* dpr *pageRate, 3* dpr *pageRate],
                    lineWidth: 1 * dpr *pageRate
                  }
                },
                label: {
                  show: true,
                  padding: 0,
                  inRange: true,
                  inside: true,
                  style: {
                    fill: color.eqAxisY,
                    fontSize: font.size,
                    fontWeight: font.weight,
                    fontFamily: font.family
                  },
                  formatter (a, count, allNum) {
                    const labelValue = Math.floor(a * 100) / 100;
                    return labelValue;
                  },
                },
                line: {
                  show: false
                },
                tick: {
                  show: false
                }
              }
            ],
            // 页面组件布局分布
            grid: [
              {
                // 绘制顶部模块
                left: 0,
                right: 0,
                top: 0,
                bottom: '48%',
                background: {
                  show: true,
                  borderEnable: [0, 0, 0, 0],
                  style: {
                    stroke: color.axisLine,
                  }
                },
              },
              {
                // 绘制底部模块（也就是柱状图部分top可以压缩图表）
                left: 0,
                right: 0,
                top: 224 * dpr * pageRate,
                bottom: 2 * dpr *pageRate,
                background: {
                  show: true,
                  borderEnable: [0, 0, 0, 0],
                  style: {
                    stroke: color.axisLine,
                  }
                }
              }
            ],
            // 光标放置在那里那么那里就会出现这个提示柱
            axisPointer: [
              // 垂直实线
              {
                $axisIndex: 0,
                line: {
                  style: {
                    stroke: color.hoverLine,
                    lineWidth: 1 * dpr *pageRate
                  }
                },
                label: {
                  show: false
                }
              },
            ],
            dataZoom: [
              {
                $gridIndex: [0, 1],
                minValueSpan,
                startValue: -60, // 六十个工作日展示
                pressStop: true
              }
            ],
            series: [
              {
                type: 'hqbar',
                hqbarType: 'kline',
                name: 'k线指数',
                $axisIndex: [0, 1],
                $dataIndex: 0,
                line: {
                  show: this.exponentTypeInfo.lineType === 'kline'
                },
                hq: {
                  up: {
                    stroke: color.klineUpColor,
                    fill: color.klineUpColor
                  },
                  down: {
                    stroke: color.klineDownColor,
                    fill: color.klineDownColor
                  },
                }
              },
              {
                type: 'line',
                aliasType: 'hqline',
                $axisIndex: [0, 2],
                $dataIndex: 0,
                dataKey: this.totalNetTypeInfo.id === 'totalBuy' ? 'totalNetBuy' : 'totalProfit',
                name: this.totalNetTypeInfo.id === 'totalBuy' ? '累计净买' : '累计盈利',
                symbol: {
                  emphasis: {
                    show: false,
                    size: 5, // 内部点大小
                    style: {
                      fill: color.blueLine,// 标识符内部填充颜色
                      stroke: 'rgba(91.215, 61, 25, 0.25)',// 外部填充颜色色号
                      lineWidth: 6 //外部圈范围大小
                    }
                  }
                },
                line: {
                  show: true,
                  style: {
                    normal: {
                      stroke: color.blueLine,
                      lineWidth: 1.5 * dpr *pageRate
                    }
                  }
                },
                area: {
                  show: true,
                  style: {
                    normal: {
                      fill: {
                        y2: 1,
                        x2: 0,
                        colorStops: [
                          {
                            offset: 0,
                            color: color.blueLine
                          },
                          {
                            offset: 1,
                            color: this.isDark ? 'black' : 'white'
                          },
                        ]

                      },
                      opacity: 0.2
                    }
                  },
                  opacity: 0.2
                }
              },
              {
                type: 'bar',
                name: '净买入/净盈利',
                $dataIndex: 0,
                dataKey: this.netTypeInfo.id === 'buy' ? 'netBuy' : 'profit',
                $axisIndex: [0, 3],
                itemStyle: {
                  // 判断柱状图颜色赋值模块
                  normal (data) {
                    if (data[1] > 0) {
                      return {
                        fill: color.upBarcolor
                      };
                    } else {
                      return {
                        fill: color.downBarcolor
                      };
                    }
                  },
                  emphasis: {
                    opacity: 0.8
                  }
                },
              },
              {
                type: 'line',
                $dataIndex: 0,
                dataKey: 'c',
                name: '折线指数',
                $axisIndex: [0, 1],
                line: {
                  show: this.exponentTypeInfo.lineType !== 'kline',
                  style: {
                    normal: {
                      stroke: color.orangeLine,
                      lineWidth: 1 * dpr *pageRate
                    }
                  }
                },
              },
            ],
            tooltip: [
              {
                trigger: 'axis',
                $axisIndex: 0,
              },
            ],
            animation: false,
          };
          if (!this.interceptor) {
            this.interceptor = new Interceptor(myChart._dom, 300, this.setTouching, this.setPointer);
          }
          this.chart = myChart;
          myChart.setOption(option);
          this.xAxis = myChart.getModel('axis', 0);
          this.axisPointer = myChart.getModel('axisPointer');
          this.axisPointerViewX = myChart.getViewOfComponentModel(this.axisPointer[0]);
          const axisModel = myChart.getModel('axis', 0);
          myChart.registerAction(axisModel, 'AXIS_MOVE', this.onChartMove);
          myChart.registerAction(axisModel, 'AXIS_OUT', this.onChartOut);
          this.mobileInteractor = new MobileInteractor(myChart,this.setShowTooltip);
        });
      }
    },
    // 切换净值类型(净买入/盈利)
    changeNetType(item) {
      this.netTypeInfo = {
        id: item.id,
        label: item.label
      };
    },
    // 四舍五入并保留两位小数
    numberConvert(value) {
      return  `${value >0 ? '+': ''}${value.toFixed(2)}`;
    },
    setTouching (value) {
      this.touching = value;
    },
    setPointer (value) {
      this.pointer = value;
    },
    setShowTooltip (value) {
      this.showTooltip = value;
    },
    onChartMove (e) {
      this.pointer = true;
      this.setTooltip(e.dataIndex);
    },
    onChartOut () {
      this.pointer = false;
    },
    handleTouchMove (e) {
      if (this.touching && !this.pointer) {
        const { clientX } = e.touches[0];
        const { x } = this.chart._dom.children[0].children[0].getBoundingClientRect();
        const _x = clientX - x;
        const xRange = this.xAxis.range;
        const xDelta = xRange[1] - xRange[0];
        const xTotal = this.xAxis.domain.length;
        let xIndex = Math.floor((_x - xRange[0]) / xDelta * xTotal);
        xIndex = xIndex < 0 ? 0 : xIndex > xTotal - 1 ? xTotal - 1 : xIndex;
        this.handleAxisPointer('show', xIndex);
        this.setTooltip(xIndex+this.xAxis.startIndex);
      }
    },
    // 控制坐标指示线显示与隐藏
    handleAxisPointer (type, xIndex) {
      this.xShape = this.axisPointerViewX._shapeMap;
      for (const shape in this.xShape) {
        const timer = setTimeout(() => {
          clearTimeout(timer);
          this.xShape[shape][type]();
        });
        if (typeof xIndex === 'number' && type === 'show') {
          let x = this.xAxis.scale(this.xAxis.domain[xIndex]);
          if (~shape.indexOf('label')) {
            // 绘制x轴竖线
            const xRange = this.xAxis.range;
            const outerWidth = (this.xShape[shape]?.__textCotentBlock?.outerWidth || 74) / 2;
            x = x - outerWidth < xRange[0] ? xRange[0] + outerWidth : x;
            x = x + outerWidth > xRange[1] ? xRange[1] - outerWidth : x;
            const pos = this.xShape[shape].position;
            this.xShape[shape].attr('position', [x, pos[1]]);
            this.xShape[shape].style.text = this.xAxis.domain[xIndex];
          } else {
            this.xShape[shape].attr('shape', {...this.xShape[shape].shape, x1: x, x2: x});
          }
        }
      }
    },
    // 设置tooltip的位置与值
    setTooltip (xIndex) {
      this.tooltipPosition = xIndex > (this.xAxis.startIndex+ this.xAxis.endIndex)/2 ? 'left': 'right';
      this.tooltipData = {
        date: `${this.allChartData[xIndex].t.slice(0,4)}-${this.allChartData[xIndex].t.slice(4,6)}-${this.allChartData[xIndex].t.slice(6,8)}`,
        content: [
          {
            label: this.exponentTypeInfo.label,
            value1: this.allChartData[xIndex].c,
            value2: (this.allChartData[xIndex].c/this.allChartData[xIndex].yc-1)*100
          },
          {
            label: this.totalNetTypeInfo.label,
            value: this.totalNetTypeInfo.id === 'totalBuy' ? this.allChartData[xIndex].totalNetBuy : this.allChartData[xIndex].totalProfit
          },
          {
            label: this.pageType === 'north' ? this.netTypeInfo.id === 'buy' ? '北向净买(亿)':'北向盈利(亿)' : this.netTypeInfo.id === 'buy' ? '南向净买(亿)':'南向盈利(亿)',
            value: this.netTypeInfo.id === 'buy' ? this.allChartData[xIndex].netBuy : this.allChartData[xIndex].profit
          },
        ]
      };
    }
  },
};
</script>

<style lang="less" scoped>
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
    .wp {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        .watermark {
            position: absolute;
            width: 0.72rem;
            right: 0.8rem;
            top: 42%;
        }
        .select-area {
            .flex(row, flex-start, center, nowrap);
            position: absolute;
            top: 3.8rem;
            left: 0;
            .icon1 {
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.04rem;
                background: #FF665C;
                border-radius: 0.02rem;
            }
            .icon2 {
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.08rem;
                background: #47C271;
                border-radius: 0.02rem;
            }
        }
    }
    .chartBox {
        width: 6.86rem;
        height: 5.75rem;
        background-color: transparent;
        margin-bottom: 0.48rem;
    }
</style>
<style lang="less">
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.wp {
    .tooltip-time {
        font-family: THSMoneyfont-Medium;
        font-size: 0.22rem;
        color: @font-white;
        font-weight: 500;
        margin-left: 0.16rem;
        margin-bottom: 0.06rem;
    }
    .tooltip-item {
        .flex(row,space-between,center,nowrap);
        margin: 0 0.16rem 0.08rem 0.16rem;
        .icon {
            width: 0.2rem;
            height: 0.2rem;
            margin-right: 0.06rem;
        }
        .line {
            display: inline-block;
            width: 0.12rem;
            height: 0.04rem;
            margin-right: 0.14rem;
            border-radius: 0.02rem;
            &.blue {
                background: @line-blue;
            }
            &.orange {
                background: @line-orange;
            }
        }
        .block {
            display: inline-block;
            width: 0.12rem;
            height: 0.12rem;
            margin-right: 0.14rem;
            border-radius: 0.02rem;
            &.red {
                background: #FF665C;
            }
            &.green {
                background: #47C271;
            }
        }
        .blank {
            display: inline-block;
            width: 0.12rem;
            height: 0.12rem;
            margin-right: 0.14rem;
        }
        .title {
            .flex(row,space-between,center,nowrap);
            font-family: PingFangSC-Regular;
            font-size: 0.24rem;
            color: @font-white;
            font-weight: 400;
        }
        .value {
            font-family: THSMoneyfont-Medium;
            font-size: 0.24rem;
            color: @font-white;
            font-weight: 500;
        }
    }
    .tooltip {
        position: absolute;
        top: 0;
        min-width: 3.5rem;
        border-radius: 0.08rem;
        background: #323232;
        text-align: left;
        opacity: 0.8;
        padding: 0.16rem 0;
        &.left {
            left: 0;
        }
        &.right {
            right: 0;
        }
        .tooltip-time {
            font-family: THSMoneyfont-Medium;
            font-size: 0.22rem;
            color: @font-white;
            font-weight: 500;
            margin-left: 0.16rem;
            margin-bottom: 0.06rem;
        }
        .tooltip-item {
            .flex(row,space-between,center,nowrap);
            margin: 0 0.16rem 0.08rem 0.16rem;
            .icon {
                width: 0.2rem;
                height: 0.2rem;
                margin-right: 0.06rem;
            }
            .line {
                display: inline-block;
                width: 0.12rem;
                height: 0.04rem;
                margin-right: 0.14rem;
                border-radius: 0.02rem;
                &.blue {
                    background: @line-blue;
                }
                &.green {
                    background: @line-green;
                }
                &.pink {
                    background: @line-pink;
                }
                &.orange {
                    background: @line-orange;
                }
            }
            .blank {
                display: inline-block;
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.14rem;
            }
            .title {
                .flex(row,space-between,center,nowrap);
                font-family: PingFangSC-Regular;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 400;
            }
            .value {
                font-family: THSMoneyfont-Medium;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 500;
                text-align: right;
            }
        }
    }
}
[theme-mode="black"] {
    .wp {
        .tooltip-time {
            font-family: THSMoneyfont-Medium;
            font-size: 0.22rem;
            color: @font-white;
            font-weight: 500;
            margin-left: 0.16rem;
            margin-bottom: 0.06rem;
        }
        .tooltip-item {
            .flex(row,space-between,center,nowrap);
            margin: 0 0.16rem 0.08rem 0.16rem;
            .icon {
                width: 0.2rem;
                height: 0.2rem;
                margin-right: 0.06rem;
            }
            .line {
                display: inline-block;
                width: 0.12rem;
                height: 0.04rem;
                margin-right: 0.14rem;
                border-radius: 0.02rem;
                &.blue {
                    background: @line-blue-dark;
                }
                &.orange {
                    background: @line-orange-dark;
                }
            }
            .block {
                display: inline-block;
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.14rem;
                border-radius: 0.02rem;
                &.red {
                    background: #FF665C;
                }
                &.green {
                    background: #47C271;
                }
            }
            .blank {
                display: inline-block;
                width: 0.12rem;
                height: 0.12rem;
                margin-right: 0.14rem;
            }
            .title {
                .flex(row,space-between,center,nowrap);
                font-family: PingFangSC-Regular;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 400;
            }
            .value {
                font-family: THSMoneyfont-Medium;
                font-size: 0.24rem;
                color: @font-white;
                font-weight: 500;
            }
        }
        .tooltip {
            position: absolute;
            top: 0;
            min-width: 3.5rem;
            border-radius: 0.08rem;
            background: #323232;
            text-align: left;
            opacity: 0.8;
            padding: 0.16rem 0;
            &.left {
                left: 0;
            }
            &.right {
                right: 0;
            }
            .tooltip-time {
                font-family: THSMoneyfont-Medium;
                font-size: 0.22rem;
                color: @font-white;
                font-weight: 500;
                margin-left: 0.16rem;
                margin-bottom: 0.06rem;
            }
            .tooltip-item {
                .flex(row,space-between,center,nowrap);
                margin: 0 0.16rem 0.08rem 0.16rem;
                .icon {
                    width: 0.2rem;
                    height: 0.2rem;
                    margin-right: 0.06rem;
                }
                .line {
                    display: inline-block;
                    width: 0.12rem;
                    height: 0.04rem;
                    margin-right: 0.14rem;
                    border-radius: 0.02rem;
                    &.blue {
                        background: @line-blue;
                    }
                    &.green {
                        background: @line-green;
                    }
                    &.pink {
                        background: @line-pink;
                    }
                    &.orange {
                        background: @line-orange;
                    }
                }
                .blank {
                    display: inline-block;
                    width: 0.12rem;
                    height: 0.12rem;
                    margin-right: 0.14rem;
                }
                .title {
                    .flex(row,space-between,center,nowrap);
                    font-family: PingFangSC-Regular;
                    font-size: 0.24rem;
                    color: @font-white;
                    font-weight: 400;
                }
                .value {
                    font-family: THSMoneyfont-Medium;
                    font-size: 0.24rem;
                    color: @font-white;
                    font-weight: 500;
                }
            }
        }
    }
}
</style>
