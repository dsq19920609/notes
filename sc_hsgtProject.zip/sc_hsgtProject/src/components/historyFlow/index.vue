<template>
  <div class="history-flow">
    <div class="header">
      <div class="title-and-time">
        <div class="title">历史流向</div>
        <!-- <div class="time">更新于06-16 18:00</div> -->
      </div>
      <SelectList :list="dataTypeList" level="1" @selectItem="changeDateType"></SelectList>
    </div>
    <div class="net-buy">
      <template v-for="(item, index) in historyFlowData.netBuyList">
        <div class="list-item" :key="index">
          <div class="desc">{{ item.desc }}</div>
          <div class="value" :class="{ red: item.value >= 0 }">
            {{ item.value | numberConvert }}<span style="fontsize: 0.26rem;">亿</span>
          </div>
        </div>
      </template>
    </div>
    <div class="legend">
      <div class="series-legend">
        <div class="line" :class="{ blue: totalSelect.color === 'blue' }"></div>
        <SelectList
          v-if="totalSelect.selectable"
          :list="totalSelect.selectList"
          level="2"
          @selectItem="changeTotalType"
        ></SelectList>
      </div>
      <div class="series-legend">
        <SelectList
          v-if="exponentSelect.selectable"
          :list="exponentSelect.selectList"
          level="2"
          @selectItem="changeExponentTypeInfo"
        ></SelectList>
      </div>
    </div>
    <HistoryFlowChart
      :pageType="pageType"
      :historyFlowData="historyFlowData"
      :totalNetTypeInfo="totalNetTypeInfo"
      :exponentTypeInfo="exponentTypeInfo"
      :dateType="dateType"
    ></HistoryFlowChart>
  </div>
</template>
<script>
import SelectList from '@/components/commen/selectList';
import HistoryFlowChart from '@/components/historyFlow/historyFlowChart';
import { getHistoryFlowData } from '@/apis/index';
export default {
  name: 'HistoryFlow',
  components: {
    SelectList,
    HistoryFlowChart,
  },
  props: {
    pageType: String,
    hgtMarketStatus: Number,
    ggtMarketStatus: Number,
  },
  watch: {
    pageType() {
      this.handleGetHistoryFlowData();
    },
  },
  mounted() {
    this.timer = setInterval(() => {
      if (this.hgtMarketStatus === 3 || this.ggtMarketStatus === 3) {
        this.handleGetHistoryFlowData();
      }
    }, 180000);
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  data() {
    return {
      dataTypeList: [
        {
          id: 'day',
          label: '按日',
        },
        {
          id: 'week',
          label: '按周',
        },
        {
          id: 'month',
          label: '按月',
        },
      ],
      dateType: '',
      totalSelect: {
        selectable: null,
        switchable: null,
        seriesStatus: null,
        color: '',
        selectList: [],
      },
      exponentSelect: {
        id: '2',
        selectable: null,
        switchable: null,
        seriesStatus: null,
        color: '',
        selectList: [],
      },
      historyFlowData: {
        netBuyList: [],
      },
      totalNetTypeInfo: {
        id: '',
        label: '',
      },
      exponentTypeInfo: {
        code: '',
        lineType: '',
        label: '',
      },
      timer: null,
    };
  },
  methods: {
    // 获取历史流向数据
    handleGetHistoryFlowData() {
      getHistoryFlowData(this.pageType, this.dateType).then(res => {
        const chartData = [];
        res.data.trade_time_list.forEach((item, index) => {
          chartData.push({
            date: item,
            totalNetBuy: null,
            totalProfit: null,
            netBuy: null,
            profit: null,
            twoWeekNetBuyList: null,
            twoWeekProfitList: null,
          });
        });
        res.data.total_net_buy.total_net_buy_list.forEach((item, index) => {
          chartData[index].totalNetBuy = item;
        });
        res.data.total_profit.total_profit_list.forEach((item, index) => {
          chartData[index].totalProfit = item;
        });
        res.data.net_buy.total_net_buy_list.forEach((item, index) => {
          chartData[index].netBuy = item;
        });
        res.data.profit.total_profit_list.forEach((item, index) => {
          chartData[index].profit = item;
        });
        res.data.net_buy.two_week_net_buy_list.forEach((item, index) => {
          chartData[index].twoWeekNetBuyList = item;
        });
        res.data.profit.two_week_profit_list.forEach((item, index) => {
          chartData[index].twoWeekProfitList = item;
        });
        this.historyFlowData = {
          netBuyList: [
            {
              desc: '近60日净买',
              value: res.data.net_buy_sixty_day,
            },
            {
              desc: '近30日净买',
              value: res.data.net_buy_thirty_day,
            },
            {
              desc: '近10日净买',
              value: res.data.net_buy_ten_day,
            },
            {
              desc: '近5日净买',
              value: res.data.net_buy_five_day,
            },
          ],
          chartData,
        };
      });
    },
    // 切换累计类型(累计净买/盈利)
    changeTotalType(item) {
      this.totalNetTypeInfo = {
        id: item.id,
        label: item.label,
      };
      if (this.pageType == 'north') {
        if (item.id == 'totalProfit') {
          window.hxmClickStat('hsgt.lgt.lslx.bxljyl');
        } else {
          window.hxmClickStat('hsgt.lgt.lslx.bxljjm');
        }
      } else {
        if (item.id == 'totalProfit') {
          window.hxmClickStat('hsgt.ggt.lslx.bxljyl');
        } else {
          window.hxmClickStat('hsgt.ggt.lslx.bxljjm');
        }
      }
    },
    // 切换指数类型(上证指数/深证成指/沪深300)
    changeExponentTypeInfo(item) {
      this.exponentTypeInfo = {
        code: item.code,
        lineType: item.lineType,
        label: item.label,
      };

      const str=this.pageType == 'north' ? 'lgt' : 'ggt';
      switch (item.id) {
      case 1:
        window.hxmClickStat(`lsgt.${str}.lslx.kx.szzs`);
        break;
      case 2:
        window.hxmClickStat(`lsgt.${str}.lslx.zx.szzs`);
        break;
      case 3:
        window.hxmClickStat(`lsgt.${str}.lslx.kx.szcz`);
        break;
      case 4:
        window.hxmClickStat(`lsgt.${str}.lslx.zx.szcz`);
        break;
      case 5:
        window.hxmClickStat(`lsgt.${str}.lslx.kx.zybz`);
        break;
      case 6:
        window.hxmClickStat(`lsgt.${str}.lslx.zx.zybz`);
        break;
      default:
      }
    },
    // 切换时间区间(按日/周/月)
    changeDateType(item) {
      this.dateType = item.id;
      switch (true) {
      // 陆股通
      case this.pageType === 'north':
        this.totalSelect = {
          selectable: true,
          switchable: false,
          seriesStatus: false,
          color: 'blue',
          selectList: [
            {
              id: 'totalBuy',
              label: '北向累计净买(亿)',
            },
            {
              id: 'totalProfit',
              label: '北向累计盈利(亿)',
            },
          ],
        };
        this.exponentSelect = {
          id: '2',
          selectable: true,
          switchable: false,
          seriesStatus: true,
          color: '',
          selectList: [
            {
              id: '1',
              label: '上证指数',
              lineType: 'kline',
              color: '',
              code: 'hs_1A0001',
            },
            {
              id: '2',
              label: '上证指数',
              lineType: 'line',
              color: 'orange',
              code: 'hs_1A0001',
            },
            {
              id: '3',
              label: '深证成指',
              lineType: 'kline',
              color: '',
              code: 'hs_399001',
            },
            {
              id: '4',
              label: '深证成指',
              lineType: 'line',
              color: 'orange',
              code: 'hs_399001',
            },
            {
              id: '5',
              label: '创业板指',
              lineType: 'kline',
              color: '',
              code: 'hs_399006',
            },
            {
              id: '6',
              label: '创业板指',
              lineType: 'line',
              color: 'orange',
              code: 'hs_399006',
            },
          ],
        };
        window.hxmClickStat(`hsgt.lgt.lslx.${item.id}`);
        break;
        // 港股通
      case this.pageType === 'south':
        this.totalSelect = {
          selectable: true,
          switchable: false,
          seriesStatus: false,
          color: 'blue',
          selectList: [
            {
              id: 'totalBuy',
              label: '南向累计净买(亿)',
            },
            {
              id: 'totalProfit',
              label: '南向累计盈利(亿)',
            },
          ],
        };
        this.exponentSelect = {
          id: '2',
          selectable: true,
          switchable: false,
          seriesStatus: true,
          color: '',
          selectList: [
            {
              id: '1',
              label: '恒生指数',
              lineType: 'kline',
              color: '',
              code: 'hk_HSI',
            },
            {
              id: '2',
              label: '恒生指数',
              lineType: 'line',
              color: 'orange',
              code: 'hk_HSI',
            },
            {
              id: '3',
              label: '国企指数',
              lineType: 'kline',
              color: '',
              code: 'hk_HSCEI',
            },
            {
              id: '4',
              label: '国企指数',
              lineType: 'line',
              color: 'orange',
              code: 'hk_HSCEI',
            },
          ],
        };
        window.hxmClickStat(`hsgt.ggt.lslx.${item.id}`);
        break;
      default:
        break;
      }
      this.handleGetHistoryFlowData();
    },
  },
};
</script>
<style lang="less" scoped>
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.history-flow {
  .flex(column,flex-start,center,nowrap);
  width: 100%;
  margin-bottom: 0.16rem;
  border-radius: 0.16rem;
  background-color: @background-white;
  .header {
    width: calc(100% - 0.64rem);
    margin: 0.4rem 0 0.4rem;
    .flex(row,space-between,center,nowrap);
    .title-and-time {
      .flex(row,flex-start,center,nowrap);
      .title {
        margin-right: 0.36rem;
        font-size: 0.36rem;
        color: @font-most-major;
        line-height: 0.5rem;
        font-weight: 700;
        text-align: left;
      }
      .time {
        font-family: PingFangSC-Regular;
        font-size: 0.24rem;
        color: @font-general-major;
        font-weight: 400;
      }
    }
  }
  .net-buy {
    .flex(row,space-between,center,nowrap);
    width: calc(100% - 0.88rem);
    padding: 0 0.12rem;
    height: 1.2rem;
    background: @background-net-purchase;
    border-radius: 0.12rem;
    .list-item {
      .desc {
        margin-bottom: 0.08rem;
        font-family: PingFangSC-Regular;
        font-size: 0.26rem;
        color: @font-major;
        text-align: center;
        line-height: 0.36rem;
        font-weight: 400;
      }
      .value {
        font-family: THSMoneyfont-Medium;
        font-size: 0.28rem;
        color: @font-green;
        text-align: center;
        line-height: 0.36rem;
        font-weight: 500;
        &.red {
          color: @font-red;
        }
      }
    }
  }
  .legend {
    .flex(row,flex-start,center,nowrap);
    width: calc(100% - 0.64rem);
    margin-top: 0.32rem;
    margin-bottom: 0.4rem;
    .series-legend {
      .flex(row,flex-start,center,nowrap);
      margin-right: 0.28rem;
      .switch-btn {
        position: relative;
        margin-right: 0.12rem;
        .out-circle {
          width: 0.2rem;
          height: 0.2rem;
          border: 0.01rem solid @font-general-major;
          border-radius: 50%;
          &.blue {
            border: 0.01rem solid @line-blue;
          }
        }
        .inner-circle {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 0.18rem;
          height: 0.18rem;
          border-radius: 50%;
          &.blue {
            background-color: @line-blue;
          }
        }
      }
      .line {
        width: 0.12rem;
        height: 0.04rem;
        margin-right: 0.08rem;
        border-radius: 0.02rem;
        &.blue {
          background: @line-blue;
        }
      }
    }
  }
}

[theme-mode='black'] {
  .history-flow {
    .flex(column,flex-start,center,nowrap);
    width: 100%;
    margin-bottom: 0.16rem;
    border-radius: 0.16rem;
    background-color: @background-white-dark;
    .header {
      width: calc(100% - 0.64rem);
      margin: 0.4rem 0 0.4rem;
      .flex(row,space-between,center,nowrap);
      .title-and-time {
        .flex(row,flex-start,center,nowrap);
        .title {
          margin-right: 0.36rem;
          font-size: 0.36rem;
          color: @font-most-major-dark;
          line-height: 0.5rem;
          font-weight: 700;
          text-align: left;
        }
        .time {
          font-family: PingFangSC-Regular;
          font-size: 0.24rem;
          color: @font-general-major-dark;
          font-weight: 400;
        }
      }
    }
    .net-buy {
      .flex(row,space-between,center,nowrap);
      width: calc(100% - 0.88rem);
      padding: 0 0.12rem;
      height: 1.2rem;
      background: @background-net-purchase-dark;
      border-radius: 0.12rem;
      .list-item {
        .desc {
          margin-bottom: 0.08rem;
          font-family: PingFangSC-Regular;
          font-size: 0.26rem;
          color: @font-major-dark;
          text-align: center;
          line-height: 0.36rem;
          font-weight: 400;
        }
        .value {
          font-family: THSMoneyfont-Medium;
          font-size: 0.28rem;
          color: @font-green-dark;
          text-align: center;
          line-height: 0.36rem;
          font-weight: 500;
          &.red {
            color: @font-red-dark;
          }
        }
      }
    }
    .legend {
      .flex(row,flex-start,center,nowrap);
      width: calc(100% - 0.64rem);
      margin-top: 0.32rem;
      margin-bottom: 0.4rem;
      .series-legend {
        .flex(row,flex-start,center,nowrap);
        margin-right: 0.28rem;
        .switch-btn {
          position: relative;
          margin-right: 0.12rem;
          .out-circle {
            width: 0.2rem;
            height: 0.2rem;
            border: 0.01rem solid @font-general-major-dark;
            border-radius: 50%;
            &.blue {
              border: 0.01rem solid @line-blue-dark;
            }
          }
          .inner-circle {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 0.18rem;
            height: 0.18rem;
            border-radius: 50%;
            &.blue {
              background-color: @line-blue-dark;
            }
          }
        }
        .line {
          width: 0.12rem;
          height: 0.04rem;
          margin-right: 0.08rem;
          border-radius: 0.02rem;
          &.blue {
            background: @line-blue-dark;
          }
        }
      }
    }
  }
}
</style>
