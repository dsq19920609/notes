// 控制图标无效滑动
export class Interceptor {
    constructor(dom, time, setTouch, setPointer) {
      this.posX = 0;
      this.posY = 0;
      this.start = null;
      this._dom = dom;
      this._time = time;
      this.onTouchStart = this.onTouchStart.bind(this);
      this.onTouchMove = this.onTouchMove.bind(this);
      this.onTouchEnd = this.onTouchEnd.bind(this);
      this.locked = true;
      this.setTouch = setTouch;
      this.setPointer = setPointer;
      dom.addEventListener('touchstart', this.onTouchStart, true);
      dom.addEventListener('touchmove', this.onTouchMove, true);
      dom.addEventListener('touchend', this.onTouchEnd, true);
    }
    onTouchStart(e) {
      if (this.locked) {
        e.stopPropagation();
        this.posX = e.touches[0].pageX;
        this.posY = e.touches[0].pageY;
        this.start = e;
        this.unLock = setTimeout(() => {
          this.locked = false;
          this.unLock = false;
          this.touched = setTimeout(() => { 
            this.setTouch(true);
          }, 300);
          e.target.dispatchEvent(
            new TouchEvent('touchstart', {
              cancelable: true,
              bubbles: true,
              composed: true,
              touches: [e.touches[0]],
              targetTouches: [e.touches[0]],
              changedTouches: [e.touches[0]],
            })
          );
        }, this._time);
      }
    }
    onTouchMove(e) {
      if (this.locked) {
        if (this.unLock) {
          const moveX = Math.abs(e.touches[0].pageX - this.posX);
          const moveY = Math.abs(e.touches[0].pageY - this.posY);
          this.posX = e.touches[0].pageX;
          this.posY = e.touches[0].pageY;
          if (moveX < 5 && moveY >= moveX) {
            clearTimeout(this.unLock);
            this.unLock = false;  
          } else {
            clearTimeout(this.unLock);
            this.locked = false;
            this.unLock = false;
            this.setTouch(true);
            e.target.dispatchEvent(
              new TouchEvent('touchstart', {
                cancelable: true,
                bubbles: true,
                composed: true,
                touches: [this.start.touches[0]],
                targetTouches: [this.start.touches[0]],
                changedTouches: [this.start.touches[0]],
              })
            );
          }
        }
        e.stopPropagation();
      }
    }
    onTouchEnd(e) {
      this.locked = true;
      this.setTouch(false);
      this.setPointer(false);
      clearTimeout(this.touched);
      if (this.unLock) {
        clearTimeout(this.unLock);
        this.unLock = false;
      }
    }
    destroy() {
      dom.removeEventListener('touchstart', this.onTouchStart, true);
      dom.removeEventListener('touchmove', this.onTouchMove, true);
      dom.removeEventListener('touchend', this.onTouchEnd, true);
    }
}

// 拖拽时不显示弹框和指示器
export class MobileInteractor {
  lock = true;
  constructor(chart,setShowTooltip) {
    this.chart = chart;
    this.setShowTooltip = setShowTooltip;
    this.setShowTooltip(true);
    this.axisPointers = chart.getModel("axisPointer");
    this.axisPointers.forEach((e) => {
      e.set("enable", false);
    });
    this.onMouseDown = this.onMouseDown.bind(this);
    this.onMouseMove = this.onMouseMove.bind(this);
    this.onMouseUp = this.onMouseUp.bind(this);
    chart._zr.on("mousedown", this.onMouseDown);
    chart._zr.on("mousemove", this.onMouseMove);
    chart._zr.on("mouseup", this.onMouseUp);

    const tooltip = chart.getViewOfComponentModel(
      chart.getModel("tooltip", 0)
    )._tooltipContent;
    const show = tooltip.show.bind(tooltip);
    tooltip.show = (data) => {
      show(data);
      if (this.lock) {
        tooltip.el.style.display = "none";
        this.setShowTooltip(false);
      } else {
        tooltip.el.style.display = "none";
        this.setShowTooltip(true);
      }
    };
  }
  onMouseDown() {
    this.delay = setTimeout(() => {
      this.lock = false;
      this.delay = undefined;
      this.axisPointers.forEach((e) => {
        e.set("enable", true);
        this.chart._zr.trigger("mousemove", this.mouseEvent);
      });
    }, 300);
  }
  onMouseMove(e) {
    this.mouseEvent = e;
    if (this.delay) {
      clearTimeout(this.delay);
      this.delay = undefined;
    }
  }
  onMouseUp() {
    if (this.delay) {
      clearTimeout(this.delay);
      this.delay = undefined;
    }
    this.lock = true;
    this.axisPointers.forEach((e) => {
      e.set("enable", false);
    });
  }
}