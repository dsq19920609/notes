<template>
    <div class="select" :class="{'level-one': level === '1','level-two': level === '2'}">
        <div class="label" @click.stop="showSelectList()">
            <img  v-if="currentDataType.lineType === 'kline'" class="icon" src="../../assets/images/tl.png" alt="">
            <div v-if="currentDataType.lineType === 'line'" class="line" :class="{'orange': currentDataType.color === 'orange'}"></div>
            {{currentDataType.label}}
            <img class="arrow" :class="{'open': dataTypeSwitch}" src="../../assets/images/icon_open.png" alt="">
        </div>
        <div class="select-list" v-if="dataTypeSwitch">
            <div class="arrow"></div>
            <template v-for="(item,index) in list">
                <div 
                    class="list-item" 
                    :class="{'active': item.id === currentDataType.id,'touch': currentTouch ? item.id === currentTouch.id : false}"
                    :key="index"  
                    @touchstart="touchstartList(item)"
                    @click.stop="closeSelectList(item)"
                >
                    <img v-if="item.lineType === 'kline'" src="../../assets/images/tl.png" alt="">
                    <div v-if="item.lineType === 'line'" class="line" :class="{'orange': item.color === 'orange'}"></div>
                    {{item.label}}
                </div>
            </template>
        </div>
        <div class="mask" v-if="dataTypeSwitch" @click.stop="closeSelectList()"></div>
    </div>
</template>

<script>
export default {
    name: 'Selectlist',
    props: {
        list: Object,
        level: String
    },
    data() {
        return {
            list:this.list,
            level: this.level,
            currentDataType: this.list[0],
            currentTouch: null,
            dataTypeSwitch: false
        };
    },
    mounted() {
        this.$emit('selectItem',this.currentDataType);
    },
    methods: {
        // 显示选择下拉框列表
        showSelectList() {
            this.dataTypeSwitch = true;
            document.body.style.overflowY='hidden'
        },
        // 关闭选择下拉框列表
        closeSelectList(item) {
            if (item) {
                this.currentDataType = item;
                this.$emit('selectItem',item);
            }
            this.dataTypeSwitch = false;
            document.body.style.overflowY='auto'
        },
        // 手指触碰列表项时触发
        touchstartList(item) {
            this.currentTouch = item;
            setTimeout(()=>{
                this.currentTouch = null;
            },500);
        },
    },
};
</script>

<style lang="less" scoped>
@import '../../assets/styles/mixin.less';
@import '../../assets/styles/skin.less';
.select {
    position: relative;
    height: 0.36rem;
    font-family: PingFangSC-Regular;
    font-weight: 400;
    &.level-one {
        font-size: 0.26rem;
        color: @font-most-major;
        .arrow {
            width: 0.16rem;
            margin-left: 0.08rem; 
            &.open {
                transform: rotate(180deg);
            }
        }
    }
    &.level-two {
        font-size: 0.24rem;
        color: @font-general-major;
        .arrow {
            width: 0.12rem;
            margin-left: 0.08rem; 
            &.open {
                transform: rotate(180deg);
            }
        }
    }
    .label {
        .flex(row,flex-start,center,nowrap);
        .icon {
            width: 0.24rem;
            margin-right: 0.08rem;
        }
        .line {
            width: 0.12rem;
            height: 0.04rem;
            margin-right: 0.08rem;
            border-radius: 0.02rem;
            &.orange {
                background: @line-orange;
            }
        }
        
    }
    .select-list {
        position: absolute;
        top: 0.5rem;
        right: 0;
        z-index: 2;
        min-width: 1.88rem;
        padding: 0.16rem 0;
        background: @background-white;
        background: @background-white;
        border-radius: 0.08rem;
        color: @font-most-major;
        white-space: nowrap;
        .arrow {
            width: 0;
            height: 0;
            border-top: 0.15rem solid transparent;
            border-right: 0.15rem solid transparent;
            border-bottom: 0.15rem solid @background-white;
            border-left: 0.15rem solid transparent;
            position: absolute;
            top: -0.3rem;
            right: 0.35rem;
        }
        .list-item {
            .flex(row,center,center,nowrap);
            padding: 0.16rem 0.16rem;
            font-size: 0.28rem;
            img {
                width: 0.20rem;
                margin-left: 0;
                margin-right: 0.18rem;
            }
            .line {
                display: inline-block;
                width: 0.20rem;
                height: 0.04rem;
                margin-right: 0.18rem;
                border-radius: 0.02rem;
                &.orange {
                    background: @line-orange;
                }
            }
            &.active {
                color: @font-red;
            }
            &.touch {
                background-color: @background-black-1;
            }
        }
    }
    .mask {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        background: #000000;
        opacity: 0.03;
    }
}
[theme-mode="black"] {
    .select {
        position: relative;
        height: 0.36rem;
        font-family: PingFangSC-Regular;
        font-weight: 400;
        &.level-one {
            font-size: 0.26rem;
            color: @font-most-major-dark;
            .arrow {
                width: 0.16rem;
                margin-left: 0.08rem; 
                &.open {
                    transform: rotate(180deg);
                }
            }
        }
        &.level-two {
            font-size: 0.24rem;
            color: @font-general-major-dark;
            .arrow {
                width: 0.12rem;
                margin-left: 0.08rem; 
                &.open {
                    transform: rotate(180deg);
                }
            }
        }
        .label {
            .flex(row,flex-start,center,nowrap);
            .icon {
                width: 0.24rem;
                margin-right: 0.08rem;
            }
            .line {
                width: 0.12rem;
                height: 0.04rem;
                margin-right: 0.08rem;
                border-radius: 0.02rem;
                &.orange {
                    background: @line-orange-dark;
                }
            }
        }
        .select-list {
            position: absolute;
            top: 0.5rem;
            right: 0;
            z-index: 2;
            width: 2.04rem;
            padding: 0.16rem 0;
            background: @background-white-dark;
            background: @background-white-dark;
            border-radius: 0.08rem;
            color: @font-most-major-dark;
            .arrow {
                width: 0;
                height: 0;
                border-top: 0.15rem solid transparent;
                border-right: 0.15rem solid transparent;
                border-bottom: 0.15rem solid @background-white-dark;
                border-left: 0.15rem solid transparent;
                position: absolute;
                top: -0.3rem;
                right: 0.35rem;
            }
            .list-item {
                .flex(row,center,center,nowrap);
                padding: 0.16rem 0;
                font-size: 0.28rem;
                img {
                    width: 0.20rem;
                    margin-left: 0;
                    margin-right: 0.18rem;
                }
                .line {
                    display: inline-block;
                    width: 0.20rem;
                    height: 0.04rem;
                    margin-right: 0.18rem;
                    border-radius: 0.02rem;
                    &.orange {
                        background: @line-orange-dark;
                    }
                }
                &.active {
                    color: @font-red-dark;
                }
                &.touch {
                    background-color: @background-black-1-dark;
                }
            }
        }
        .mask {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1;
            width: 100%;
            height: 100%;
            background: #000000;
            opacity: 0.03;
        }
    }
}
</style>