<template>
  <div class="search-panel">
    <div class="search-content">
      <div class="search-input">
        <div class="search-icon"></div>
        <input
          v-model="searchText"
          type="text"
          placeholder="搜索查看个股港资动向"
          @focus="handleFocus"
        />
        <div class="clear-icon" @click="handleClear"></div>
      </div>
      <div class="cancel" @click="cancel">取消</div>
    </div>
    <div class="search-nodata" v-if="list.length == 0 && searchText != ''">
      <div class="nodata-img"></div>
      <div class="text" v-if="isVaild">没有找到相关搜索结果</div>
      <div class="text" v-else>该股票不支持沪深港通交易</div>
    </div>
    <div class="list" v-else>
      <div class="item" v-for="item in list" :key="item.stockCode" @click="handleClick(item)">
        <div class="name">{{ item.stockName }}</div>
        <div class="info">
          <div class="tag">{{ item.marketName }}</div>
          <div class="code">{{ item.stockCode }}</div>
        </div>
      </div>
      <div class="clear-text" v-if="searchText == '' && list.length > 0" @click="clearStorage">
        清除搜索记录
      </div>
    </div>
  </div>
</template>

<script>
import { searchStock } from '@/apis/index.js';
import config from '@/config';
export default {
  data() {
    return {
      list: [],
      searchText: '',
      xhr: null,
      isVaild: true,
      storageKey: 'hsgtSearchHistoryList20211029',
    };
  },
  props: {
    searchList: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  watch: {
    searchText(v) {
      this.list = [];
      if (v == '') {
        this.$nextTick(() => {
          this.list = this.getStorage();
        });
        return;
      }

      searchStock(this.searchText).then(res => {
        if (res.errorcode == 0) {
          for (let i = 0; i < res.data.length; i++) {
            if (this.list.length >= 5) {
              break;
            }
            if (res.data[i].marketId == '17' || res.data[i].marketId == '33') {
              this.list.push(res.data[i]);
            }
          }
        }
      });
    },
  },
  mounted() {
    const s = this;
    // 历史记录和userid相关联
    window.callNativeHandler('getAppInfo', '');
    window.callNativeHandler('getAppInfo', '', function (data) {
      console.log(data);
      s.storageKey += data.mauserid;
    });
  },
  methods: {
    handleClear() {
      this.searchText = '';
    },
    handleFocus() {
      if (this.searchText == '') {
        this.list = this.getStorage();
      }
    },
    cancel() {
      this.$emit('cancel');
    },
    setStorage(item) {
      let list = localStorage.getItem(this.storageKey);
      if (!list) {
        list = [];
        list.push(item);
      } else {
        list = JSON.parse(list);
        if (list.length < 5) {
          list.unshift(item);
        } else {
          list.length = 4;
          list.unshift(item);
        }
      }
      localStorage.setItem(this.storageKey, JSON.stringify(list));
    },
    getStorage() {
      let list = localStorage.getItem(this.storageKey);
      if (!list) {
        return [];
      } else {
        list = JSON.parse(list);
        return list;
      }
    },
    clearStorage() {
      localStorage.removeItem(this.storageKey);
      this.list = [];
    },
    handleClick(item) {
      this.isVaild = false;
      for (let i = 0; i < this.searchList.length; i++) {
        if (this.searchList[i] == item.stockCode) {
          this.isVaild = true;
          break;
        }
      }
      if (this.isVaild) {
        this.setStorage(item);
        window.location.href = `${config.url.stockDetailLink}?market=hs&code=${item.stockCode}&needNew=true`;
      } else {
        this.list = [];
        this.isVaild = false;
      }
    },
  },
};
</script>

<style lang="less">
.search-panel {
  position: fixed;
  height: 100vh;
  width: 100vw;
  background-color: #fff;
  top: 0;
  left: 0;
  padding: 0.24rem 0.32rem;
  text-align: left;
  box-sizing: border-box;
  z-index: 99;
}
.search-nodata {
  text-align: center;
  .nodata-img {
    background-image: url(../assets/images/nodata.png);
    width: 2.2rem;
    height: 2.2rem;
    background-size: 100% 100%;
    margin: 1.28rem auto 0.16rem auto;
  }
  .text {
    font-family: PingFangSC-Regular;
    font-size: 0.28rem;
    color: #323232;
    font-weight: 400;
  }
}
.search-content {
  display: flex;
  margin-bottom: 0.24rem;
  .search-input {
    flex: 1;
    background: #f6f6f6;
    border-radius: 0.16rem;
    padding: 0.2rem 0.16rem;
    display: flex;
    align-items: center;
    .search-icon {
      background-image: url(../assets/images/search-icon.png);
      width: 0.32rem;
      height: 0.32rem;
      background-size: 100% 100%;
      margin-right: 0.18rem;
    }
    input {
      font-family: PingFangSC-Regular;
      font-size: 0.28rem;
      color: #323232;
      background-color: #f6f6f6;
      letter-spacing: 0;
      flex: 1;
      margin-right: 0.18rem;
      font-weight: 400;
    }
    input::-webkit-input-placeholder {
      font-family: PingFangSC-Regular;
      font-size: 0.28rem;
      color: #999999;
      letter-spacing: 0;
      font-weight: 400;
    }
    .clear-icon {
      background-image: url(../assets/images/delete@2x.png);
      width: 0.32rem;
      height: 0.32rem;
      background-size: 100% 100%;
    }
  }
  .cancel {
    font-family: PingFangSC-Regular;
    font-size: 0.28rem;
    color: #323232;
    display: flex;
    align-items: center;
    padding-left: 0.2rem;
  }
}

.list {
  font-family: PingFangSC-Regular;
  font-weight: 400;
  letter-spacing: 0;
  .clear-text {
    font-size: 0.28rem;
    color: #323232;
    text-align: center;
    font-weight: 400;
    padding: 0.3rem;
  }
  .item {
    border-bottom: 0.02rem solid rgba(232, 232, 232, 1);
    padding: 0.18rem 0;
    .name {
      font-size: 0.32rem;
      color: #323232;
      line-height: 0.4rem;
    }
    .info {
      margin-top: 0.08rem;
      .tag {
        font-size: 0.18rem;
        color: #ffffff;
        text-align: center;
        line-height: 0.22rem;
        display: inline-block;
        background: #ffa742;
        border-radius: 0.04rem;
        padding: 0.04rem 0.08rem;
        margin-right: 0.12rem;
      }
      .code {
        display: inline-block;
        font-size: 0.24rem;
        color: #999999;
        line-height: 0.3rem;
      }
    }
  }
}

[theme-mode='black'] {
  .search-panel {
    background-color: #121212;
  }
  .search-nodata {
    .nodata-img {
      background-image: url(../assets/images/nodata.png);
    }
    .text {
      color: #d2d2d3;
    }
  }
  .search-content {
    .search-input {
      flex: 1;
      background: #252525;
      .search-icon {
        background-image: url(../assets/images/search-icon-dark.png);
      }
      input {
        color: #d2d2d3;
        background-color: #252525;
      }
      input::-webkit-input-placeholder {
        color: #8e8e8e;
      }
      .clear-icon {
        background-image: url(../assets/images/delete_dark@2x.png);
      }
    }
    .cancel {
      color: #d2d2d3;
    }
  }

  .list {
    .clear-text {
      color: #d2d2d3;
    }
    .item {
      border-bottom: 0.02rem solid rgba(46, 46, 46, 1);
      .name {
        color: #d2d2d3;
      }
      .info {
        .tag {
          color: #ffffff;
          background: #d48e3d;
        }
        .code {
          color: #8e8e8e;
        }
      }
    }
  }
}
</style>
