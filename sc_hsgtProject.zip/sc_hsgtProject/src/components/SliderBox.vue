<template>
  <div class="slider-box">
    <vue-slider
      v-model="value"
      @change="handleChange"
      @drag-end="handleEnd"
      @drag-start="handleStart"
      tooltip="always"
      :max="59"
      :minRange="1"
      :marks="marks"
      :enableCross="false"
      :tooltip-formatter="formatTootip"
    />
    <Kline :klineVisible="klineVisible" :startIndex="startIndex" :endIndex="endIndex"></Kline>
  </div>
</template>

<script>
import Kline from '@/components/Kline';
export default {
  components: {
    Kline,
  },
  props: {
    // 交易日列表
    tradeList: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      value: [0, 59],
      tradeDays: [],
      marks: {},
      klineVisible: false,
      startIndex: 0,
      endIndex: 59,
      // 跨年情况下显示年份
      showYear: false,
    };
  },
  watch: {
    tradeList() {
      this.init();
      this.tradeDays = this.tradeList.slice(this.tradeList.length - 60, this.tradeList.length);
      const firstDay = this.tradeDays[0];
      const lastDay = this.tradeDays[this.tradeDays.length - 1];
      if (firstDay.toString().substr(0, 4) != lastDay.toString().substr(0, 4)) {
        this.showYear = true;
      } else {
        this.showYear = false;
      }
      this.setMarks();
    },
  },
  methods: {
    init() {
      this.value = [0, 59];
      this.startIndex = 0;
      this.startIndex = 59;
      document.getElementsByClassName('vue-slider-dot-tooltip-top')[0].style.left = this.showYear
        ? '230%'
        : '130%';
      document.getElementsByClassName('vue-slider-dot-tooltip-top')[1].style.left = '-45%';
    },
    formatTootip(v) {
      return this.getDateStr(this.tradeDays[v]);
    },
    // 格式化日期
    getDateStr(v) {
      if (v) {
        if (!this.showYear) {
          return `${v.toString().substr(4, 2)}-${v.toString().substr(6, 2)}`;
        } else {
          if (Number(v.toString().substr(4, 2)) > 5) {
            return `${v.toString().substr(0, 4)}-${v.toString().substr(4, 2)}-${v
              .toString()
              .substr(6, 2)}`;
          } else {
            return `${v.toString().substr(4, 2)}-${v.toString().substr(6, 2)}`;
          }
        }
      } else {
        return '';
      }
    },
    setMarks() {
      this.marks = {
        '0': {
          label: this.getDateStr(this.tradeDays[0]),
          labelStyle: {
            transform: 'translate(0.01rem, 0)',
          },
        },
        '20': {
          label: this.getDateStr(this.tradeDays[20]),
        },
        '40': {
          label: this.getDateStr(this.tradeDays[40]),
        },
        '59': {
          label: this.getDateStr(this.tradeDays[59]),
          labelStyle: {
            transform: 'translate(-0.6rem, 0)',
          },
        },
      };
    },
    handleChange(v) {
      [this.startIndex, this.endIndex] = v;
      const startDate = `${this.tradeDays[this.startIndex].substr(0, 4)}-${this.tradeDays[
        this.startIndex
      ].substr(4, 2)}-${this.tradeDays[this.startIndex].substr(6, 2)}`;
      const endDate = `${this.tradeDays[this.endIndex].substr(0, 4)}-${this.tradeDays[
        this.endIndex
      ].substr(4, 2)}-${this.tradeDays[this.endIndex].substr(6, 2)}`;
      this.startDate = startDate;
      this.endDate = endDate;
      if (this.startIndex < (this.showYear ? 8 : 4)) {
        document.getElementsByClassName('vue-slider-dot-tooltip-top')[0].style.left = this.showYear
          ? '230%'
          : '130%';
      } else {
        document.getElementsByClassName('vue-slider-dot-tooltip-top')[0].style.left = '50%';
      }
      if (this.endIndex > 55) {
        document.getElementsByClassName('vue-slider-dot-tooltip-top')[1].style.left = '-45%';
      } else {
        document.getElementsByClassName('vue-slider-dot-tooltip-top')[1].style.left = '50%';
      }
    },
    // 开始滑动
    handleStart(v) {
      this.klineVisible = true;
      document.getElementsByClassName('vue-slider-dot')[v].style.zIndex = 10;
      document.getElementsByClassName('vue-slider-dot-tooltip-inner')[v].style.fontSize = '0.36rem';
      document.getElementsByClassName('vue-slider-dot-tooltip-inner')[v].style.padding =
        '0.06rem 0.14rem 0.06rem 0.14rem';
    },
    // 滑动结束
    handleEnd(v) {
      this.klineVisible = false;
      this.$emit('change', this.startDate, this.endDate);
      document.getElementsByClassName('vue-slider-dot')[1].style.zIndex = 5;
      document.getElementsByClassName('vue-slider-dot')[0].style.zIndex = 5;

      document.getElementsByClassName('vue-slider-dot-tooltip-inner')[v].style.fontSize = '0.22rem';
      document.getElementsByClassName('vue-slider-dot-tooltip-inner')[v].style.padding =
        '0.02rem 0.08rem';
    },
  },
};
</script>
<style lang="less">
.slider-box {
  .vue-slider-rail {
    background: #f1f1f1;
  }
  .vue-slider-process {
    background-color: #fa3b32;
  }

  .vue-slider-ltr .vue-slider-mark-step {
    top: -0.1rem;
    height: 0.06rem;
    width: 0.02rem;
    background-color: #999999;
    border-radius: 0;
  }
  .vue-slider-ltr .vue-slider-mark-label {
    font-size: 0.22rem;
    color: #999999;
    top: -0.52rem;
    font-family: THSMoneyfont-Medium;
    margin-top: 0;
  }
  .vue-slider-dot {
    width: 0.32rem !important;
    height: 0.32rem !important;
  }
  .vue-slider-dot-handle {
    width: 0.32rem;
    height: 0.32rem;
    // transform: translate(-0.12rem, -0.12rem);
    box-shadow: 0px 0px 5px 0px rgba(221, 221, 221, 1);
  }
  .vue-slider-dot-tooltip-top {
    top: 0.07rem;
  }
  .vue-slider-dot-handle::after {
    content: '';
    height: 0.16rem;
    width: 0.16rem;
    opacity: 0.6;
    background: #e93030;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    border-radius: 50%;
  }
  .vue-slider-dot-tooltip-inner {
    font-size: 0.22rem;
    background: #323232;
    border-radius: 0.06rem;
    padding: 0 0.08rem 0.02rem 0.08rem;
    font-family: THSMoneyfont-Medium;
    margin-bottom: 0.16rem;
    &::after {
      display: none;
    }
  }
}

[theme-mode='black'] {
  .slider-box {
    .vue-slider-rail {
      background: #505050;
    }
    .vue-slider-process {
      background-color: #cf3930;
    }

    .vue-slider-ltr .vue-slider-mark-step {
      background-color: #8e8e8e;
    }
    .vue-slider-ltr .vue-slider-mark-label {
      color: #8e8e8e;
    }
    .vue-slider-dot-handle {
      box-shadow: 0px 0px 5px 0px rgba(221, 221, 221, 1);
    }
    .vue-slider-dot-handle::after {
      background: #e93030;
    }
    .vue-slider-dot-tooltip-inner {
      background: #d2d2d3;
      color: #121212;
    }
  }
}
</style>
<style lang="less" scoped>
.slider-box {
  position: fixed;
  bottom: 0;
  width: 100vw;
  height: 1.92rem;
  background-color: #fff;
  padding-top: 0.62rem;
  box-sizing: border-box;
  box-shadow: 0px -3px 12px 0px rgba(232, 232, 232, 1);
  padding-left: 0.32rem;
  padding-right: 0.32rem;
  z-index: 10;
}

.vue-slider {
  height: 0.12rem !important;
}

[theme-mode='black'] {
  .slider-box {
    background-color: #191919;
    box-shadow: 0px -3px 12px 0px rgba(0, 0, 0, 1);
  }
}
</style>
