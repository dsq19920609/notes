<template>
    <div class="history-data" v-if="historyList.length > 0">
        <div class="title">历史数据</div>
        <div class="list-header">
            <div class="col1">日期</div>
            <div class="col2">{{pageType === 'north' ? '沪股通' : '港股通(沪)'}}</div>
            <div class="col3">{{pageType === 'north' ? '深股通' : '港股通(深)'}}</div>
            <div class="col4">合计</div>
        </div>
        <div class="list-content">
            <template v-for="(item,index) in historyList.slice(0,10)">
                <div
                    class="list-item"
                    :key="index"
                >
                    <div class="col1">{{item.date}}</div>
                    <div class="col2" :class="{'red': item.hgt >=0 }">{{item.hgt | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                    <div class="col3" :class="{'red': item.sgt >=0 }">{{item.sgt | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                    <div class="col4" :class="{'red': item.total >=0 }">{{item.total | numberConvert}}<span style="fontSize: 0.3rem">亿</span></div>
                </div>
            </template>
        </div>
        <div class="list-more" @click="gotoHistoryDataPage()">
            查看更多
            <img src="../assets/images/icon_forward.png" alt="">
        </div>
    </div>
</template>
<script>

import {getHistoryData} from '@/apis';
export default {
  name: 'HistoryData',
  mounted() {
    this.handleGetHistoryData();
    this.timer = setInterval(()=>{
      this.handleGetHistoryData();
    },60000);
  },
  props: {
    pageType: String
  },
  beforeDestroy() {
    clearInterval(this.timer);
  },
  data() {
    return {
      historyList: [], // 历史数据列表
      timer: null
    };
  },
  methods: {
    // 查看更历史数据
    gotoHistoryDataPage() {
      this.$router.push({
        path: `/historyDataPage?pageType=${this.pageType}`,
        query: {
          pageType: this.pageType
        }
      });
      const type=this.pageType=='north'?'lgt':'ggt';
      window.hxmClickStat(`hsgt.${type}.lssj`);
      // window.location.href = `client.html?action=ymtz^webid=2804^url=${'https://localhost:8080/historyDataPage'}^mode=new`;
    },
    // 获取历史数据
    handleGetHistoryData () {
      getHistoryData(this.pageType,1,10).then(res=>{
        if (res.status_code === 0) {
          res.data.list.forEach((item,index)=>{
            this.historyList.push({
              date: item.trade_date,
              hgt: item.sh_net_buy/100000000,
              sgt: item.sz_net_buy/100000000,
              total: item.total_net_buy/100000000
            });
          });
        }
      });
    }
  }
};
</script>
<style lang="less" scoped>
@import '../assets/styles/mixin.less';
@import '../assets/styles/skin.less';
.history-data {
    .flex(column,flex-start,center,nowrap);
    width: 100%;
    margin-bottom: 0.4rem;
    border-radius: 0.16rem;
    background-color: @background-white;
    .title {
        width: calc(100% - 0.64rem);
        margin: 0.4rem 0 0.24rem;
        font-size: 0.36rem;
        color: @font-most-major;
        line-height: 0.5rem;
        font-weight: 700;
        text-align: left;
    }
    .list-header {
        .flex(row,flex-start,center,nowrap);
        width: calc(100% - 0.64rem);
        height: 0.74rem;
        font-family: PingFangSC-Regular;
        font-size: 0.28rem;
        color: @font-general-major;
        font-weight: 400;
        .col1 {
            width: 2.2rem;
            text-align: left;
        }
        .col2 {
            width: 1.32rem;
            text-align: right;
        }
        .col3 {
            width: 1.68rem;
            text-align: right;
        }
        .col4 {
            width: 1.68rem;
            text-align: right;
        }
    }
    .list-content {
        .flex(column,flex-start,center,nowrap);
        width: calc(100% - 0.64rem);
        .list-item {
            .flex(row,flex-start,center,nowrap);
            width: 100%;
            height: 0.96rem;
            font-family: THSMoneyfont-Medium;
            font-size: 0.32rem;
            font-weight: 500;
            border-bottom: 0.01rem solid @line-gray;
            &:first-child {
                border-top: 0.01rem solid @line-gray;
            }
            .col1 {
                width: 2.2rem;
                text-align: left;
                color: @font-most-major;
            }
            .col2 {
                width: 1.32rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
            .col3 {
                width: 1.68rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
            .col4 {
                width: 1.68rem;
                text-align: right;
                color: @font-green;
                &.red {
                    color: @font-red;
                }
            }
        }

    }
    .list-more {
        width: 100%;
        height:0.96rem;
        line-height: 0.96rem;
        color: @font-general-major;
        font-size: 0.28rem;
        text-align: center;
        img {
            height: 0.24rem;
            vertical-align: initial;
        }
    }
}
[theme-mode="black"] {
    .history-data {
        .flex(column,flex-start,center,nowrap);
        width: 100%;
        margin-bottom: 0.4rem;
        border-radius: 0.16rem;
        background-color: @background-white-dark;
        .title {
            width: calc(100% - 0.64rem);
            margin: 0.4rem 0 0.24rem;
            font-size: 0.36rem;
            color: @font-most-major-dark;
            line-height: 0.5rem;
            font-weight: 700;
            text-align: left;
        }
        .list-header {
            .flex(row,flex-start,center,nowrap);
            width: calc(100% - 0.64rem);
            height: 0.74rem;
            font-family: PingFangSC-Regular;
            font-size: 0.28rem;
            color: @font-general-major-dark;
            font-weight: 400;
            .col1 {
                width: 2.2rem;
                text-align: left;
            }
            .col2 {
                width: 1.32rem;
                text-align: right;
            }
            .col3 {
                width: 1.68rem;
                text-align: right;
            }
            .col4 {
                width: 1.68rem;
                text-align: right;
            }
        }
        .list-content {
            .flex(column,flex-start,center,nowrap);
            width: calc(100% - 0.64rem);
            .list-item {
                .flex(row,flex-start,center,nowrap);
                width: 100%;
                height: 0.96rem;
                font-family: THSMoneyfont-Medium;
                font-size: 0.32rem;
                font-weight: 500;
                border-bottom: 0.01rem solid @line-gray-dark;
                &:first-child {
                    border-top: 0.01rem solid @line-gray-dark;
                }
                .col1 {
                    width: 2.2rem;
                    text-align: left;
                    color: @font-most-major-dark;
                }
                .col2 {
                    width: 1.32rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red-dark;
                    }
                }
                .col3 {
                    width: 1.68rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red-dark;
                    }
                }
                .col4 {
                    width: 1.68rem;
                    text-align: right;
                    color: @font-green-dark;
                    &.red {
                        color: @font-red;
                    }
                }
            }
        }
        .list-more {
            width: 100%;
            height:0.96rem;
            line-height: 0.96rem;
            color: @font-general-major-dark;
            font-size: 0.28rem;
            text-align: center;
            img {
                height: 0.24rem;
                vertical-align: initial;
            }
        }
    }
}
</style>
