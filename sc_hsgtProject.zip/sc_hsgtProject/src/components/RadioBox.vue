<template>
  <div class="radio-box">
    <div
      :class="{ 'radio-item': true, active: activeId == item.id }"
      v-for="item in list"
      :key="item.name"
      @click="handleClick(item)"
    >
      {{ item.name }}
    </div>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex';

export default {
  data() {
    return {
      activeId: 1,
      list: [],
    };
  },
  props: {
    type: {
      type: Number,
      default: 1,
    },
  },
  computed: {
    ...mapState(['fixedTab']),
    radioBoxClass() {
      return ['radio-box', this.fixedTab ? 'fixed' : ''];
    },
  },
  methods: {
    ...mapMutations(['setFixedTab']),
    handleClick(item) {
      this.activeId = item.id;
      this.$emit('change', item);
    },
  },
  mounted() {
    if (this.type == 1) {
      this.list = [
        {
          id: 1,
          name: '十大成交榜',
          url: '/stock/top_ten_data/get_list',
        },
        {
          id: 2,
          name: '净买入',
          url: '/stock/net_buy_list/get_list',
        },
        {
          id: 3,
          name: '净卖出',
          url: '/stock/net_sell_list/get_list',
        },
        {
          id: 4,
          name: '增持比例',
          url: '/stock/add_hold_list/get_list',
        },
        {
          id: 5,
          name: '重仓股票',
          url: '/stock/heavy_position_list/get_list',
        },
        {
          id: 6,
          name: '自选股',
          url: '/stock/optional/get_list',
        },
      ];
    } else if (this.type == 2) {
      this.list = [
        {
          id: 1,
          name: '十大成交榜',
          url: '/stock/top_ten_data/get_list',
        },
        {
          id: 2,
          name: '净买入',
          url: '/stock/net_buy_list/get_list',
        },
        {
          id: 3,
          name: '净卖出',
          url: '/stock/net_sell_list/get_list',
        },
        {
          id: 4,
          name: '增持比例',
          url: '/stock/add_hold_list/get_list',
        },
        {
          id: 5,
          name: '重仓股票',
          url: '/stock/heavy_position_list/get_list',
        },
      ];
    } else if (this.type == 3) {
      this.list = [
        {
          id: 1,
          name: '盈利最强',
          type: 'profit',
        },
        {
          id: 2,
          name: '资金最强',
          type: 'fund',
        },
        {
          id: 3,
          name: '连续增仓',
          type: 'continue',
        },
      ];
    } else {
      this.list = [
        {
          id: 1,
          name: '流入板块',
        },
        {
          id: 2,
          name: '流出板块',
        },
      ];
    }
  },
};
</script>

<style lang="less" scoped>
.radio-box {
  padding-left: 0.32rem;
  width: 100vw;
  background-color: #fff;
  text-align: left;
  overflow-x: auto;
  height: 0.64rem;
  overflow-y: hidden;
  white-space: nowrap;
  padding-top: 0.24rem;
  padding-bottom: 0.26rem;
  &::-webkit-scrollbar {
    display: none;
  }

  .radio-item {
    padding: 0.14rem 0.32rem 0.13rem 0.32rem;
    background: #f6f6f6;
    border-radius: 0.08rem;
    color: #666666;
    font-size: 0.26rem;
    margin-right: 0.24rem;
    display: inline-block;
    font-family: PingFangSC-Regular;
  }

  .radio-item:last-child{
    margin-right: 0.5rem;
  }
  .active {
    background: rgba(250, 59, 50, 0.1);
    color: #fa3b32;
  }
}

[theme-mode='black'] {
  .radio-box {
    background-color: #121212;
    .radio-item {
      background: #252525;
      color: #a9a9a9;
    }
    .active {
      background: rgba(207, 57, 48, 0.1);
      color: #cf3930;
    }
  }
}
</style>
