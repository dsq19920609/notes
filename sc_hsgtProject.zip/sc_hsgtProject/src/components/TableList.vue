<template>
  <div class="table-list">
    <div class="table-content" ref="tableContent" @scroll="tbodyHandleScroll">
      <dir class="table-thead">
        <div
          class="table-th"
          :style="{ width: item.width }"
          v-for="item in thead"
          :key="item.key"
          @click="thClick(item)"
        >
          <template v-if="item.theadFormat"
            ><div style="display: inline-block;" v-html="item.theadFormat()"></div
          ></template>
          <template v-else>
            {{ item.name }}
          </template>
          <div
            v-if="item.sortable && item.key == sortThead && sortType != ''"
            :class="sortClassName"
          ></div>
        </div>
      </dir>
      <div class="table-tbody">
        <div
          class="table-tr"
          v-for="item in list"
          :key="item.security_code || item.code || broker_code"
          @click="handleTrClick(item)"
        >
          <div class="table-td" :style="{ width: td.width }" v-for="td in thead" :key="td.key">
            <template v-if="td.format">
              <div v-html="td.format(item)"></div>
            </template>
            <template v-else>
              {{ item[td.key] }}
            </template>
          </div>
        </div>
        <div class="table-nodata" v-if="list.length == 0">
          {{ isLoading ? '加载中...' : '暂无数据' }}
        </div>
      </div>
    </div>
    <div class="table-thead-fixed" ref="fixedThead">
      <div v-if="fixedTab" class="table-column-thead" :style="{ width: fixedThead.width }">
        <template v-if="fixedThead.theadFormat">
          <div v-html="fixedThead.theadFormat()"></div>
        </template>
        <template v-else>{{ fixedThead.name }}</template>
      </div>
      <div v-if="fixedTab" class="right-white"></div>
      <div
        class="table-th"
        :style="{ width: item.width }"
        v-for="item in thead"
        :key="item.key"
        @click="thClick(item)"
      >
        <template v-if="item.theadFormat"
          ><div style="display: inline-block;" v-html="item.theadFormat()"></div
        ></template>
        <template v-else>
          {{ item.name }}
        </template>
        <div
          v-if="item.sortable && item.key == sortThead && sortType != ''"
          :class="sortClassName"
        ></div>
      </div>
    </div>

    <div class="table-column-fixed">
      <div class="table-thead" :style="{ width: fixedThead.width }">
        <template v-if="fixedThead.theadFormat">
          <div v-html="fixedThead.theadFormat()"></div>
        </template>
        <template v-else>{{ fixedThead.name }}</template>
      </div>
      <div class="table-tbody" ref="fixedTbody" :style="{ width: fixedThead.width }">
        <div
          class="table-tr"
          v-for="item in list"
          :key="item.security_code || item.code || item.broker_code"
          @click="handleTrClick(item)"
        >
          <template v-if="fixedThead.format">
            <div v-html="fixedThead.format(item)"></div>
          </template>
          <template v-else>
            {{ item[fixedThead.key] }}
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
  props: {
    thead: {
      type: Array,
      default() {
        return [];
      },
    },
    list: {
      type: Array,
      default() {
        return [];
      },
    },
    fixedTab: {
      type: Boolean,
      default: false,
    },
    defaultSortField: {
      type: String,
      default: '',
    },
    defaultSortMode: {
      type: String,
      default: 'desc',
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      fixedThead: {},
      sortType: '',
      sortThead: '',
      scrollTop: 0,
    };
  },
  computed: {
    sortClassName() {
      return [`thead-sort-${this.sortType}`];
    },
  },
  methods: {
    initSort() {
      this.sortType = '';
      this.sortThead = '';
    },
    handleTrClick(item) {
      this.$emit('tr-click', item);
    },
    tbodyHandleScroll(e) {
      this.$refs.fixedThead.style.marginLeft = `-${e.target.scrollLeft}px`;
    },
    getSortType(str) {
      if (str == '' || str == 'up') {
        return 'down';
      } else if (str == 'down') {
        return 'up';
      } else {
        return 'down';
      }
    },
    thClick(item) {
      if (item.sortable) {
        if (this.sortThead === item.key) {
          this.sortType = this.getSortType(this.sortType);
        } else {
          this.sortThead = item.key;
          this.sortType = 'down';
        }
        this.$emit('thClick', item, this.sortType);
      }
    },
  },
  mounted() {
    this.fixedThead = {};
    this.thead.forEach(element => {
      if (element.fixed) {
        this.fixedThead = element;
      }
    });
    this.sortThead = this.defaultSortField;
    this.sortType = this.defaultSortMode;
  },
  watch: {
    defaultSortField(v) {
      this.sortThead = v;
      this.sortType = this.defaultSortMode;
    },
    thead: {
      handler(v) {
        this.fixedThead = {};
        v.forEach(item => {
          if (item.fixed) {
            this.fixedThead = item;
          }
        });
      },
      deep: true,
    },
  },
};
</script>
<style lang="less">
.table-nodata {
  color: #999999;
  padding-top:1.28rem;
  padding-bottom: 1.28rem;
}
.fall {
  color: #00b650 !important;
}
.rise {
  color: #fa3b32 !important;
}
.unit {
  font-size: 0.32rem !important;
  font-family: PingFangSC-Semibold;
  font-weight: 600;
}

[theme-mode='black'] {
  .fall {
    color: #019e4b !important;
  }
  .rise {
    color: #cf3930 !important;
  }
}
</style>

<style lang="less" scoped>
.table-list {
  position: relative;
  margin: 0 0.32rem;
  overflow: hidden;
  font-family: PingFangSC-Regular;
  border-top: 0.01rem solid rgba(232, 232, 232, 1);
  z-index: 0;
}
.table-content {
  white-space: nowrap;
  overflow: auto;
  &::-webkit-scrollbar {
    display: none;
  }
}
.table-thead {
  font-size: 0.26rem;
  color: #999999;
  font-family: PingFangSC-Regular;
}
.table-th {
  vertical-align: middle;
  display: inline-block;
  text-align: right;
  color: #999999;
  height: 0.72rem;
  line-height: 0.7rem;
  font-family: PingFangSC-Regular;
  font-size: 0.26rem;
}
.table-tr {
  border-bottom: 0.01rem solid rgba(232, 232, 232, 1);
  padding: 0.16rem 0;
  width: max-content;
}
.table-td {
  display: inline-block;
  vertical-align: middle;
  text-align: right;
  font-family: PingFangSC-Regular;
  font-size: 0.34rem;
}
.table-column-fixed {
  position: absolute;
  top: 0;
  left: 0;
  background-color: #ffffff;
  z-index: 9;
  .table-thead {
    border-bottom: 0.01rem solid rgba(232, 232, 232, 1);
    width: max-content;
    height: 0.72rem;
    line-height: 0.7rem;
  }
  .table-tbody {
    overflow: auto;
    margin-top: -0.02rem;
    &::-webkit-scrollbar {
      display: none;
    }

    .table-tr {
      width: initial;
    }
  }
}
.table-thead-fixed {
  overflow-y: hidden;
  white-space: nowrap;
  // overflow-x: auto;
  overflow-x: hidden;
  position: absolute;
  top: 0;
  background-color: #ffffff;
  border-bottom: 0.01rem solid rgba(232, 232, 232, 1);
  // width: 100%;
  width: max-content;
  &::-webkit-scrollbar {
    display: none;
  }

  .table-column-thead {
    position: fixed;
    padding-left: 0.32rem;
    left: 0;
    top: 0;
    background-color: #fff;
    font-family: PingFangSC-Regular;
    font-size: 0.26rem;
    line-height: 0.7rem;
    color: #999999;
    z-index: 10;
  }

  .right-white {
    width: 0.32rem;
    height: 1.1rem;
    background: #fff;
    position: fixed;
    right: 0;
    top: 0;
    margin-top: -0.02rem;
  }
}

.thead-sort-up {
  background-image: url(../assets/images/sort_up.png);
  width: 0.15rem;
  height: 0.2rem;
  display: inline-block;
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.thead-sort-down {
  background-image: url(../assets/images/sort_up.png);
  transform: rotate(180deg);
  width: 0.15rem;
  height: 0.2rem;
  display: inline-block;
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

[theme-mode='black'] {
  .table-list {
    border-top: 0.01rem solid rgba(46, 46, 46, 1);
    color: #d2d2d3;
  }
  .table-thead {
    color: #8e8e8e;
  }
  .table-th {
    color: #8e8e8e;
  }
  .table-tr {
    border-bottom: 0.01rem solid rgba(46, 46, 46, 1);
  }
  .table-column-fixed {
    background-color: #121212;
    .table-thead {
      border-bottom: 0.01rem solid rgba(46, 46, 46, 1);
    }
  }
  .table-thead-fixed {
    background-color: #121212;
    border-bottom: 0.01rem solid rgba(46, 46, 46, 1);

    .table-column-thead {
      background-color: #121212;
      color: #8e8e8e;
    }

    .right-white {
      background: #121212;
    }
  }

  .thead-sort-up {
    background-image: url(../assets/images/sort_up_dark.png);
  }
  .thead-sort-down {
    background-image: url(../assets/images/sort_up_dark.png);
  }
}
</style>
