<template>
  <div class="tree-map">
    <div
      style="
        height: 3.4rem;
        border-radius: 0.20rem;
        overflow: hidden;
        position: relative;
        transform-style: preserve-3d;
      "
    >
      <div style="height: 100%; width: 100%;">
        <div id="tree-map"></div>
      </div>
      <div class="nodata" v-show="list.length == 0">
        暂无数据
      </div>
    </div>
  </div>
</template>

<script>
const pageWidth = document.body.offsetWidth;
import util from '@/lib/util.js';
const dpr = document.getElementsByTagName('html')[0].getAttribute('data-dpr'); // dpr不同页面大小不同（图表会产生畸形变化），会影响可视化图表样式，需要乘上dpr。
const pageRate = pageWidth / (375 * dpr);
import { phoneTheme } from '@/assets/common.js';
export default {
  props: {
    list: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  watch: {
    list: {
      handler() {
        this.selfData = {
          name: '流入',
          children: this.list,
        };
        setTimeout(() => {
          this.setChart();
        });
      },
      deep: true,
    },
  },
  data() {
    return {
      chart: '',
      selfData: [],
      isDark: false,
    };
  },
  mounted() {
    this.isDark = phoneTheme();
  },
  methods: {
    setChart() {
      const self = this;
      if (!this.chart) {
        this.chart = window.D3Charts.init('tree-map');
      }
      const font = {
        size: 14 * dpr * pageRate,
        height: 20 * dpr * pageRate,
        weight: 400,
        family: 'PingFangSC-Regular',
      };
      const option = {
        data: [
          {
            originData: this.selfData,
          },
        ],
        grid: [
          {
            left: 0,
            top: 0,
            right: 0,
            bottom: 0,
          },
        ],
        series: [
          {
            type: 'treemap',
            $dataIndex: 0,
            $gridIndex: 0,
            color(d) {
              if (d.change > 0) {
                // return window.D3Charts.graphic.colorTool.modifyHSL(
                //   '#2F97FF',
                //   null,
                //   null,
                //   1 - d.percent * 7
                // );
                return self.isDark ? '#CF3930' : '#F25557';
              } else if (d.change < 0) {
                // return D3Charts.graphic.colorTool.modifyHSL(
                //   '#2CDCBC',
                //   null,
                //   null,
                //   1 + d.percent * 7
                // );
                return self.isDark ? '#019E4B' : '#3AA66B';
              } else {
                return '#dcdcdc';
              }
            },
            breadcrumb: {
              show: false,
            },
            label: {
              normal: {
                show: true,
                formatter(value) {
                  const v = util.getUnitNumber2(value.showValue);
                  return `{name|${value.name}\n}{value|${v}}`;
                },
                style: {
                  rich: {
                    name: {
                      fontSize: font.size,
                      fontFamily: font.family,
                      fontWeight: font.weight,
                      textLineHeight: font.height,
                      textAlign: 'center',
                      fill: '#fff',
                    },
                    value: {
                      fontSize: font.size,
                      fontFamily: font.family,
                      fontWeight: font.weight,
                      textAlign: 'center',
                      fill: '#fff',
                    },
                  },
                },
              },
            },
            itemStyle: {
              normal: {
                lineWidth: 1 * pageRate * dpr,
                stroke: self.isDark ? '#121212' : '#ffffff',
              },
            },
          },
        ],
      };
      this.chart.setOption(option);
    },
  },
};
</script>
<style lang="less">
.nodata {
  position: absolute;
  color: #999999;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>
<style lang="less" scoped>
.tree-map {
  height: 3.94rem;
  box-sizing: border-box;
  margin: 0 0.28rem;
  padding-top: 0.32rem;
  .name {
    font-family: PingFangSC-Medium;
    font-size: 0.36rem;
    color: #323232;
    text-align: left;
  }
}
#tree-map {
  height: 100%;
  width: 100%;
}

[theme-mode='black'] {
  .tree-map {
    .name {
      color: #d2d2d3;
    }
  }
}
</style>
