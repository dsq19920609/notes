/**
 * @description: 全局变量
 * @param {String} str
 */

// eslint-disable-next-line no-unused-vars
const { protocol } = window.location;
// 环境域名
const envHost = {
  // 对应proxy
  dev: '//apigate-test.10jqka.com.cn',
  //对应测试环境主域名
  test: '//apigate-test.10jqka.com.cn',
  //对应正式环境主域名
  release: '//apigate.10jqka.com.cn',
};
const BASE_URL_API = envHost[process.env.VUE_APP_CURRENTMODE];

// 相同域名接口申明(自动拼接域名前缀)
const interfaceApi = {
  interface: 'https://apigate.10jqka.com.cn/d/hq/hshkconnect',
};
// const interfaceApi = {
//   interface: '/d/hq/hshkconnect',
// };
// Object.keys(interfaceApi).forEach(key => interfaceApi[key] = BASE_URL_API + interfaceApi[key]);

// 不同域名接口申明
const diffInterface = {
  //对应开发环境
  dev: {
    getSearchStocks: '//testm.10jqka.com.cn/hgt/data/method/searchStocks/',
    searchStock:
      'https://testm.10jqka.com.cn/tg_templates/doubleone/apiCenter/searchStock/index.php',
  },
  //对应测试环境
  test: {
    getSearchStocks: '//testm.10jqka.com.cn/hgt/data/method/searchStocks/',
    searchStock: '//testm.10jqka.com.cn/tg_templates/doubleone/apiCenter/searchStock/index.php',
  },
  //对应正式环境主
  release: {
    getSearchStocks: '//eq.10jqka.com.cn/hgt/data/method/searchStocks/',
    searchStock: '//ozone.10jqka.com.cn/tg_templates/doubleone/apiCenter/searchStock/index.php',
  },
};

// 图片路径
const imageUrl = {
  dev: '//testm.10jqka.com.cn/cd/mobileweb-eq-hsgt-project-front-container',
  test: '//testm.10jqka.com.cn/cd/mobileweb-eq-hsgt-project-front-container',
  release: '//s.thsi.cn/cd/mobileweb-eq-hsgt-project-front-container',
};

export default {
  stat: {
    pageId: '',
    // eslint-disable-next-line camelcase
    url_ver: '',
  },

  api: {
    ...interfaceApi,
    // 其余域名自行填充
    ...diffInterface[process.env.VUE_APP_CURRENTMODE],
  },

  url: {
    stockDetailLink: '//eq.10jqka.com.cn/HSHKCapitalCount/stockDetail.html',
    blockDetailLink: '//eq.10jqka.com.cn/HSHKCapitalCount/plateMoneyFlowDetail.html',
    organDetailLink: '//eq.10jqka.com.cn/HSHKCapitalCount/departmentDetail.html',
  },
  imageUrl: imageUrl[process.env.VUE_APP_CURRENTMODE],
};
