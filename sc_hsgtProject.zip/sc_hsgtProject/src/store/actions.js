export const showModal = ({
  commit
}, {
  modaldata,
  type
}) => {
  commit('showModal', {
    modaldata,
    type
  });
  commit('toggleModal');
};