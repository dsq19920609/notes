const state = {
  fixedTab: false,
};
const mutations = {
  setFixedTab(s, v) {
    s.fixedTab = v;
  },
};
export { state, mutations };
