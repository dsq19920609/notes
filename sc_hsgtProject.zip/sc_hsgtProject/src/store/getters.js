export const alertmodal = state => state.alertmodal;

export const isExistInMyIndexes = state => name => state.myIndexes.find(item => item.display_name == name);