<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import { phoneTheme } from '@/assets/common.js'
export default {
  mounted() {
    phoneTheme();
  }
}
</script>

<style lang="less">
@import './assets/styles/mixin.less';
@import './assets/styles/skin.less';
  html {
    height: 100%;
  }
  body {
    height: 100%;
    background: @background-page;
    overflow-x: hidden;
  }
  #app {
    height:calc(100% - 0.68rem);
    font-family: 'PingFang Medium', 'PingFang SC', 'Source Han Sans', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
  }

  [theme-mode="black"] {
    html {
      height: 100%;
    }
    body {
      height: 100%;
      background: @background-page-dark;
      overflow-x: hidden;
    }
    #app {
      height:calc(100% - 0.68rem);
      font-family: 'PingFang Medium', 'PingFang SC', 'Source Han Sans', sans-serif;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      text-align: center;
    }
  }
</style>
