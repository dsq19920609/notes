module.exports = {
  env: {
    node: true,
    browser: true,
    es6: true
  },
  extends: ['plugin:vue/essential', 'sonarjs'],
  parserOptions: {
    sourceType: 'module',
  },
  parser: 'vue-eslint-parser',

  rules: {
    'no-magic-numbers': 0,
    // 'guard-for-in': 0,
    'eqeqeq': 0,
    'line-comment-position': 0,
    'no-console': 1,
    // 'complexity': 0
  }
};